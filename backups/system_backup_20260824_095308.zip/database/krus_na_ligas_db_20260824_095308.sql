-- Krus na Ligas system backup
-- Generated: 2026-08-24 09:53:08

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `krus_na_ligas_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `krus_na_ligas_db`;

DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `username` varchar(100) NOT NULL DEFAULT '',
  `role` varchar(50) NOT NULL DEFAULT 'resident',
  `action` varchar(50) NOT NULL DEFAULT 'activity',
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activity_logs_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('1', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 21:22:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('2', '8', 'tenderfoot1', 'resident', 'login', 'User logged in to the system', '2026-07-29 21:38:29');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('3', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 21:39:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('4', '8', 'tenderfoot1', 'resident', 'login', 'User logged in to the system', '2026-07-29 21:51:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('5', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 21:52:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('6', '7', 'admin', 'admin', 'user_created', 'Admin created a STAFF account for mig1259.', '2026-07-29 22:23:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('7', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:23:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('8', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:31:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('9', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:32:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('10', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:46:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('11', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdasdas.', '2026-07-29 22:59:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('12', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: dasdsadas.', '2026-07-29 23:12:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('13', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:18:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('14', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:18:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('15', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdasda.', '2026-07-29 23:27:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('16', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:28:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('17', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 23:57:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('18', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 23:57:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('19', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdasd.', '2026-07-29 23:58:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('20', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:58:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('21', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdads.', '2026-07-30 00:00:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('22', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-30 00:00:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('23', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-30 00:01:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('24', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-30 00:57:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('25', '7', 'admin', 'admin', 'user_created', 'Admin created a ADMIN account for admin1.', '2026-07-30 01:04:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('26', '7', 'admin', 'admin', 'user_created', 'Admin created a STAFF account for kenneth.', '2026-07-30 01:05:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('27', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 01:05:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('28', '0', 'nethhh', 'resident', 'registration_submitted', 'A new resident account was registered.', '2026-07-30 01:11:29');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('29', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 01:11:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('30', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 01:13:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('31', '10', 'admin1', 'admin', 'verification_verified', 'User verification was verified.', '2026-07-30 01:14:55');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('32', '10', 'admin1', 'admin', 'verification_verified', 'User verification was verified.', '2026-07-30 01:14:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('33', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 01:15:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('34', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 01:15:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('35', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 01:16:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('36', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 01:16:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('37', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 01:17:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('38', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 01:17:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('39', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 13:55:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('40', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 13:58:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('41', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:16:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('42', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:17:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('43', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:17:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('44', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:18:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('45', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:23:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('46', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:27:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('47', '11', 'kenneth', 'staff', 'request_approved', 'REQ-2026-006 was approved by staff.', '2026-07-30 14:44:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('48', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 14:44:32');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('49', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:44:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('50', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:44:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('51', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:45:31');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('52', '11', 'kenneth', 'staff', 'request_rejected', 'REQ-2026-007 was rejected by staff.', '2026-07-30 14:45:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('53', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 14:46:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('54', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 14:46:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('55', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 14:47:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('56', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 14:47:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('57', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:47:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('58', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:47:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('59', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:47:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('60', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:48:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('61', '11', 'kenneth', 'staff', 'request_rejected', 'REQ-2026-012 was rejected by staff.', '2026-07-30 14:48:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('62', '11', 'kenneth', 'staff', 'request_approved', 'REQ-2026-011 was approved by staff.', '2026-07-30 14:48:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('63', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:48:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('64', '10', 'admin1', 'admin', 'request_approved', 'REQ-2026-010 was approved by admin.', '2026-07-30 14:49:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('65', '10', 'admin1', 'admin', 'request_rejected', 'REQ-2026-009 was rejected by admin.', '2026-07-30 14:49:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('66', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 15:03:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('67', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 15:03:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('68', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 15:04:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('69', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 15:04:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('70', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 15:04:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('71', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 15:05:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('72', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 15:05:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('73', '11', 'kenneth', 'staff', 'request_rejected', 'REQ-2026-017 was rejected by staff.', '2026-07-30 15:05:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('74', '11', 'kenneth', 'staff', 'request_approved', 'REQ-2026-016 was approved by staff.', '2026-07-30 15:05:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('75', '11', 'kenneth', 'staff', 'request_released', 'REQ-2026-016 was released by staff.', '2026-07-30 15:06:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('76', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 15:06:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('77', '10', 'admin1', 'admin', 'request_rejected', 'REQ-2026-015 was rejected by admin.', '2026-07-30 15:07:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('78', '10', 'admin1', 'admin', 'request_approved', 'REQ-2026-014 was approved by admin.', '2026-07-30 15:07:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('79', '10', 'admin1', 'admin', 'request_released', 'REQ-2026-014 was released by admin.', '2026-07-30 15:07:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('80', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:18:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('81', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 21:27:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('82', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:27:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('83', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:33:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('84', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 21:34:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('85', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 21:34:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('86', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:35:30');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('87', '0', 'tbag', 'resident', 'registration_submitted', 'A new resident account was registered.', '2026-07-30 21:40:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('88', '13', 'tbag', 'resident', 'login', 'User logged in to the system', '2026-07-30 21:41:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('89', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:41:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('90', '10', 'admin1', 'admin', 'user_created', 'Admin created a ADMIN account for admin2.', '2026-07-30 21:48:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('91', '10', 'admin1', 'admin', 'user_deleted', 'Admin deleted user account #7.', '2026-07-30 21:57:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('92', '10', 'admin1', 'admin', 'user_deleted', 'Admin deleted user account #4.', '2026-07-30 21:57:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('93', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 21:58:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('94', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:58:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('95', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 22:05:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('96', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:07:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('97', '10', 'admin1', 'admin', 'user_updated', 'Admin updated user account #14.', '2026-07-30 22:29:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('98', '10', 'admin1', 'admin', 'user_updated', 'Admin updated user account: Daniel Padilla (username: daniel, role: Staff).', '2026-07-30 22:44:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('99', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:45:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('100', '14', 'joshua', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:45:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('101', '14', 'joshua', 'admin', 'user_updated', 'Admin updated user account: Kenneth Tarroza (username: michael, role: Resident).', '2026-07-30 22:46:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('102', '14', 'joshua', 'admin', 'user_updated', 'Admin updated user account: Kenneth Tarroza (username: michael, role: Resident).', '2026-07-30 22:47:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('103', '12', 'michael', 'resident', 'login', 'User logged in to the system', '2026-07-30 22:49:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('104', '14', 'joshua', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:50:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('105', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Theodor Bagwell (username: tbag, role: Resident).', '2026-07-30 22:56:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('106', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Michael Scofield (username: michael, role: Resident).', '2026-07-30 22:56:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('107', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Daniel Padilla (username: daniel, role: Staff).', '2026-07-30 22:56:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('108', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: admin1 (username: admin1, role: Admin).', '2026-07-30 22:56:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('109', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: mig1259 (username: mig1259, role: Staff).', '2026-07-30 22:56:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('110', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Miguel Rivera (username: tenderfoot1, role: Resident).', '2026-07-30 22:56:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('111', '14', 'joshua', 'admin', 'request_rejected', 'Admin rejected document request: REQ-2026-013 (Certificate of Indigency).', '2026-07-30 22:56:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('112', '14', 'joshua', 'admin', 'request_released', 'Admin released document request: REQ-2026-010 (Certificate of Residency).', '2026-07-30 22:56:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('113', '14', 'joshua', 'admin', 'request_released', 'Admin released document request: REQ-2026-011 (Certificate of Residency).', '2026-07-30 22:56:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('114', '14', 'joshua', 'admin', 'user_created', 'Admin created user account: Kenneth Tarroza (username: nethhh, role: Admin).', '2026-07-30 22:58:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('115', '14', 'joshua', 'admin', 'user_created', 'Admin created user account: Michael Scofield (username: michael, role: Staff).', '2026-07-30 22:59:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('116', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:00:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('117', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:00:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('118', '16', 'michael', 'staff', 'request_rejected', 'Staff rejected document request: REQ-2026-008 (Certificate of Indigency).', '2026-07-30 23:01:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('119', '17', 'fernando', 'resident', 'registration_submitted', 'Resident registered account: Fernando Sucre (username: fernando, role: Resident). Pending admin verification.', '2026-07-30 23:02:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('120', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:02:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('121', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:02:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('122', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:03:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('123', '15', 'nethhh', 'admin', 'user_deleted', 'Admin deleted user account: Joshua Garcia (username: joshua, role: Admin).', '2026-07-30 23:03:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('124', '15', 'nethhh', 'admin', 'verification_verified', 'Admin set verification status to verified for user account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:03:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('125', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:03:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('126', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-018 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:04:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('127', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-019 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:04:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('128', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-020 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:04:53');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('129', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-021 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:05:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('130', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-022 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:05:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('131', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-023 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:05:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('132', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:05:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('133', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-023 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:06:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('134', '15', 'nethhh', 'admin', 'request_rejected', 'Admin rejected document request: REQ-2026-022 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:06:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('135', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-004 (Certificate of Indigency).', '2026-07-30 23:06:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('136', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-006 (Certificate of Indigency).', '2026-07-30 23:06:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('137', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-021 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:06:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('138', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:07:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('139', '16', 'michael', 'staff', 'request_approved', 'Staff approved document request: REQ-2026-020 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:07:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('140', '16', 'michael', 'staff', 'request_approved', 'Staff approved document request: REQ-2026-019 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:07:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('141', '16', 'michael', 'staff', 'request_rejected', 'Staff rejected document request: REQ-2026-018 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:07:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('142', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:07:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('143', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:08:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('144', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-024 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:08:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('145', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-025 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:08:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('146', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:08:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('147', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-019 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:09:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('148', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:09:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('149', '16', 'michael', 'staff', 'request_released', 'Staff released document request: REQ-2026-020 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:09:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('150', '18', 'alexander', 'resident', 'registration_submitted', 'Resident registered account: Alexander Mahone (username: alexander, role: Resident). Pending admin verification.', '2026-07-30 23:11:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('151', '19', 'lincoln', 'resident', 'registration_submitted', 'Resident registered account: Lincoln Burrows (username: lincoln, role: Resident). Pending admin verification.', '2026-07-30 23:12:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('152', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:12:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('153', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:12:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('154', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:12:50');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('155', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: wfvdwvwe', '2026-07-30 23:13:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('156', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:14:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('157', '19', 'lincoln', 'resident', 'verification_resubmitted', 'Resident resubmitted verification proof for account: Lincoln Burrows (username: lincoln, role: Resident).', '2026-07-30 23:14:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('158', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:14:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('159', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: fewfewvbwe', '2026-07-30 23:15:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('160', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: fewfewvbwe', '2026-07-30 23:15:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('161', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:15:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('162', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:18:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('163', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:22:31');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('164', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:22:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('165', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:23:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('166', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:23:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('167', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:23:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('168', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:24:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('169', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: wqfwevwev', '2026-07-30 23:24:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('170', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:29:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('171', '19', 'lincoln', 'resident', 'verification_resubmitted', 'Resident resubmitted verification proof for account: Lincoln Burrows (username: lincoln, role: Resident).', '2026-07-30 23:30:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('172', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:30:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('173', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-025 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-31 00:01:03');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('174', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-31 00:01:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('175', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-026 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-31 00:01:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('176', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-31 00:01:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('177', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:24:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('178', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:38:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('179', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:39:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('180', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:58:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('181', '0', 'Guest', 'resident', 'complaint_submitted', 'Complaint submitted: CMP-0001.', '2026-07-31 16:09:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('182', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 16:09:50');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('183', '16', 'michael', 'staff', 'complaint_done', 'Staff marked complaint CMP-0001 as done.', '2026-07-31 16:15:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('184', '16', 'michael', 'staff', 'complaint_pending', 'Staff marked complaint CMP-0001 as pending.', '2026-07-31 16:15:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('185', '16', 'michael', 'staff', 'complaint_done', 'Staff marked complaint CMP-0001 as done.', '2026-07-31 16:15:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('186', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-31 16:16:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('187', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-31 16:16:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('188', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 20:42:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('189', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 20:56:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('190', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 21:00:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('191', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:01:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('192', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:02:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('193', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:13:31');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('194', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:16:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('195', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 21:18:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('196', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:18:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('197', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 21:27:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('198', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:27:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('199', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 21:27:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('200', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 21:27:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('201', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 21:35:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('202', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:35:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('203', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 21:39:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('204', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:42:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('205', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 21:42:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('206', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 21:42:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('207', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:00:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('208', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:00:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('209', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:00:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('210', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:01:05');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('211', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:06:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('212', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:06:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('213', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:13:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('214', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:13:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('215', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:21:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('216', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:22:03');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('217', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:31:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('218', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:31:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('219', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:32:20');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('220', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:32:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('221', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:40:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('222', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:40:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('223', '15', 'nethhh', 'admin', 'verification_verified', 'Admin set verification status to verified for user account: Alexander Mahone (username: alexander, role: Resident).', '2026-08-02 22:40:32');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('224', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:40:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('225', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:40:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('226', '18', 'alexander', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-027 (Certificate of Indigency) for account: Alexander Mahone (username: alexander, role: Resident).', '2026-08-02 22:40:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('227', '18', 'alexander', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:41:03');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('228', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:41:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('229', '16', 'michael', 'staff', 'request_approved', 'Staff approved document request: REQ-2026-027 (Certificate of Indigency) for resident Alexander Mahone (username: alexander).', '2026-08-02 22:41:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('230', '16', 'michael', 'staff', 'request_released', 'Staff released document request: REQ-2026-027 (Certificate of Indigency) for resident Alexander Mahone (username: alexander).', '2026-08-02 22:46:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('231', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:46:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('232', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:46:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('233', '18', 'alexander', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:46:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('234', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:47:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('235', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:57:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('236', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:57:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('237', '18', 'alexander', 'resident', 'logout', 'User logged out of the system', '2026-08-02 23:01:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('238', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 23:01:53');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('239', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 23:02:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('240', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-08-19 21:46:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('241', '19', 'lincoln', 'resident', 'logout', 'User logged out of the system', '2026-08-19 21:47:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('242', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-19 21:48:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('243', '16', 'michael', 'staff', 'certificate_printed', 'Staff printed sample certificate preview for REQ-2026-025 (Certificate of Residency) for Fernando Sucre.', '2026-08-19 21:48:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('244', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-19 21:49:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('245', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-19 21:49:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('246', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-19 21:52:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('247', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-23 22:21:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('248', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-23 22:22:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('249', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-23 22:22:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('250', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-23 22:23:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('251', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 15:05:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('252', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 15:05:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('253', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 15:05:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('254', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 15:05:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('255', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:06:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('256', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:23:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('257', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:24:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('258', '15', 'nethhh', 'admin', 'request_printed', 'Admin printed document request: REQ-2026-025 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-08-24 15:37:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('259', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:37:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('260', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:39:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('261', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:46:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('262', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 15:46:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('263', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 15:47:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('264', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 15:47:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('265', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 15:47:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('266', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:50:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('267', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:52:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('268', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:53:06');

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `complaints`;
CREATE TABLE `complaints` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `attachment_name` varchar(255) DEFAULT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `status` enum('pending','done') NOT NULL DEFAULT 'pending',
  `completed_by` int(11) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`complaint_id`),
  KEY `idx_complaints_status_created` (`status`,`created_at`),
  KEY `idx_complaints_completed_by` (`completed_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `complaints` (`complaint_id`, `categories`, `location`, `description`, `attachment_name`, `attachment_path`, `status`, `completed_by`, `completed_at`, `created_at`, `updated_at`) VALUES ('1', 'Draining / Flooding', 'rwenvierv', 'erberbcdbvebrf', 'cat hitler.jpg', 'uploads/complaints/complaint_6a6c583fd8c391.76754598_cat_hitler.jpg', 'done', '16', '2026-07-31 16:15:16', '2026-07-31 16:09:35', '2026-07-31 16:15:16');

DROP TABLE IF EXISTS `document_request_files`;
CREATE TABLE `document_request_files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`file_id`),
  KEY `idx_document_request_files_request_id` (`request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('1', '1', 'cat hitler.jpg', 'uploads/requirements/6a3bd3f706adf_cathitler.jpg', '2026-06-24 20:56:23');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('2', '2', 'cat hitler.jpg', 'uploads/requirements/6a3ea56de6552_cathitler.jpg', '2026-06-27 00:14:37');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('3', '3', 'cat hitler.jpg', 'uploads/requirements/6a3ea5d8928b7_cathitler.jpg', '2026-06-27 00:16:24');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('4', '4', 'cat hitler.jpg', 'uploads/requirements/6a3ea68aa5283_cathitler.jpg', '2026-06-27 00:19:22');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('5', '5', 'cat hitler.jpg', 'uploads/requirements/6a3ea69a3d7a0_cathitler.jpg', '2026-06-27 00:19:38');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('6', '6', 'cat hitler.jpg', 'uploads/requirements/6a6a3545d7596_cathitler.jpg', '2026-07-30 01:15:49');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('7', '7', 'cat hitler.jpg', 'uploads/requirements/6a6af2db09528_cathitler.jpg', '2026-07-30 14:44:43');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('8', '8', 'cat hitler.jpg', 'uploads/requirements/6a6af35793b27_cathitler.jpg', '2026-07-30 14:46:47');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('9', '9', 'cat hitler.jpg', 'uploads/requirements/6a6af37be7880_cathitler.jpg', '2026-07-30 14:47:23');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('10', '10', 'cat hitler.jpg', 'uploads/requirements/6a6af38852469_cathitler.jpg', '2026-07-30 14:47:36');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('11', '11', 'cat hitler.jpg', 'uploads/requirements/6a6af39155920_cathitler.jpg', '2026-07-30 14:47:45');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('12', '12', 'cat hitler.jpg', 'uploads/requirements/6a6af39a71812_cathitler.jpg', '2026-07-30 14:47:54');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('13', '13', 'cat hitler.jpg', 'uploads/requirements/6a6af757533a7_cathitler.jpg', '2026-07-30 15:03:51');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('14', '14', 'cat hitler.jpg', 'uploads/requirements/6a6af773cb222_cathitler.jpg', '2026-07-30 15:04:19');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('15', '15', 'cat hitler.jpg', 'uploads/requirements/6a6af7914b588_cathitler.jpg', '2026-07-30 15:04:49');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('16', '16', 'cat hitler.jpg', 'uploads/requirements/6a6af79ba6374_cathitler.jpg', '2026-07-30 15:04:59');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('17', '17', 'cat hitler.jpg', 'uploads/requirements/6a6af7a744d13_cathitler.jpg', '2026-07-30 15:05:11');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('18', '18', 'cat hitler.jpg', 'uploads/requirements/6a6b67f82d1e6_cathitler.jpg', '2026-07-30 23:04:24');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('19', '19', 'cat hitler.jpg', 'uploads/requirements/6a6b680682972_cathitler.jpg', '2026-07-30 23:04:38');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('20', '20', 'cat hitler.jpg', 'uploads/requirements/6a6b68153e2eb_cathitler.jpg', '2026-07-30 23:04:53');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('21', '21', 'cat hitler.jpg', 'uploads/requirements/6a6b682034266_cathitler.jpg', '2026-07-30 23:05:04');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('22', '22', 'cat hitler.jpg', 'uploads/requirements/6a6b682cd0f96_cathitler.jpg', '2026-07-30 23:05:16');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('23', '23', 'cat hitler.jpg', 'uploads/requirements/6a6b683646f8b_cathitler.jpg', '2026-07-30 23:05:26');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('24', '24', 'cat hitler.jpg', 'uploads/requirements/6a6b68f381df9_cathitler.jpg', '2026-07-30 23:08:35');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('25', '25', 'cat hitler.jpg', 'uploads/requirements/6a6b68fc7b758_cathitler.jpg', '2026-07-30 23:08:44');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('26', '26', 'cat hitler.jpg', 'uploads/requirements/6a6b755e7b569_cathitler.jpg', '2026-07-31 00:01:34');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('27', '27', 'cat hitler.jpg', 'uploads/requirements/6a6f56f45aa3a_cathitler.jpg', '2026-08-02 22:40:52');

DROP TABLE IF EXISTS `document_requests`;
CREATE TABLE `document_requests` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_number` varchar(30) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `document_type` varchar(100) NOT NULL,
  `purpose` text NOT NULL,
  `status` enum('pending','approved','printed','released','rejected') NOT NULL DEFAULT 'pending',
  `generated_file_path` varchar(255) DEFAULT NULL,
  `admin_remarks` text DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `date_submitted` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('1', 'REQ-2026-001', '6', 'Certificate of Residency', 'sample', 'rejected', NULL, NULL, '9', '2026-06-24 22:08:17', '2026-06-24 20:56:23', '2026-06-24 22:08:17');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('2', 'REQ-2026-002', '10', 'Certificate of Residency', 'purpose', 'released', NULL, NULL, '9', '2026-06-27 00:15:54', '2026-06-27 00:14:37', '2026-06-27 00:15:54');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('3', 'REQ-2026-003', '10', 'Certificate of Residency', 'purpose', 'released', NULL, NULL, '7', '2026-07-29 20:47:02', '2026-06-27 00:16:24', '2026-07-29 20:47:02');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('4', 'REQ-2026-004', '10', 'Certificate of Indigency', 'purpose', 'released', NULL, NULL, '15', '2026-07-30 23:06:28', '2026-06-27 00:19:22', '2026-07-30 23:06:28');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('5', 'REQ-2026-005', '10', 'Certificate of Indigency', 'purpose', 'rejected', NULL, 'Invalid requirement', '9', '2026-06-27 00:23:26', '2026-06-27 00:19:38', '2026-06-27 00:23:26');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('6', 'REQ-2026-006', '12', 'Certificate of Indigency', 'sadwqf', 'released', 'uploads/generated_documents/REQ-2026-000_1785345349.pdf', NULL, '15', '2026-07-30 23:06:35', '2026-07-30 01:15:49', '2026-07-30 23:06:35');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('7', 'REQ-2026-007', '12', 'Certificate of Residency', 'awdwvdsv', 'rejected', 'uploads/generated_documents/REQ-2026-007_1785393883.pdf', 'sawevewv', '11', '2026-07-30 14:45:42', '2026-07-30 14:44:43', '2026-07-30 14:45:42');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('8', 'REQ-2026-008', '12', 'Certificate of Indigency', 'awfwqfwe', 'rejected', 'uploads/generated_documents/REQ-2026-008_1785394007.pdf', 'wefewvwv', '16', '2026-07-30 23:01:07', '2026-07-30 14:46:47', '2026-07-30 23:01:07');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('9', 'REQ-2026-009', '12', 'Certificate of Indigency', 'ewfewvwe', 'rejected', 'uploads/generated_documents/REQ-2026-009_1785394043.pdf', 'wefwef', '10', '2026-07-30 14:49:42', '2026-07-30 14:47:23', '2026-07-30 14:49:42');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('10', 'REQ-2026-010', '12', 'Certificate of Residency', 'cagerwvbreb', 'released', 'uploads/generated_documents/REQ-2026-010_1785394056.pdf', NULL, '14', '2026-07-30 22:56:51', '2026-07-30 14:47:36', '2026-07-30 22:56:51');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('11', 'REQ-2026-011', '12', 'Certificate of Residency', 'cwevewvwe', 'released', 'uploads/generated_documents/REQ-2026-011_1785394065.pdf', NULL, '14', '2026-07-30 22:56:52', '2026-07-30 14:47:45', '2026-07-30 22:56:52');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('12', 'REQ-2026-012', '12', 'Certificate of Residency', 'ascewgvew', 'rejected', 'uploads/generated_documents/REQ-2026-012_1785394074.pdf', 'wefwevwe', '11', '2026-07-30 14:48:08', '2026-07-30 14:47:54', '2026-07-30 14:48:08');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('13', 'REQ-2026-013', '12', 'Certificate of Indigency', 'fwqfgewg', 'rejected', 'uploads/generated_documents/REQ-2026-013_1785395031.pdf', 'dqwfwqf', '14', '2026-07-30 22:56:43', '2026-07-30 15:03:51', '2026-07-30 22:56:43');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('14', 'REQ-2026-014', '12', 'Certificate of Residency', 'qwefwegwe', 'released', 'uploads/generated_documents/REQ-2026-014_1785395059.pdf', NULL, '10', '2026-07-30 15:07:12', '2026-07-30 15:04:19', '2026-07-30 15:07:12');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('15', 'REQ-2026-015', '12', 'Certificate of Residency', 'fwqfwqf', 'rejected', 'uploads/generated_documents/REQ-2026-015_1785395089.pdf', 'fwqefewf', '10', '2026-07-30 15:07:04', '2026-07-30 15:04:49', '2026-07-30 15:07:04');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('16', 'REQ-2026-016', '12', 'Certificate of Indigency', 'wefewggewg', 'released', 'uploads/generated_documents/REQ-2026-016_1785395099.pdf', NULL, '11', '2026-07-30 15:06:01', '2026-07-30 15:04:59', '2026-07-30 15:06:01');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('17', 'REQ-2026-017', '12', 'Certificate of Indigency', 'fewqfwebwe', 'rejected', 'uploads/generated_documents/REQ-2026-017_1785395111.pdf', 'wefsvewg', '11', '2026-07-30 15:05:33', '2026-07-30 15:05:11', '2026-07-30 15:05:33');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('18', 'REQ-2026-018', '17', 'Certificate of Indigency', 'wefew', 'rejected', 'uploads/generated_documents/REQ-2026-018_1785423864.pdf', 'ewfewvwv', '16', '2026-07-30 23:07:34', '2026-07-30 23:04:24', '2026-07-30 23:07:34');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('19', 'REQ-2026-019', '17', 'Certificate of Residency', 'cwefew', 'released', 'uploads/generated_documents/REQ-2026-019_1785423878.pdf', NULL, '15', '2026-07-30 23:09:04', '2026-07-30 23:04:38', '2026-07-30 23:09:04');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('20', 'REQ-2026-020', '17', 'Certificate of Indigency', 'cwerfwe', 'released', 'uploads/generated_documents/REQ-2026-020_1785423893.pdf', NULL, '16', '2026-07-30 23:09:22', '2026-07-30 23:04:53', '2026-07-30 23:09:22');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('21', 'REQ-2026-021', '17', 'Certificate of Residency', 'cascewv', 'approved', 'uploads/generated_documents/REQ-2026-021_1785423904.pdf', NULL, '15', '2026-07-30 23:06:57', '2026-07-30 23:05:04', '2026-07-30 23:06:57');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('22', 'REQ-2026-022', '17', 'Certificate of Indigency', 'casfewvfdbv', 'rejected', 'uploads/generated_documents/REQ-2026-022_1785423916.pdf', 'wefvewvew', '15', '2026-07-30 23:06:10', '2026-07-30 23:05:16', '2026-07-30 23:06:10');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('23', 'REQ-2026-023', '17', 'Certificate of Residency', 'sacregrebc', 'approved', 'uploads/generated_documents/REQ-2026-023_1785423926.pdf', NULL, '15', '2026-07-30 23:06:00', '2026-07-30 23:05:26', '2026-07-30 23:06:00');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('24', 'REQ-2026-024', '17', 'Certificate of Indigency', 'ewfvewvwe', 'pending', 'uploads/generated_documents/REQ-2026-024_1785424115.pdf', NULL, NULL, NULL, '2026-07-30 23:08:35', '2026-07-30 23:08:35');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('25', 'REQ-2026-025', '17', 'Certificate of Residency', 'ascngfrt', 'printed', 'uploads/generated_documents/REQ-2026-025_1785424124.pdf', NULL, '15', '2026-08-24 15:37:19', '2026-07-30 23:08:44', '2026-08-24 15:37:19');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('26', 'REQ-2026-026', '17', 'Certificate of Indigency', 'sacewgvew', 'pending', 'uploads/generated_documents/REQ-2026-026_1785427294.pdf', NULL, NULL, NULL, '2026-07-31 00:01:34', '2026-07-31 00:01:34');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('27', 'REQ-2026-027', '18', 'Certificate of Indigency', 'asdewqcvew', 'released', 'uploads/generated_documents/REQ-2026-027_1785681652.pdf', NULL, '16', '2026-08-02 22:46:16', '2026-08-02 22:40:52', '2026-08-02 22:46:16');

DROP TABLE IF EXISTS `document_templates`;
CREATE TABLE `document_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `usage_count` int(11) NOT NULL DEFAULT 0,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `template_content` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `requests`;
CREATE TABLE `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `doc_type` varchar(255) NOT NULL,
  `date_submitted` datetime NOT NULL,
  `date_requested` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'processing',
  `purpose` text DEFAULT NULL,
  `files` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `requests` (`id`, `user_id`, `doc_type`, `date_submitted`, `date_requested`, `status`, `purpose`, `files`, `created_at`, `updated_at`) VALUES ('1', '4', 'Certificate of Indigency', '2026-05-09 11:38:53', NULL, 'processing', 'zzz', '{\"government_id\":\"69ff00adc1c82_picka.jpg\"}', '2026-05-09 17:38:53', '2026-05-09 17:38:53');

DROP TABLE IF EXISTS `residents`;
CREATE TABLE `residents` (
  `residentId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `middleName` varchar(100) DEFAULT NULL,
  `suffix` varchar(50) DEFAULT NULL,
  `dateOfBirth` date NOT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `civilStatus` enum('Single','Married','Widowed','Separated') NOT NULL,
  `fullAddress` text NOT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL,
  `emailAddress` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`residentId`),
  UNIQUE KEY `phoneNumber` (`phoneNumber`),
  UNIQUE KEY `emailAddress` (`emailAddress`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('4', 'Miguel', 'Rivera', 'N/A', 'N/A', '2001-09-29', 'Male', 'Single', '12333 street', '09300659494', 'mglrvr55555@gmail.com', '2026-05-09 13:57:16', '2026-05-09 13:57:16');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('5', 'admin', 'admin', 'N/A', 'N/A', '2001-09-12', 'Male', 'Single', '1212123 street', '09121232211', 'admin@gmail.com', '2026-05-09 18:30:00', '2026-05-09 18:30:00');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('8', 'Miguel', 'Rivera', 'Lopez', NULL, '2001-09-19', 'Male', 'Single', 'quezon city', '09206899729', 'midguel7@gmail.com', '2026-07-29 19:47:21', '2026-07-29 19:47:21');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('9', 'Michael', 'Scofield', NULL, NULL, '2004-11-22', 'Male', 'Single', 'San Mateo, Rizal', '09143827901', 'michaelscofield@gmail.com', '2026-07-30 01:11:29', '2026-07-30 22:54:21');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('10', 'Theodor', 'Bagwell', NULL, NULL, '1980-10-01', 'Male', 'Separated', 'San Mateo, Rizal', '09111111111', 'tbag@gmail.com', '2026-07-30 21:40:56', '2026-07-30 21:40:56');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('11', 'Fernando', 'Sucre', NULL, NULL, '1990-01-20', 'Male', 'Married', 'San Mateo, Rizal', '09385003281', 'fernandosucre@gmail.com', '2026-07-30 23:02:22', '2026-07-30 23:02:22');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('12', 'Alexander', 'Mahone', NULL, NULL, '1980-05-05', 'Male', 'Separated', 'San Mateo, Rizal', '09839902141', 'alexmahone@gmail.com', '2026-07-30 23:11:07', '2026-07-30 23:11:07');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('13', 'Lincoln', 'Burrows', NULL, NULL, '1980-04-11', 'Male', 'Single', 'San Mateo, Rizal', '09469480012', 'lincolnburrows@gmail.com', '2026-07-30 23:12:15', '2026-07-30 23:12:15');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `contact_email` varchar(150) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('resident','admin','staff') NOT NULL,
  `residentId` int(11) DEFAULT NULL,
  `account_status` varchar(20) NOT NULL DEFAULT 'pending',
  `verification_proof` varchar(255) DEFAULT NULL,
  `verification_rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `avatar_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username` (`username`),
  KEY `residentId` (`residentId`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`residentId`) REFERENCES `residents` (`residentId`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('15', 'nethhh', 'Kenneth', 'Tarroza', 'kennethtarroza22@gmail.com', '09129048371', '$2y$10$iUQ6/4XVeAhimt96JiAIIeQkZKGQ.PpUzIrfb6vzzSMBOQzQ4N/qi', 'admin', NULL, 'verified', NULL, NULL, '2026-07-30 22:58:35', '2026-07-30 22:58:35', NULL);
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('16', 'michael', 'Michael', 'Scofield', 'michaelscofield@gmail.com', '09139945021', '$2y$10$0lBl.bqOqTmW64/UQ5cA6uWBLH/sy4dlfv9lFwvCkbW57cNUmg0zq', 'staff', NULL, 'verified', NULL, NULL, '2026-07-30 22:59:37', '2026-07-30 22:59:37', NULL);
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('17', 'fernando', NULL, NULL, NULL, NULL, '$2y$10$iNCt.PQKUyfaK0xlrHSeeu9.cODzEr6Co7i0gM4z.34vW7h8zdAIi', 'resident', '11', 'verified', 'uploads/verification_proofs/proof_6a6b677eb6e284.63244289_cathitler.jpg', NULL, '2026-07-30 23:02:22', '2026-08-02 21:35:53', '/updated/uploads/avatars/avatar_17_1785677753.jpg');
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('18', 'alexander', NULL, NULL, NULL, NULL, '$2y$10$Y9TXXYY4/mSHeU7JR4u6m.UuiIeZsU8NIhSNcLfpnt4NUHZLSxlvC', 'resident', '12', 'verified', 'uploads/verification_proofs/proof_6a6b698b1f8ba5.74669941_cathitler.jpg', NULL, '2026-07-30 23:11:07', '2026-08-02 22:40:32', NULL);
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('19', 'lincoln', NULL, NULL, NULL, NULL, '$2y$10$Y4YfAoAZKLvbn.lqpYUPsOyTEtjYY7PVsDc2qz0U6ZAqvZTEfJja.', 'resident', '13', 'pending', 'uploads/verification_proofs/proof_6a6b6dff8b0f13.06839829_cathitler.jpg', NULL, '2026-07-30 23:12:15', '2026-07-30 23:30:07', NULL);

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;

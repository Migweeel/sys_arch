<?php



// SANITIZE DATA
function clean($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}


// VALIDATION
function emptyField($username, $password, $confirmPassword, $firstName, $lastName, $birthdate, $sex, $address, $civilStatus, $phoneNumber, $email) {
    if(empty($username) || empty($password) || empty($confirmPassword) || empty($firstName) || empty($lastName) || empty($birthdate) 
        || empty($sex) || empty($address) || empty($civilStatus) || empty($phoneNumber) || empty($email)) {
        
        return true;    
    }

    return false;
}


function invalidNamePattern($firstName, $lastName) {
    $namePattern = "/^[a-zA-Z\sñÑ.]+$/";

    if ((!empty($firstName) || !empty($lastName)) && (!preg_match($namePattern, $firstName) || !preg_match($namePattern, $lastName))) {
        return true;
    }

    return false;

}


function invalidSex($sex) {
    $validSex = ['Male', 'Female'];

    if (!empty($sex) && !in_array($sex, $validSex)) {
        return true;
    }

    return false;
}


function invalidCivilStatus($civilStatus) {
    $validCivilStatus = ['Single', 'Married', 'Widowed', 'Separated'];

    if (!empty($civilStatus) && !in_array($civilStatus, $validCivilStatus)) {
        return true;
    }

    return false;
}


function passwordNotMatch($password, $confirmPassword) {
    if ($password !== $confirmPassword) {
        return true;
    }

    return false;
}


function passwordLength($password) {
    if (!empty($password) && strlen($password) < 8) {
        return true;
    }

    return false;
}


function invalidPhoneNo($phoneNumber) {
    if (!empty($phoneNumber) && !preg_match('/^09[0-9]{9}$/', $phoneNumber)) {
        return true;
    }

    return false;
}


function usernameTaken($conn, $username) {
    $stmt = mysqli_prepare($conn, "SELECT username FROM users WHERE LOWER(username) = LOWER(?) LIMIT 1");
    
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        return true;
    }

    return false;
}


function emailRegistered($conn, $email) {
    $stmt = mysqli_prepare($conn, "SELECT emailAddress FROM residents WHERE emailAddress = ? LIMIT 1");
    
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    return mysqli_num_rows($result) > 0;
}


function phoneRegistered($conn, $phoneNumber) {
    $stmt = mysqli_prepare($conn, "SELECT phoneNumber FROM residents WHERE phoneNumber = ? LIMIT 1");
    
    mysqli_stmt_bind_param($stmt, "s", $phoneNumber);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    return mysqli_num_rows($result) > 0;
}

function userColumnExists($conn, $columnName) {
    static $cache = [];

    if (!$conn) {
        return false;
    }

    if (isset($cache[$columnName])) {
        return $cache[$columnName];
    }

    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS column_count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = ?");
    if (!$stmt) {
        $cache[$columnName] = false;
        return false;
    }

    mysqli_stmt_bind_param($stmt, "s", $columnName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    $cache[$columnName] = $row && (int) $row['column_count'] > 0;
    return $cache[$columnName];
}

function userAccountLogLabel($conn, $userId) {
    $userId = (int) $userId;
    if (!$conn || $userId <= 0) {
        return 'Unknown account';
    }

    $firstNameSelect = userColumnExists($conn, 'first_name') ? 'u.first_name AS accountFirstName' : 'NULL AS accountFirstName';
    $lastNameSelect = userColumnExists($conn, 'last_name') ? 'u.last_name AS accountLastName' : 'NULL AS accountLastName';

    $sql = "SELECT
            u.username,
            u.role,
            $firstNameSelect,
            $lastNameSelect,
            res.firstName AS residentFirstName,
            res.lastName AS residentLastName
        FROM users u
        LEFT JOIN residents res ON u.residentId = res.residentId
        WHERE u.userId = ?
        LIMIT 1";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return 'User account #' . $userId;
    }

    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    if (!$user) {
        return 'User account #' . $userId;
    }

    $residentName = trim((string) ($user['residentFirstName'] ?? '') . ' ' . (string) ($user['residentLastName'] ?? ''));
    $accountName = trim((string) ($user['accountFirstName'] ?? '') . ' ' . (string) ($user['accountLastName'] ?? ''));
    $displayName = $residentName ?: ($accountName ?: ($user['username'] ?? ('User #' . $userId)));
    $username = trim((string) ($user['username'] ?? ''));
    $role = ucfirst((string) ($user['role'] ?? 'user'));

    $details = [];
    if ($username !== '') {
        $details[] = 'username: ' . $username;
    }
    if ($role !== '') {
        $details[] = 'role: ' . $role;
    }

    return $displayName . ($details ? ' (' . implode(', ', $details) . ')' : '');
}

function formatActivityLogDescription($conn, $description) {
    $description = trim((string) $description);
    if ($description === '') {
        return 'System activity';
    }

    if (preg_match('/\buser account #(\d+)\b/i', $description, $matches)) {
        $userId = (int) $matches[1];
        $userLabel = userAccountLogLabel($conn, $userId);

        if (stripos($userLabel, 'User account #') !== 0) {
            return preg_replace('/\buser account #' . preg_quote((string) $userId, '/') . '\b/i', 'user account: ' . $userLabel, $description, 1);
        }
    }

    return $description;
}


function invalidBirthdate($birthdate) {
    if (empty($birthdate)) return true;

    $dateInput = strtotime($birthdate);
    $currentDate = time();
    $minYear = strtotime("1900-01-01");

    if ($dateInput > $currentDate || $dateInput < $minYear) {
        return true;
    }
    
    return false;
}

function buildResidentDocumentData($residentData, $requestData) {
    $fullName = trim((string) ($residentData['first_name'] ?? '') . ' ' . (string) ($residentData['middle_name'] ?? '') . ' ' . (string) ($residentData['last_name'] ?? '') . ' ' . (string) ($residentData['suffix'] ?? ''));
    $fullName = preg_replace('/\s+/', ' ', $fullName);
    $fullName = trim($fullName);

    $address = trim((string) ($residentData['address'] ?? '') . ' ' . (string) ($residentData['full_address'] ?? ''));
    $address = preg_replace('/\s+/', ' ', $address);

    $birthdate = trim((string) ($residentData['birthdate'] ?? ''));
    $age = '';
    if ($birthdate !== '') {
        try {
            $dob = new DateTime($birthdate);
            $now = new DateTime('today');
            $age = (string) $now->diff($dob)->y;
        } catch (Exception $e) {
            $age = '';
        }
    }

    return [
        'name' => $fullName ?: ($residentData['full_name'] ?? ''),
        'full_name' => $fullName ?: ($residentData['full_name'] ?? ''),
        'first_name' => $residentData['first_name'] ?? '',
        'last_name' => $residentData['last_name'] ?? '',
        'middle_name' => $residentData['middle_name'] ?? '',
        'suffix' => $residentData['suffix'] ?? '',
        'age' => $age,
        'address' => $address,
        'full_address' => $address,
        'document_type' => $requestData['document_type'] ?? '',
        'purpose' => $requestData['purpose'] ?? '',
        'request_number' => $requestData['request_number'] ?? '',
        'date' => date('F j, Y'),
        'today' => date('F j, Y')
    ];
}

function applyDocumentPlaceholders($content, $data) {
    $replacements = [];
    foreach ($data as $key => $value) {
        $replacements['{{' . $key . '}}'] = (string) $value;
        $replacements['[[' . $key . ']]'] = (string) $value;
        $replacements['{' . $key . '}'] = (string) $value;
    }

    return strtr((string) $content, $replacements);
}

function escapePdfText($text) {
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], (string) $text);
}

function generateFilledDocumentPdf($templateContent, $outputDir, $data, $requestNumber) {
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0777, true);
    }

    $filledText = applyDocumentPlaceholders((string) $templateContent, $data);
    if (trim($filledText) === '') {
        $filledText = "Barangay Document\n\nName: " . ($data['name'] ?: 'Resident') . "\nAge: " . ($data['age'] ?: '') . "\nAddress: " . ($data['address'] ?: '');
    }

    $lines = preg_split('/\r\n|\r|\n/', $filledText);
    $lines = array_values(array_filter($lines, static function ($line) {
        return trim($line) !== '';
    }));
    if ($lines === []) {
        $lines = ['Barangay Document'];
    }

    $wrappedLines = [];
    foreach ($lines as $line) {
        $wrapped = wordwrap($line, 90, "\n", true);
        $wrappedLines = array_merge($wrappedLines, explode("\n", $wrapped));
    }

    $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', (string) ($requestNumber ?: 'document'));
    $fileName = $safeName . '_' . time() . '.pdf';
    $filePath = rtrim($outputDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $fileName;

    $contentStream = "BT\n/F1 12 Tf\n72 720 Td\n";
    foreach ($wrappedLines as $index => $line) {
        $contentStream .= '(' . escapePdfText($line) . ") Tj\n";
        if ($index < count($wrappedLines) - 1) {
            $contentStream .= "0 -14 Td\n";
        }
    }
    $contentStream .= "ET\n";

    $streamObject = "<< /Length " . strlen($contentStream) . " >>\nstream\n" . $contentStream . "\nendstream";

    $objects = [
        '<< /Type /Catalog /Pages 2 0 R >>',
        '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
        '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
        $streamObject,
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'
    ];

    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $index => $object) {
        $offsets[$index] = strlen($pdf);
        $pdf .= ($index + 1) . " 0 obj\n" . $object . "\nendobj\n";
    }

    $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    foreach ($offsets as $offset) {
        $pdf .= sprintf("%010d 00000 n \n", $offset);
    }
    $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n" . strlen($pdf) . "\n%%EOF\n";

    file_put_contents($filePath, $pdf);

    return 'uploads/generated_documents/' . basename($filePath);
}

function logActivity($conn, $userId, $username, $role, $action, $description) {
    if (!$conn) {
        return false;
    }

    $userId = (int) $userId;
    $username = trim((string) $username);
    $role = strtolower(trim((string) $role));
    $action = strtolower(preg_replace('/[^a-z0-9_]/', '', (string) $action));
    $description = trim((string) $description);

    if ($description === '') {
        $description = ucfirst(str_replace('_', ' ', $action));
    }

    $stmt = mysqli_prepare($conn, "INSERT INTO activity_logs (user_id, username, role, action, description, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "issss", $userId, $username, $role, $action, $description);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    return $result;
}

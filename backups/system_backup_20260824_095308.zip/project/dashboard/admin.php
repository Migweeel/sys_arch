<?php
require_once '../auth/session.php';
require_once '../config/db.php';
require_once '../helpers/functions.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['errors'] = ["Please login to access the admin panel."];
    header("Location: ../pages/loginPage.php");
    exit();
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard/" . $_SESSION['role'] . ".php");
    exit();
}

if ($conn === null) {
    die("Database connection failed. Please check your database configuration and ensure MySQL is running.");
}

$displayName = $_SESSION['username'] ?? 'Admin User';
$activeSection = strtolower($_GET['section'] ?? 'requests');
if (!in_array($activeSection, ['overview', 'pending', 'requests', 'users', 'templates', 'approved', 'archive', 'reports', 'backup', 'activity'], true)) {
    $activeSection = 'requests';
}

$allowedStatuses = ['all', 'approved', 'printed', 'rejected', 'released'];
$statusFilter = strtolower($_GET['status'] ?? 'all');
if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = 'all';
}
$archiveCutoffDays = 90;
$archiveCondition = "r.status IN ('printed', 'released', 'rejected') AND COALESCE(r.reviewed_at, r.date_updated, r.date_submitted) < DATE_SUB(NOW(), INTERVAL $archiveCutoffDays DAY)";

$search = trim($_GET['search'] ?? '');
$userSearch = trim($_GET['user_search'] ?? '');
$roleFilter = strtolower($_GET['role'] ?? 'all');
if (!in_array($roleFilter, ['all', 'admin', 'staff', 'resident'], true)) {
    $roleFilter = 'all';
}
$accountStatusFilter = strtolower($_GET['account_status'] ?? 'all');
if (!in_array($accountStatusFilter, ['all', 'pending', 'verified', 'rejected'], true)) {
    $accountStatusFilter = 'all';
}

$activitySearch = trim($_GET['activity_search'] ?? '');
$highlightUserId = isset($_GET['highlight_user']) ? (int) $_GET['highlight_user'] : 0;
$highlightRequestId = isset($_GET['highlight_request']) ? (int) $_GET['highlight_request'] : 0;

function adminRequestNumber($id, $dateSubmitted) {
    $year = $dateSubmitted ? date('Y', strtotime($dateSubmitted)) : date('Y');
    return 'REQ-' . $year . '-' . str_pad((string) $id, 3, '0', STR_PAD_LEFT);
}

function adminStatusLabel($status) {
    $labels = [
        'pending' => 'Pending',
        'approved' => 'Approved',
        'printed' => 'Printed',
        'rejected' => 'Rejected',
        'released' => 'Released',
    ];

    return $labels[$status] ?? ucfirst((string) $status);
}

function adminStatusClass($status) {
    return $status;
}

function adminStatusMessage($status) {
    $messages = [
        'pending' => 'This request is waiting for review.',
        'approved' => 'This document request has been approved and is ready for printing.',
        'printed' => 'This document has been printed and can now be claimed by the resident during office hours.',
        'released' => 'This document has already been released to the resident.',
        'rejected' => 'This request was rejected. Review the remarks for the reason.',
    ];

    return $messages[strtolower((string) $status)] ?? 'No status message available.';
}

function accountStatusLabel($status) {
    $labels = [
        'pending' => 'For Verification',
        'verified' => 'Verified',
        'rejected' => 'Rejected',
    ];

    return $labels[$status] ?? ucfirst((string) $status);
}

function userDisplayName($user) {
    $residentName = trim(($user['firstName'] ?? '') . ' ' . ($user['lastName'] ?? ''));
    $accountName = trim(($user['accountFirstName'] ?? '') . ' ' . ($user['accountLastName'] ?? ''));
    return $residentName ?: ($accountName ?: ($user['username'] ?? 'Unknown User'));
}

function userTableColumnExists($conn, $columnName) {
    static $cache = [];

    if (isset($cache[$columnName])) {
        return $cache[$columnName];
    }

    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS column_count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = ?");
    if (!$stmt) {
        $cache[$columnName] = false;
        return false;
    }

    mysqli_stmt_bind_param($stmt, "s", $columnName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    $cache[$columnName] = $row && (int) $row['column_count'] > 0;
    return $cache[$columnName];
}

function userColumnSelect($conn, $columnName, $alias) {
    return userTableColumnExists($conn, $columnName)
        ? "u.`$columnName` AS `$alias`"
        : "NULL AS `$alias`";
}

function fetchRequestFiles($conn, $requestId) {
    $files = [];
    $fileStmt = mysqli_prepare($conn, "SELECT file_name, file_path FROM document_request_files WHERE request_id = ? ORDER BY file_id ASC");
    if ($fileStmt) {
        mysqli_stmt_bind_param($fileStmt, "i", $requestId);
        mysqli_stmt_execute($fileStmt);
        $fileResult = mysqli_stmt_get_result($fileStmt);
        while ($fileRow = mysqli_fetch_assoc($fileResult)) {
            $files[] = $fileRow;
        }
        mysqli_stmt_close($fileStmt);
    }

    return $files;
}

if (isset($_SESSION['user_id']) && userTableColumnExists($conn, 'first_name')) {
    $currentNameStmt = mysqli_prepare($conn, "SELECT first_name FROM users WHERE userId = ? LIMIT 1");
    if ($currentNameStmt) {
        $currentUserId = (int) $_SESSION['user_id'];
        mysqli_stmt_bind_param($currentNameStmt, "i", $currentUserId);
        mysqli_stmt_execute($currentNameStmt);
        $currentNameResult = mysqli_stmt_get_result($currentNameStmt);
        if ($currentNameRow = mysqli_fetch_assoc($currentNameResult)) {
            $accountFirstName = trim((string) ($currentNameRow['first_name'] ?? ''));
            if ($accountFirstName !== '') {
                $displayName = $accountFirstName;
                $_SESSION['first_name'] = $accountFirstName;
            }
        }
        mysqli_stmt_close($currentNameStmt);
    }
}

$stats = [
    'total' => 0,
    'pending' => 0,
    'approved' => 0,
    'printed' => 0,
    'released' => 0,
    'rejected' => 0,
    'archive' => 0,
];

$statsSql = "SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count,
    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_count,
    SUM(CASE WHEN status = 'printed' THEN 1 ELSE 0 END) AS printed_count,
    SUM(CASE WHEN status = 'released' THEN 1 ELSE 0 END) AS released_count,
    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_count,
    SUM(CASE WHEN status IN ('printed', 'released', 'rejected') AND COALESCE(reviewed_at, date_updated, date_submitted) < DATE_SUB(NOW(), INTERVAL $archiveCutoffDays DAY) THEN 1 ELSE 0 END) AS archive_count
    FROM document_requests";
$statsResult = mysqli_query($conn, $statsSql);
if ($statsResult && $row = mysqli_fetch_assoc($statsResult)) {
    $stats = [
        'total' => (int) $row['total'],
        'pending' => (int) $row['pending_count'],
        'approved' => (int) $row['approved_count'],
        'printed' => (int) $row['printed_count'],
        'released' => (int) $row['released_count'],
        'rejected' => (int) $row['rejected_count'],
        'archive' => (int) $row['archive_count'],
    ];
}
$historyCount = max(0, $stats['total'] - $stats['pending']);

$where = [];
$params = [];
$types = '';

if ($activeSection === 'pending') {
    $where[] = "r.status = 'pending'";
} elseif ($activeSection === 'archive') {
    $where[] = $archiveCondition;
} elseif ($statusFilter !== 'all') {
    $where[] = "r.status = ?";
    $params[] = $statusFilter;
    $types .= 's';
    $where[] = "NOT ($archiveCondition)";
} else {
    $where[] = "r.status <> 'pending'";
    $where[] = "NOT ($archiveCondition)";
}

if ($search !== '') {
    $where[] = "(r.request_number LIKE ? OR r.document_type LIKE ? OR r.purpose LIKE ? OR u.username LIKE ? OR res.firstName LIKE ? OR res.lastName LIKE ? OR res.emailAddress LIKE ?)";
    $searchTerm = '%' . $search . '%';
    for ($i = 0; $i < 7; $i++) {
        $params[] = $searchTerm;
        $types .= 's';
    }
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$requestsSql = "SELECT
        r.*,
        u.username,
        res.firstName,
        res.lastName,
        res.emailAddress,
        res.phoneNumber,
        res.fullAddress
    FROM document_requests r
    LEFT JOIN users u ON r.user_id = u.userId
    LEFT JOIN residents res ON u.residentId = res.residentId
    $whereSql
    ORDER BY COALESCE(r.reviewed_at, r.date_updated, r.date_submitted) DESC, r.request_id DESC";

$stmt = mysqli_prepare($conn, $requestsSql);
if ($stmt && $types !== '') {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

$requests = [];
if ($stmt && mysqli_stmt_execute($stmt)) {
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row;
    }
    mysqli_stmt_close($stmt);
}

$approvedWhere = ["r.status IN ('approved', 'printed')"];
$approvedParams = [];
$approvedTypes = '';
if ($search !== '') {
    $approvedWhere[] = "(r.request_number LIKE ? OR r.document_type LIKE ? OR r.purpose LIKE ? OR u.username LIKE ? OR res.firstName LIKE ? OR res.lastName LIKE ? OR res.emailAddress LIKE ?)";
    $searchTerm = '%' . $search . '%';
    for ($i = 0; $i < 7; $i++) {
        $approvedParams[] = $searchTerm;
        $approvedTypes .= 's';
    }
}

$approvedWhereSql = 'WHERE ' . implode(' AND ', $approvedWhere);
$approvedSql = "SELECT
        r.*,
        u.username,
        res.firstName,
        res.lastName,
        res.emailAddress,
        res.phoneNumber,
        res.fullAddress
    FROM document_requests r
    LEFT JOIN users u ON r.user_id = u.userId
    LEFT JOIN residents res ON u.residentId = res.residentId
    $approvedWhereSql
    ORDER BY COALESCE(r.reviewed_at, r.date_updated) DESC, r.request_id DESC";

$approvedStmt = mysqli_prepare($conn, $approvedSql);
if ($approvedStmt && $approvedTypes !== '') {
    mysqli_stmt_bind_param($approvedStmt, $approvedTypes, ...$approvedParams);
}

$approvedRequests = [];
if ($approvedStmt && mysqli_stmt_execute($approvedStmt)) {
    $approvedResult = mysqli_stmt_get_result($approvedStmt);
    while ($row = mysqli_fetch_assoc($approvedResult)) {
        $approvedRequests[] = $row;
    }
    mysqli_stmt_close($approvedStmt);
}

$statusOptions = [
    'all' => 'All History',
    'approved' => 'Approved',
    'printed' => 'Printed',
    'released' => 'Released',
    'rejected' => 'Rejected',
];

$roleOptions = [
    'all' => 'All Roles',
    'admin' => 'Admin',
    'staff' => 'Staff',
    'resident' => 'Resident',
];

$accountStatusOptions = [
    'all' => 'All Accounts',
    'pending' => 'For Verification',
    'verified' => 'Verified',
    'rejected' => 'Rejected',
];

$userStats = [
    'total' => 0,
    'admin' => 0,
    'staff' => 0,
    'resident' => 0,
];

$userStatsSql = "SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) AS admin_count,
    SUM(CASE WHEN role = 'staff' THEN 1 ELSE 0 END) AS staff_count,
    SUM(CASE WHEN role = 'resident' THEN 1 ELSE 0 END) AS resident_count
    FROM users";
$userStatsResult = mysqli_query($conn, $userStatsSql);
if ($userStatsResult && $row = mysqli_fetch_assoc($userStatsResult)) {
    $userStats = [
        'total' => (int) $row['total'],
        'admin' => (int) $row['admin_count'],
        'staff' => (int) $row['staff_count'],
        'resident' => (int) $row['resident_count'],
    ];
}

$userWhere = [];
$userParams = [];
$userTypes = '';

if ($roleFilter !== 'all') {
    $userWhere[] = "u.role = ?";
    $userParams[] = $roleFilter;
    $userTypes .= 's';
}

if ($accountStatusFilter !== 'all') {
    $userWhere[] = "u.account_status = ?";
    $userParams[] = $accountStatusFilter;
    $userTypes .= 's';
}

if ($userSearch !== '') {
    $userSearchTerm = '%' . strtolower($userSearch) . '%';
    $userSearchParts = [
        "LOWER(CONCAT(COALESCE(res.firstName, ''), ' ', COALESCE(res.lastName, ''))) LIKE ?",
        "LOWER(u.username) LIKE ?",
        "LOWER(COALESCE(res.emailAddress, '')) LIKE ?",
        "LOWER(COALESCE(res.phoneNumber, '')) LIKE ?",
    ];

    if (userTableColumnExists($conn, 'first_name')) {
        $userSearchParts[] = "LOWER(COALESCE(u.first_name, '')) LIKE ?";
    }
    if (userTableColumnExists($conn, 'last_name')) {
        $userSearchParts[] = "LOWER(COALESCE(u.last_name, '')) LIKE ?";
    }
    if (userTableColumnExists($conn, 'contact_email')) {
        $userSearchParts[] = "LOWER(COALESCE(u.contact_email, '')) LIKE ?";
    }
    if (userTableColumnExists($conn, 'contact_phone')) {
        $userSearchParts[] = "LOWER(COALESCE(u.contact_phone, '')) LIKE ?";
    }

    $userWhere[] = '(' . implode(' OR ', $userSearchParts) . ')';
    $searchPartCount = count($userSearchParts);
    for ($i = 0; $i < $searchPartCount; $i++) {
        $userParams[] = $userSearchTerm;
        $userTypes .= 's';
    }
}

$userWhereSql = $userWhere ? 'WHERE ' . implode(' AND ', $userWhere) : '';
$userProfileSelectSql = implode(",\n        ", [
    userColumnSelect($conn, 'first_name', 'accountFirstName'),
    userColumnSelect($conn, 'last_name', 'accountLastName'),
    userColumnSelect($conn, 'contact_email', 'contactEmail'),
    userColumnSelect($conn, 'contact_phone', 'contactPhone'),
]);
$usersSql = "SELECT
        u.userId,
        u.username,
        u.role,
        u.account_status,
        u.verification_proof,
        u.verification_rejection_reason,
        u.created_at,
        u.updated_at,
        $userProfileSelectSql,
        res.firstName,
        res.lastName,
        res.emailAddress,
        res.phoneNumber
    FROM users u
    LEFT JOIN residents res ON u.residentId = res.residentId
    $userWhereSql
    ORDER BY
        CASE WHEN u.account_status = 'pending' THEN 0 WHEN u.account_status = 'verified' THEN 1 ELSE 2 END,
        COALESCE(u.updated_at, u.created_at) DESC,
        u.userId DESC";

$userStmt = mysqli_prepare($conn, $usersSql);
if ($userStmt && $userTypes !== '') {
    mysqli_stmt_bind_param($userStmt, $userTypes, ...$userParams);
}

$users = [];
if ($userStmt && mysqli_stmt_execute($userStmt)) {
    $userResult = mysqli_stmt_get_result($userStmt);
    while ($row = mysqli_fetch_assoc($userResult)) {
        $users[] = $row;
    }
    mysqli_stmt_close($userStmt);
}

$adminNotifications = [];
$pendingVerificationSql = "SELECT
        u.userId,
        u.username,
        u.role,
        u.account_status,
        u.verification_proof,
        u.updated_at,
        $userProfileSelectSql,
        res.firstName,
        res.lastName,
        res.emailAddress,
        res.phoneNumber
    FROM users u
    LEFT JOIN residents res ON u.residentId = res.residentId
    WHERE u.role = 'resident'
      AND u.account_status = 'pending'
      AND COALESCE(u.verification_proof, '') <> ''
    ORDER BY COALESCE(u.updated_at, u.created_at) DESC, u.userId DESC
    LIMIT 8";
$pendingVerificationResult = mysqli_query($conn, $pendingVerificationSql);
if ($pendingVerificationResult) {
    while ($pendingUser = mysqli_fetch_assoc($pendingVerificationResult)) {
        $pendingUserId = (int) ($pendingUser['userId'] ?? 0);
        $adminNotifications[] = [
            'key' => 'admin-user-verification:' . $pendingUserId . ':' . (string) ($pendingUser['updated_at'] ?? ''),
            'href' => 'admin.php?section=users&account_status=pending&highlight_user=' . $pendingUserId,
            'message' => userDisplayName($pendingUser) . ' submitted account verification.',
            'date' => (string) ($pendingUser['updated_at'] ?? ''),
        ];
    }
}

$pendingRequestNotificationSql = "SELECT
        r.request_id,
        r.request_number,
        r.document_type,
        r.date_submitted,
        u.username,
        res.firstName,
        res.lastName
    FROM document_requests r
    LEFT JOIN users u ON r.user_id = u.userId
    LEFT JOIN residents res ON u.residentId = res.residentId
    WHERE r.status = 'pending'
    ORDER BY r.date_submitted DESC, r.request_id DESC
    LIMIT 8";
$pendingRequestNotificationResult = mysqli_query($conn, $pendingRequestNotificationSql);
if ($pendingRequestNotificationResult) {
    while ($pendingRequest = mysqli_fetch_assoc($pendingRequestNotificationResult)) {
        $pendingRequestId = (int) ($pendingRequest['request_id'] ?? 0);
        $pendingRequestNumber = $pendingRequest['request_number'] ?: adminRequestNumber($pendingRequestId, $pendingRequest['date_submitted'] ?? '');
        $pendingResidentName = trim(($pendingRequest['firstName'] ?? '') . ' ' . ($pendingRequest['lastName'] ?? ''));
        $pendingResidentName = $pendingResidentName ?: ($pendingRequest['username'] ?? 'Resident');
        $adminNotifications[] = [
            'key' => 'admin-pending-request:' . $pendingRequestId . ':' . (string) ($pendingRequest['date_submitted'] ?? ''),
            'href' => 'admin.php?section=pending&highlight_request=' . $pendingRequestId,
            'message' => $pendingRequestNumber . ' from ' . $pendingResidentName . ' is waiting for review.',
            'date' => (string) ($pendingRequest['date_submitted'] ?? ''),
        ];
    }
}

usort($adminNotifications, function ($left, $right) {
    return strtotime($right['date'] ?? '') <=> strtotime($left['date'] ?? '');
});
$adminNotifications = array_slice($adminNotifications, 0, 10);

$reportRows = [];
$reportSql = "SELECT
        r.request_id,
        r.request_number,
        r.document_type,
        r.purpose,
        r.status,
        r.date_submitted,
        r.reviewed_at,
        u.username,
        res.firstName,
        res.lastName
    FROM document_requests r
    LEFT JOIN users u ON r.user_id = u.userId
    LEFT JOIN residents res ON u.residentId = res.residentId
    ORDER BY COALESCE(r.reviewed_at, r.date_updated, r.date_submitted) DESC, r.request_id DESC
    LIMIT 75";
$reportResult = mysqli_query($conn, $reportSql);
if ($reportResult) {
    while ($row = mysqli_fetch_assoc($reportResult)) {
        $reportRows[] = $row;
    }
}

$monthlyReportRows = [];
$monthlyReportSql = "SELECT
        DATE_FORMAT(date_submitted, '%Y-%m') AS report_month,
        COUNT(*) AS total_count,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_count,
        SUM(CASE WHEN status = 'printed' THEN 1 ELSE 0 END) AS printed_count,
        SUM(CASE WHEN status = 'released' THEN 1 ELSE 0 END) AS released_count,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_count
    FROM document_requests
    GROUP BY DATE_FORMAT(date_submitted, '%Y-%m')
    ORDER BY report_month DESC
    LIMIT 6";
$monthlyReportResult = mysqli_query($conn, $monthlyReportSql);
if ($monthlyReportResult) {
    while ($row = mysqli_fetch_assoc($monthlyReportResult)) {
        $monthlyReportRows[] = $row;
    }
}

$backupDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'backups';
$recentBackups = [];
if (is_dir($backupDirectory)) {
    $backupFiles = glob($backupDirectory . DIRECTORY_SEPARATOR . '*.zip') ?: [];
    usort($backupFiles, function ($left, $right) {
        return filemtime($right) <=> filemtime($left);
    });
    foreach (array_slice($backupFiles, 0, 8) as $backupFile) {
        $recentBackups[] = [
            'name' => basename($backupFile),
            'size' => filesize($backupFile),
            'date' => filemtime($backupFile),
        ];
    }
}

$templates = [];
$templateSql = "SELECT id, name, category, description, fee, usage_count, file_name, file_path, template_content, created_at, last_modified FROM document_templates ORDER BY last_modified DESC, id DESC";
$templateResult = mysqli_query($conn, $templateSql);
if ($templateResult) {
    while ($row = mysqli_fetch_assoc($templateResult)) {
        $templates[] = $row;
    }
}

$recentActivities = [];
$activitySql = "SELECT user_id, username, role, action, description, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 8";
$activityResult = mysqli_query($conn, $activitySql);
if ($activityResult) {
    while ($row = mysqli_fetch_assoc($activityResult)) {
        $recentActivities[] = $row;
    }
}

$activityLogs = [];
$activityWhere = [];
$activityParams = [];
$activityTypes = '';

if ($activitySearch !== '') {
    $activityWhere[] = "(LOWER(username) LIKE ? OR LOWER(action) LIKE ? OR LOWER(description) LIKE ?)";
    $activitySearchTerm = '%' . strtolower($activitySearch) . '%';
    $activityParams[] = $activitySearchTerm;
    $activityParams[] = $activitySearchTerm;
    $activityParams[] = $activitySearchTerm;
    $activityTypes .= 'sss';
}

$activityWhereSql = $activityWhere ? 'WHERE ' . implode(' AND ', $activityWhere) : '';
$activityLogsSql = "SELECT user_id, username, role, action, description, created_at FROM activity_logs $activityWhereSql ORDER BY created_at DESC";
$activityLogsStmt = mysqli_prepare($conn, $activityLogsSql);
if ($activityLogsStmt && $activityTypes !== '') {
    mysqli_stmt_bind_param($activityLogsStmt, $activityTypes, ...$activityParams);
}

if ($activityLogsStmt && mysqli_stmt_execute($activityLogsStmt)) {
    $activityLogsResult = mysqli_stmt_get_result($activityLogsStmt);
    while ($row = mysqli_fetch_assoc($activityLogsResult)) {
        $activityLogs[] = $row;
    }
    mysqli_stmt_close($activityLogsStmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/admin.css?v=20260824-backup-reports">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.13.1/font/bootstrap-icons.min.css" integrity="sha512-t7Few9xlddEmgd3oKZQahkNI4dS6l80+eGEzFQiqtyVYdvcSG2D3Iub77R20BdotfRPA9caaRkg1tyaJiPmO0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<header class="admin-header">
    <div class="container header-container">
        <div>
            <h1>Admin Dashboard</h1>
            <p class="admin-welcome">Welcome, <?php echo htmlspecialchars($displayName); ?></p>
        </div>
        <div class="header-actions">
            <div class="notification-wrap">
                <button class="icon-button notification-toggle" type="button" aria-label="Notifications" aria-expanded="false" aria-controls="adminNotificationMenu">
                    <i class="bi bi-bell"></i>
                    <span class="notification-badge" data-notification-badge hidden>0</span>
                </button>
                <div class="notification-menu" id="adminNotificationMenu" hidden>
                    <div class="notification-menu-header">
                        <strong>Notifications</strong>
                    </div>
                    <div class="notification-list" data-notification-list>
                        <?php if (empty($adminNotifications)): ?>
                            <div class="notification-empty">No new verification or request updates.</div>
                        <?php else: ?>
                            <?php foreach ($adminNotifications as $notification): ?>
                                <a
                                    class="notification-item"
                                    href="<?php echo htmlspecialchars($notification['href']); ?>"
                                    data-notification-key="<?php echo htmlspecialchars($notification['key']); ?>"
                                >
                                    <span class="notification-unread-dot" aria-hidden="true"></span>
                                    <span><?php echo htmlspecialchars($notification['message']); ?></span>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <button class="icon-button" aria-label="Account" data-modal-target="editSelfModal"><i class="bi bi-person-circle"></i></button>
            <a href="../auth/logout.php" class="logout-button"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
        </div>
    </div>
</header>

<main>
    <?php displayFlashMessages(); ?>

    <section class="stats-section">
        <div class="container stats-grid">
            <a href="admin.php?section=requests" class="stat-card" aria-label="View request history">
                <span>Request History</span>
                <strong><?php echo $historyCount; ?></strong>
                <i class="bi bi-file-earmark-text"></i>
            </a>
            <a href="admin.php?section=pending" class="stat-card warning" aria-label="View pending requests">
                <span>Pending</span>
                <strong><?php echo $stats['pending']; ?></strong>
                <i class="bi bi-hourglass-split"></i>
            </a>
            <a href="admin.php?section=requests&status=approved" class="stat-card info" aria-label="View approved requests">
                <span>Approved</span>
                <strong><?php echo $stats['approved']; ?></strong>
                <i class="bi bi-arrow-repeat"></i>
            </a>
            <a href="admin.php?section=requests&status=printed" class="stat-card success" aria-label="View printed requests">
                <span>Printed</span>
                <strong><?php echo $stats['printed']; ?></strong>
                <i class="bi bi-printer"></i>
            </a>
            <a href="admin.php?section=requests&status=released" class="stat-card primary" aria-label="View released requests">
                <span>Released</span>
                <strong><?php echo $stats['released']; ?></strong>
                <i class="bi bi-send-check"></i>
            </a>
            <a href="admin.php?section=requests&status=rejected" class="stat-card danger" aria-label="View rejected requests">
                <span>Rejected</span>
                <strong><?php echo $stats['rejected']; ?></strong>
                <i class="bi bi-x-circle"></i>
            </a>
            <a href="admin.php?section=archive" class="stat-card" aria-label="View archived request history">
                <span>Archived</span>
                <strong><?php echo $stats['archive']; ?></strong>
                <i class="bi bi-archive"></i>
            </a>
        </div>
    </section>

    <section class="nav-section">
        <div class="container">
            <nav class="admin-nav" aria-label="Admin sections">
                <a href="admin.php?section=overview" class="nav-link <?php echo $activeSection === 'overview' ? 'active' : ''; ?>"><i class="bi bi-grid"></i><span>Overview</span></a>
                <a href="admin.php?section=users" class="nav-link <?php echo $activeSection === 'users' ? 'active' : ''; ?>"><i class="bi bi-people"></i><span>User Management</span></a>
                <a href="admin.php?section=pending" class="nav-link <?php echo $activeSection === 'pending' ? 'active' : ''; ?>"><i class="bi bi-hourglass-split"></i><span>Pending Requests</span></a>
                <a href="admin.php?section=requests" class="nav-link <?php echo $activeSection === 'requests' ? 'active' : ''; ?>"><i class="bi bi-file-earmark-text"></i><span>Request History</span></a>
                <a href="admin.php?section=approved" class="nav-link <?php echo $activeSection === 'approved' ? 'active' : ''; ?>"><i class="bi bi-file-earmark-check"></i><span>Approved Documents</span></a>
                <a href="admin.php?section=archive" class="nav-link <?php echo $activeSection === 'archive' ? 'active' : ''; ?>"><i class="bi bi-archive"></i><span>Archive</span></a>
                <a href="admin.php?section=reports" class="nav-link <?php echo $activeSection === 'reports' ? 'active' : ''; ?>"><i class="bi bi-printer"></i><span>Print Reports</span></a>
                <a href="admin.php?section=backup" class="nav-link <?php echo $activeSection === 'backup' ? 'active' : ''; ?>"><i class="bi bi-database-down"></i><span>System Backup</span></a>
                <a href="admin.php?section=templates" class="nav-link <?php echo $activeSection === 'templates' ? 'active' : ''; ?>"><i class="bi bi-gear"></i><span>Document Templates</span></a>
                <a href="admin.php?section=activity" class="nav-link <?php echo $activeSection === 'activity' ? 'active' : ''; ?>"><i class="bi bi-activity"></i><span>Activity Log</span></a>
            </nav>
        </div>
    </section>

    <section class="requests-section">
        <div class="container">
            <?php if ($activeSection === 'users'): ?>
            <div class="requests-card user-management-card">
                <div class="card-heading">
                    <div class="title-row">
                        <i class="bi bi-people"></i>
                        <div>
                            <h2>User Management</h2>
                            <p>Manage system users and resident verification</p>
                        </div>
                    </div>
                    <button type="button" class="add-user-button open-modal-button" data-modal-target="addUserModal">
                        <i class="bi bi-plus-lg"></i>Add User
                    </button>
                </div>

                <div class="user-toolbar">
                    <div class="user-counts">
                        <span>Total Users: <?php echo $userStats['total']; ?></span>
                        <span>Admin: <?php echo $userStats['admin']; ?></span>
                        <span>Staff: <?php echo $userStats['staff']; ?></span>
                        <span>Resident: <?php echo $userStats['resident']; ?></span>
                    </div>
                    <form class="filter-form" method="GET">
                        <input type="hidden" name="section" value="users">
                        <label class="search-box">
                            <i class="bi bi-search"></i>
                            <input type="search" name="user_search" placeholder="Search users by name or contact..." value="<?php echo htmlspecialchars($userSearch); ?>">
                        </label>
                        <button type="submit" class="mini-action">Search</button>
                        <select name="role" aria-label="Filter by role" onchange="this.form.submit()">
                            <?php foreach ($roleOptions as $value => $label): ?>
                                <option value="<?php echo htmlspecialchars($value); ?>" <?php echo $roleFilter === $value ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <select name="account_status" aria-label="Filter by account status" onchange="this.form.submit()">
                            <?php foreach ($accountStatusOptions as $value => $label): ?>
                                <option value="<?php echo htmlspecialchars($value); ?>" <?php echo $accountStatusFilter === $value ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>

                <div class="table-wrap">
                    <table class="requests-table users-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="8" class="empty-cell">No users found.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($users as $user): ?>
                                <?php
                                $displayUserName = userDisplayName($user);
                                $email = trim((string) ($user['emailAddress'] ?? '')) ?: (trim((string) ($user['contactEmail'] ?? '')) ?: 'Not provided');
                                $phone = trim((string) ($user['phoneNumber'] ?? '')) ?: (trim((string) ($user['contactPhone'] ?? '')) ?: 'Not provided');
                                $accountFirstName = trim((string) ($user['firstName'] ?? '')) ?: trim((string) ($user['accountFirstName'] ?? ''));
                                $accountLastName = trim((string) ($user['lastName'] ?? '')) ?: trim((string) ($user['accountLastName'] ?? ''));
                                $accountEmail = trim((string) ($user['emailAddress'] ?? '')) ?: trim((string) ($user['contactEmail'] ?? ''));
                                $accountPhone = trim((string) ($user['phoneNumber'] ?? '')) ?: trim((string) ($user['contactPhone'] ?? ''));
                                $status = strtolower($user['account_status'] ?? 'pending');
                                $proofPath = trim((string) ($user['verification_proof'] ?? ''));
                                $rejectReason = trim((string) ($user['verification_rejection_reason'] ?? ''));
                                $proofUrl = $proofPath !== '' ? '../' . ltrim($proofPath, '/\\') : '';
                                $canReview = $user['role'] === 'resident' && $proofPath !== '' && $status === 'pending';
                                $reviewModalId = 'verifyUserModal' . (int) $user['userId'];
                                $rejectModalId = 'rejectUserModal' . (int) $user['userId'];
                                ?>
                                <tr id="admin-user-<?php echo (int) $user['userId']; ?>" class="<?php echo (int) $user['userId'] === $highlightUserId ? 'request-highlight' : ''; ?>">
                                    <td><?php echo htmlspecialchars($displayUserName); ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($email); ?></td>
                                    <td><?php echo htmlspecialchars($phone); ?></td>
                                    <td><span class="role-pill <?php echo htmlspecialchars($user['role']); ?>"><?php echo htmlspecialchars(ucfirst($user['role'])); ?></span></td>
                                    <td><span class="status-pill <?php echo htmlspecialchars($status); ?>"><?php echo htmlspecialchars(accountStatusLabel($status)); ?></span></td>
                                    <td><?php echo htmlspecialchars(date('m/d/Y', strtotime($user['created_at']))); ?></td>
                                    <td>
                                        <div class="user-actions">
                                            <?php if ($canReview): ?>
                                                <button
                                                    type="button"
                                                    class="mini-action verify open-modal-button"
                                                    data-modal-target="<?php echo htmlspecialchars($reviewModalId); ?>">
                                                    View &amp; Verify
                                                </button>
                                            <?php else: ?>
                                                <button type="button" class="mini-action verify disabled" disabled>View &amp; Verify</button>
                                            <?php endif; ?>
                                            <?php if ((int) $user['userId'] !== (int) $_SESSION['user_id']): ?>
                                                <form method="POST" action="../actions/deleteUser.php" onsubmit="return confirm('Delete this user account?');">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                    <input type="hidden" name="user_id" value="<?php echo (int) $user['userId']; ?>">
                                                    <button type="submit" class="mini-action delete">Delete</button>
                                                </form>
                                            <?php else: ?>
                                                <span class="muted-text">Current user</span>
                                            <?php endif; ?>
                                            <?php if ((int) $user['userId'] !== (int) $_SESSION['user_id']): ?>
                                                <button type="button" class="mini-action edit open-modal-button" data-modal-target="editUserModal<?php echo (int) $user['userId']; ?>">Edit</button>
                                            <?php endif; ?>
                                        </div>
                                        <?php if ($canReview): ?>
                                            <div class="modal-backdrop" id="<?php echo htmlspecialchars($reviewModalId); ?>" aria-hidden="true" hidden data-allow-backdrop="false">
                                                <div class="modal-panel review-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($reviewModalId); ?>Title">
                                                    <div class="modal-header">
                                                        <div>
                                                            <h3 id="<?php echo htmlspecialchars($reviewModalId); ?>Title">View &amp; Verify</h3>
                                                            <p><?php echo htmlspecialchars($displayUserName); ?> - <?php echo htmlspecialchars(accountStatusLabel($status)); ?></p>
                                                        </div>
                                                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                                    </div>
                                                    <div class="modal-form review-content">
                                                        <div class="review-details">
                                                            <span>Username: <strong><?php echo htmlspecialchars($user['username']); ?></strong></span>
                                                            <span>Email: <strong><?php echo htmlspecialchars($email); ?></strong></span>
                                                            <span>Phone: <strong><?php echo htmlspecialchars($phone); ?></strong></span>
                                                        </div>

                                                        <?php if ($rejectReason !== ''): ?>
                                                            <div class="reason-note">
                                                                <strong>Previous reason</strong>
                                                                <p><?php echo htmlspecialchars($rejectReason); ?></p>
                                                            </div>
                                                        <?php endif; ?>

                                                        <div class="proof-preview-box">
                                                            <div class="proof-preview-header">
                                                                <strong>Submitted proof</strong>
                                                                <a href="<?php echo htmlspecialchars($proofUrl); ?>" target="_blank" rel="noopener"><i class="bi bi-box-arrow-up-right"></i>Open file</a>
                                                            </div>
                                                            <iframe src="<?php echo htmlspecialchars($proofUrl); ?>" title="Verification proof for <?php echo htmlspecialchars($displayUserName); ?>"></iframe>
                                                        </div>

                                                        <div class="review-actions">
                                                            <form method="POST" action="../actions/updateUserVerification.php">
                                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                                <input type="hidden" name="user_id" value="<?php echo (int) $user['userId']; ?>">
                                                                <input type="hidden" name="status" value="verified">
                                                                <button type="submit" class="add-user-button approve-submit"><i class="bi bi-check-circle"></i>Verify</button>
                                                            </form>
                                                            <button
                                                                type="button"
                                                                class="add-user-button reject-submit open-modal-button"
                                                                data-modal-target="<?php echo htmlspecialchars($rejectModalId); ?>">
                                                                <i class="bi bi-x-circle"></i>Reject
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-backdrop" id="<?php echo htmlspecialchars($rejectModalId); ?>" aria-hidden="true" hidden>
                                                <div class="modal-panel reject-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($rejectModalId); ?>Title">
                                                    <div class="modal-header">
                                                        <div>
                                                            <h3 id="<?php echo htmlspecialchars($rejectModalId); ?>Title">Reject Verification</h3>
                                                            <p><?php echo htmlspecialchars($displayUserName); ?></p>
                                                        </div>
                                                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                                    </div>
                                                    <form method="POST" action="../actions/updateUserVerification.php" class="modal-form reject-review-form">
                                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                        <input type="hidden" name="user_id" value="<?php echo (int) $user['userId']; ?>">
                                                        <input type="hidden" name="status" value="rejected">
                                                        <label for="rejectReason<?php echo (int) $user['userId']; ?>">Reason</label>
                                                        <textarea id="rejectReason<?php echo (int) $user['userId']; ?>" name="rejection_reason" rows="4" placeholder="Example: Uploaded proof is blurry or does not match the registered details." required></textarea>
                                                        <div class="reject-modal-actions">
                                                            <button type="button" class="modal-secondary-button" data-modal-close>Cancel</button>
                                                            <button type="submit" class="add-user-button reject-submit"><i class="bi bi-x-circle"></i>Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ((int) $user['userId'] !== (int) $_SESSION['user_id']): ?>
                                            <div class="modal-backdrop" id="editUserModal<?php echo (int) $user['userId']; ?>" aria-hidden="true" hidden>
                                                <div class="modal-panel edit-user-modal" role="dialog" aria-modal="true" aria-labelledby="editUserModal<?php echo (int) $user['userId']; ?>Title">
                                                    <div class="modal-header">
                                                        <div>
                                                            <h3 id="editUserModal<?php echo (int) $user['userId']; ?>Title">Edit User</h3>
                                                            <p><?php echo htmlspecialchars($displayUserName); ?></p>
                                                        </div>
                                                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                                    </div>
                                                    <form method="POST" action="../actions/updateUser.php" class="modal-form">
                                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                        <input type="hidden" name="user_id" value="<?php echo (int) $user['userId']; ?>">
                                                        <div>
                                                            <label>First Name</label>
                                                            <input type="text" name="first_name" value="<?php echo htmlspecialchars($accountFirstName); ?>" placeholder="First name">
                                                        </div>
                                                        <div>
                                                            <label>Surname</label>
                                                            <input type="text" name="last_name" value="<?php echo htmlspecialchars($accountLastName); ?>" placeholder="Surname">
                                                        </div>
                                                        <div>
                                                            <label>Phone Number</label>
                                                            <input type="tel" name="contact_phone" value="<?php echo htmlspecialchars($accountPhone); ?>" placeholder="09XXXXXXXXX">
                                                        </div>
                                                        <div>
                                                            <label>Email Address</label>
                                                            <input type="email" name="contact_email" value="<?php echo htmlspecialchars($accountEmail); ?>" placeholder="Email address">
                                                        </div>
                                                        <div>
                                                            <label>Username</label>
                                                            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                                        </div>
                                                        <div>
                                                            <label>Role</label>
                                                            <select name="role" required>
                                                                <option value="resident" <?php echo $user['role'] === 'resident' ? 'selected' : ''; ?>>Resident</option>
                                                                <option value="staff" <?php echo $user['role'] === 'staff' ? 'selected' : ''; ?>>Staff</option>
                                                                <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                                            </select>
                                                        </div>
                                                        <div>
                                                            <label>New Password (leave blank to keep current)</label>
                                                            <input type="password" name="password" placeholder="New password">
                                                        </div>
                                                        <div class="form-actions">
                                                            <button type="submit" class="add-user-button">Save</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-backdrop" id="addUserModal" aria-hidden="true" hidden>
                <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="addUserModalTitle">
                    <div class="modal-header">
                        <div>
                            <h3 id="addUserModalTitle">Add User</h3>
                            <p>Create a staff or admin account.</p>
                        </div>
                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                    </div>
                    <form class="add-user-form modal-form" method="POST" action="../actions/addUser.php">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <div>
                            <label>First Name</label>
                            <input type="text" name="first_name" placeholder="Enter first name" required>
                        </div>
                        <div>
                            <label>Surname</label>
                            <input type="text" name="last_name" placeholder="Enter surname" required>
                        </div>
                        <div>
                            <label>Phone Number</label>
                            <input type="tel" name="contact_phone" placeholder="09XXXXXXXXX" required>
                        </div>
                        <div>
                            <label>Email Address</label>
                            <input type="email" name="contact_email" placeholder="Enter email address" required>
                        </div>
                        <div>
                            <label>Username</label>
                            <input type="text" name="username" placeholder="Enter username" required>
                        </div>
                        <div>
                            <label>Role</label>
                            <select name="role" required>
                                <option value="staff">Staff</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div>
                            <label>Password</label>
                            <input type="password" name="password" placeholder="Minimum 8 characters" required>
                        </div>
                        <div>
                            <label>Confirm Password</label>
                            <input type="password" name="confirm_password" placeholder="Confirm password" required>
                        </div>
                        <button type="submit" class="add-user-button"><i class="bi bi-plus-lg"></i>Add User</button>
                    </form>
                </div>
            </div>

            <?php elseif ($activeSection === 'reports'): ?>
            <div class="requests-card report-card" id="printableReport">
                <div class="card-heading">
                    <div class="title-row">
                        <i class="bi bi-printer"></i>
                        <div>
                            <h2>Printable Request Report</h2>
                            <p>Summary and recent document request activity</p>
                        </div>
                    </div>
                    <button type="button" class="add-user-button report-print-button" data-print-report>
                        <i class="bi bi-printer"></i>Print Report
                    </button>
                </div>

                <div class="report-summary-grid">
                    <div><span>Total Requests</span><strong><?php echo $stats['total']; ?></strong></div>
                    <div><span>Pending</span><strong><?php echo $stats['pending']; ?></strong></div>
                    <div><span>Approved</span><strong><?php echo $stats['approved']; ?></strong></div>
                    <div><span>Printed</span><strong><?php echo $stats['printed']; ?></strong></div>
                    <div><span>Released</span><strong><?php echo $stats['released']; ?></strong></div>
                    <div><span>Rejected</span><strong><?php echo $stats['rejected']; ?></strong></div>
                </div>

                <div class="report-subsection">
                    <h3>Monthly Summary</h3>
                    <div class="table-wrap">
                        <table class="requests-table">
                            <thead>
                                <tr>
                                    <th>Month</th>
                                    <th>Total</th>
                                    <th>Approved</th>
                                    <th>Printed</th>
                                    <th>Released</th>
                                    <th>Rejected</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (empty($monthlyReportRows)): ?>
                                <tr><td colspan="6" class="empty-cell">No report data available.</td></tr>
                            <?php else: ?>
                                <?php foreach ($monthlyReportRows as $monthRow): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars(date('F Y', strtotime($monthRow['report_month'] . '-01'))); ?></td>
                                        <td><?php echo (int) $monthRow['total_count']; ?></td>
                                        <td><?php echo (int) $monthRow['approved_count']; ?></td>
                                        <td><?php echo (int) $monthRow['printed_count']; ?></td>
                                        <td><?php echo (int) $monthRow['released_count']; ?></td>
                                        <td><?php echo (int) $monthRow['rejected_count']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="report-subsection">
                    <h3>Recent Requests</h3>
                    <div class="table-wrap">
                        <table class="requests-table">
                            <thead>
                                <tr>
                                    <th>Request Number</th>
                                    <th>Resident</th>
                                    <th>Document Type</th>
                                    <th>Status</th>
                                    <th>Date Submitted</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (empty($reportRows)): ?>
                                <tr><td colspan="5" class="empty-cell">No requests found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($reportRows as $reportRow): ?>
                                    <?php
                                    $reportRequestId = (int) ($reportRow['request_id'] ?? 0);
                                    $reportRequestNumber = $reportRow['request_number'] ?: adminRequestNumber($reportRequestId, $reportRow['date_submitted'] ?? '');
                                    $reportResidentName = trim(($reportRow['firstName'] ?? '') . ' ' . ($reportRow['lastName'] ?? ''));
                                    $reportResidentName = $reportResidentName ?: ($reportRow['username'] ?? 'Unknown User');
                                    $reportStatus = strtolower((string) ($reportRow['status'] ?? 'pending'));
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($reportRequestNumber); ?></td>
                                        <td><?php echo htmlspecialchars($reportResidentName); ?></td>
                                        <td><?php echo htmlspecialchars($reportRow['document_type'] ?? 'Document'); ?></td>
                                        <td><span class="status-pill <?php echo htmlspecialchars(adminStatusClass($reportStatus)); ?>"><?php echo htmlspecialchars(adminStatusLabel($reportStatus)); ?></span></td>
                                        <td><?php echo htmlspecialchars(!empty($reportRow['date_submitted']) ? date('m/d/Y', strtotime($reportRow['date_submitted'])) : 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php elseif ($activeSection === 'backup'): ?>
            <div class="requests-card backup-card">
                <div class="card-heading">
                    <div class="title-row">
                        <i class="bi bi-database-down"></i>
                        <div>
                            <h2>System Backup</h2>
                            <p>Download a local ZIP copy of the database and project files</p>
                        </div>
                    </div>
                    <form method="POST" action="../actions/createSystemBackup.php">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <button type="submit" class="add-user-button">
                            <i class="bi bi-download"></i>Create Backup
                        </button>
                    </form>
                </div>

                <div class="backup-note">
                    Backup files are saved under the local <strong>backups</strong> folder and downloaded as ZIP files. The backup folder itself is skipped during backup creation to avoid nested copies.
                </div>

                <div class="table-wrap">
                    <table class="requests-table">
                        <thead>
                            <tr>
                                <th>Recent Backup</th>
                                <th>Size</th>
                                <th>Date Created</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($recentBackups)): ?>
                            <tr><td colspan="3" class="empty-cell">No local backups created yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($recentBackups as $backup): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($backup['name']); ?></td>
                                    <td><?php echo htmlspecialchars(number_format(((int) $backup['size']) / 1024, 1)); ?> KB</td>
                                    <td><?php echo htmlspecialchars(date('m/d/Y h:i A', (int) $backup['date'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php elseif ($activeSection === 'templates'): ?>
            <div class="requests-card document-template-shell">
                <section id="section-document-templates">
                    <div class="section-header">
                        <div class="section-title-area">
                            <h2>Document Templates</h2>
                            <p>Manage barangay document templates and requirements</p>
                        </div>
                        <button type="button" class="btn-primary open-template-modal" data-template-modal="createTemplateModal">
                            <i class="bi bi-plus-lg"></i>
                            <span>Create Template</span>
                        </button>
                    </div>

                    <div class="cards-grid">
                        <?php if (empty($templates)): ?>
                            <div class="template-card empty-template-card">
                                <p>No templates yet. Create your first one to get started.</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($templates as $template): ?>
                                <?php
                                $templateId = (int) $template['id'];
                                $fee = number_format((float) ($template['fee'] ?? 0), 2);
                                $lastModified = $template['last_modified'] ?: $template['created_at'];
                                $templateModalId = 'editTemplateModal' . $templateId;
                                $deleteModalId = 'deleteTemplateModal' . $templateId;
                                $templateName = htmlspecialchars($template['name'] ?? 'Untitled');
                                ?>
                                <div class="template-card">
                                    <div class="card-header">
                                        <div class="card-icon">
                                            <i class="bi bi-file-earmark-text"></i>
                                        </div>
                                        <div class="card-title-group">
                                            <h3><?php echo $templateName; ?></h3>
                                            <span class="badge"><?php echo htmlspecialchars($template['category'] ?? 'General'); ?></span>
                                        </div>
                                    </div>
                                    <p class="card-desc"><?php echo htmlspecialchars($template['description'] ?: 'Template description coming soon.'); ?></p>
                                    <div class="card-details">
                                        <div class="detail-labels">
                                            <span>Fee:</span>
                                            <span>Usage:</span>
                                            <span>Last Modified:</span>
                                        </div>
                                        <div class="detail-values">
                                            <span class="text-green">₱<?php echo htmlspecialchars($fee); ?></span>
                                            <span><?php echo (int) ($template['usage_count'] ?? 0); ?> times</span>
                                            <span class="text-dark-gray"><?php echo htmlspecialchars(date('M d, Y', strtotime($lastModified))); ?></span>
                                        </div>
                                    </div>
                                    <div class="card-actions">
                                        <?php if (!empty($template['file_path'])): ?>
                                            <a class="btn-secondary btn-view" href="../<?php echo htmlspecialchars($template['file_path']); ?>" target="_blank" rel="noopener">
                                                <i class="bi bi-download"></i>
                                                <span>Download</span>
                                            </a>
                                        <?php else: ?>
                                            <button type="button" class="btn-secondary btn-view" disabled>No File</button>
                                        <?php endif; ?>
                                        <button type="button" class="btn-icon open-template-modal" data-template-modal="<?php echo htmlspecialchars($templateModalId); ?>" aria-label="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button type="button" class="btn-icon open-template-modal" data-template-modal="<?php echo htmlspecialchars($deleteModalId); ?>" aria-label="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="modal-backdrop" id="<?php echo htmlspecialchars($templateModalId); ?>" aria-hidden="true" hidden>
                                    <div class="modal-panel template-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($templateModalId); ?>Title">
                                        <div class="modal-header">
                                            <div>
                                                <h3 id="<?php echo htmlspecialchars($templateModalId); ?>Title">Edit Template</h3>
                                                <p><?php echo $templateName; ?></p>
                                            </div>
                                            <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                        </div>
                                        <form class="modal-form template-form" method="POST" action="../actions/manageDocumentTemplate.php" enctype="multipart/form-data">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                            <input type="hidden" name="action" value="edit">
                                            <input type="hidden" name="template_id" value="<?php echo $templateId; ?>">
                                            <label>Template Name</label>
                                            <input type="text" name="name" value="<?php echo htmlspecialchars($template['name'] ?? ''); ?>" required>
                                            <label>Category</label>
                                            <input type="text" name="category" value="<?php echo htmlspecialchars($template['category'] ?? ''); ?>" required>
                                            <label>Description</label>
                                            <textarea name="description" rows="3"><?php echo htmlspecialchars($template['description'] ?? ''); ?></textarea>
                                            <label>Fee (₱)</label>
                                            <input type="number" step="0.01" min="0" name="fee" value="<?php echo htmlspecialchars((string) ($template['fee'] ?? 0)); ?>">
                                            <label>Template Content / Notes</label>
                                            <textarea name="template_content" rows="4" placeholder="Add the editable wording for this template."><?php echo htmlspecialchars($template['template_content'] ?? ''); ?></textarea>
                                            <label>Upload Word/PDF/TXT File (optional)</label>
                                            <input type="file" name="template_file" accept=".doc,.docx,.pdf,.txt">
                                            <button type="submit" class="add-user-button"><i class="bi bi-check-circle"></i>Save Changes</button>
                                        </form>
                                    </div>
                                </div>

                                <div class="modal-backdrop" id="<?php echo htmlspecialchars($deleteModalId); ?>" aria-hidden="true" hidden>
                                    <div class="modal-panel template-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($deleteModalId); ?>Title">
                                        <div class="modal-header">
                                            <div>
                                                <h3 id="<?php echo htmlspecialchars($deleteModalId); ?>Title">Delete Template</h3>
                                                <p><?php echo $templateName; ?></p>
                                            </div>
                                            <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                        </div>
                                        <form class="modal-form template-form" method="POST" action="../actions/manageDocumentTemplate.php">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="template_id" value="<?php echo $templateId; ?>">
                                            <p class="delete-template-message">Are you sure you want to delete this template?</p>
                                            <button type="submit" class="add-user-button reject-submit"><i class="bi bi-trash"></i>Delete Template</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>
            </div>

            <div class="modal-backdrop" id="createTemplateModal" aria-hidden="true" hidden>
                <div class="modal-panel template-modal" role="dialog" aria-modal="true" aria-labelledby="createTemplateModalTitle">
                    <div class="modal-header">
                        <div>
                            <h3 id="createTemplateModalTitle">Create Template</h3>
                            <p>Add a new document template and upload a file if needed.</p>
                        </div>
                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                    </div>
                    <form class="modal-form template-form" method="POST" action="../actions/manageDocumentTemplate.php" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <input type="hidden" name="action" value="create">
                        <label>Template Name</label>
                        <input type="text" name="name" placeholder="e.g. Barangay Clearance" required>
                        <label>Category</label>
                        <input type="text" name="category" placeholder="e.g. Certificates" required>
                        <label>Description</label>
                        <textarea name="description" rows="3" placeholder="Short description of the template"></textarea>
                        <label>Fee (₱)</label>
                        <input type="number" step="0.01" min="0" name="fee" value="0">
                        <label>Template Content / Notes</label>
                        <textarea name="template_content" rows="4" placeholder="Add the wording or instructions for the template."></textarea>
                        <label>Upload Word/PDF/TXT File (optional)</label>
                        <input type="file" name="template_file" accept=".doc,.docx,.pdf,.txt">
                        <button type="submit" class="add-user-button"><i class="bi bi-plus-lg"></i>Create Template</button>
                    </form>
                </div>
            </div>

            <?php elseif ($activeSection === 'approved'): ?>
            <div class="requests-card">
                <div class="card-heading">
                    <div class="title-row">
                        <i class="bi bi-file-earmark-check"></i>
                        <div>
                            <h2>Approved Documents</h2>
                            <p>Approved and printed requests ready for the next step</p>
                        </div>
                    </div>

                    <form class="filter-form" method="GET">
                        <input type="hidden" name="section" value="approved">
                        <label class="search-box">
                            <i class="bi bi-search"></i>
                            <input type="search" name="search" placeholder="Search approved..." value="<?php echo htmlspecialchars($search); ?>">
                        </label>
                    </form>
                </div>

                <div class="table-wrap">
                    <table class="requests-table">
                        <thead>
                            <tr>
                                <th>Request Number</th>
                                <th>Resident Name</th>
                                <th>Document Type</th>
                                <th>Purpose</th>
                                <th>Processed Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($approvedRequests)): ?>
                            <tr>
                                <td colspan="7" class="empty-cell">No approved or printed documents found.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($approvedRequests as $request): ?>
                                <?php
                                $requestId = (int) $request['request_id'];
                                $requestNumber = $request['request_number'] ?: adminRequestNumber($requestId, $request['date_submitted']);
                                $residentName = trim(($request['firstName'] ?? '') . ' ' . ($request['lastName'] ?? ''));
                                $userName = $residentName ?: ($request['emailAddress'] ?: ($request['username'] ?? 'Unknown User'));
                                $approvedDate = $request['reviewed_at'] ?: $request['date_updated'];
                                $requestStatus = strtolower((string) ($request['status'] ?? 'approved'));
                                $approvedModalId = 'approvedDocModal' . $requestId;
                                $requestFiles = fetchRequestFiles($conn, $requestId);
                                $approvedRedirect = http_build_query(['section' => 'approved', 'search' => $search]);
                                $certificateTitle = strtoupper((string) ($request['document_type'] ?? 'Barangay Certificate'));
                                $certificateAddress = trim((string) ($request['fullAddress'] ?? 'Barangay Krus na Ligas, Quezon City'));
                                $certificatePurpose = trim((string) ($request['purpose'] ?? 'official purposes'));
                                $certificateDate = $approvedDate ? date('F d, Y', strtotime($approvedDate)) : date('F d, Y');
                                $certificateBody = 'This is to certify that ' . $userName . ', of legal age and a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ', has requested this document for ' . ($certificatePurpose !== '' ? $certificatePurpose : 'official purposes') . '.';
                                if (stripos($certificateTitle, 'INDIGENCY') !== false) {
                                    $certificateBody = 'This is to certify that ' . $userName . ', a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ', is known to this office and may be considered for assistance subject to validation by the receiving agency.';
                                } elseif (stripos($certificateTitle, 'RESIDENCY') !== false) {
                                    $certificateBody = 'This is to certify that ' . $userName . ' is a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ' based on available barangay records.';
                                } elseif (stripos($certificateTitle, 'CLEARANCE') !== false) {
                                    $certificateBody = 'This is to certify that ' . $userName . ', a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ', has requested barangay clearance for ' . ($certificatePurpose !== '' ? $certificatePurpose : 'official purposes') . '.';
                                }
                                $certificatePreviewId = 'adminCertificatePreview' . $requestId;
                                ?>
                                <tr id="admin-request-<?php echo $requestId; ?>" class="<?php echo $requestId === $highlightRequestId ? 'request-highlight' : ''; ?>">
                                    <td><?php echo htmlspecialchars($requestNumber); ?></td>
                                    <td><span class="user-link"><?php echo htmlspecialchars($userName); ?></span></td>
                                    <td><?php echo htmlspecialchars($request['document_type']); ?></td>
                                    <td><?php echo htmlspecialchars($request['purpose'] ?: 'Not specified'); ?></td>
                                    <td><?php echo htmlspecialchars(date('m/d/Y', strtotime($approvedDate))); ?></td>
                                    <td>
                                        <span class="status-pill <?php echo htmlspecialchars(adminStatusClass($requestStatus)); ?>">
                                            <?php echo htmlspecialchars(adminStatusLabel($requestStatus)); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="table-actions">
                                            <button type="button" class="verify-button open-modal-button" data-modal-target="<?php echo htmlspecialchars($approvedModalId); ?>">
                                                <i class="bi bi-eye"></i>
                                                <span>View</span>
                                            </button>
                                            <?php if ($requestStatus === 'printed'): ?>
                                                <form method="POST" action="../actions/updateRequestStatus.php">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                    <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
                                                    <input type="hidden" name="redirect_query" value="<?php echo htmlspecialchars($approvedRedirect); ?>">
                                                    <button type="submit" name="status" value="released" class="verify-button release-inline">
                                                        <i class="bi bi-send-check"></i>
                                                        <span>Mark Released</span>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                                <div class="modal-backdrop" id="<?php echo htmlspecialchars($approvedModalId); ?>" aria-hidden="true" hidden data-allow-backdrop="false">
                                            <div class="modal-panel request-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($approvedModalId); ?>Title">
                                                <div class="modal-header">
                                                    <div>
                                                        <h3 id="<?php echo htmlspecialchars($approvedModalId); ?>Title"><?php echo htmlspecialchars($requestNumber); ?></h3>
                                                        <p><?php echo htmlspecialchars($userName); ?> - <?php echo htmlspecialchars($request['document_type']); ?></p>
                                                    </div>
                                                    <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                                </div>
                                                <div class="modal-form request-modal-content">
                                                    <div class="certificate-preview-shell">
                                                        <div class="certificate-toolbar">
                                                            <span>Sample printable preview</span>
                                                            <button
                                                                type="button"
                                                                class="verify-button print-certificate-button"
                                                                data-print-target="<?php echo htmlspecialchars($certificatePreviewId); ?>"
                                                                data-request-id="<?php echo $requestId; ?>"
                                                                data-current-status="<?php echo htmlspecialchars($requestStatus); ?>"
                                                                data-csrf-token="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>"
                                                                data-redirect-query="<?php echo htmlspecialchars($approvedRedirect); ?>">
                                                                <i class="bi bi-printer"></i>
                                                                <span>Print</span>
                                                            </button>
                                                        </div>
                                                        <div class="certificate-sheet" id="<?php echo htmlspecialchars($certificatePreviewId); ?>">
                                                            <div class="certificate-topline">Republic of the Philippines</div>
                                                            <div class="certificate-topline">Quezon City</div>
                                                            <div class="certificate-barangay">Barangay Krus na Ligas</div>
                                                            <div class="certificate-office">Office of the Barangay Chairman</div>
                                                            <div class="certificate-seal-row">
                                                                <div class="certificate-seal">KNL</div>
                                                                <div>
                                                                    <h2><?php echo htmlspecialchars($certificateTitle); ?></h2>
                                                                    <p>Control No. <?php echo htmlspecialchars($requestNumber); ?></p>
                                                                </div>
                                                            </div>
                                                            <div class="certificate-body">
                                                                <p class="certificate-greeting">TO WHOM IT MAY CONCERN:</p>
                                                                <p><?php echo htmlspecialchars($certificateBody); ?></p>
                                                                <p>This sample document is issued upon the request of the above-named resident for system demonstration and checking purposes.</p>
                                                                <p>Issued this <?php echo htmlspecialchars($certificateDate); ?> at Barangay Krus na Ligas, Quezon City.</p>
                                                            </div>
                                                            <div class="certificate-signature-row">
                                                                <div>
                                                                    <span>Prepared by</span>
                                                                    <strong>Barangay Staff</strong>
                                                                </div>
                                                                <div>
                                                                    <span>Approved by</span>
                                                                    <strong>Barangay Chairman</strong>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php elseif ($activeSection === 'overview'): ?>
            <div class="overview-shell">
                <section class="overview-content-grid">
                    <div class="overview-card">
                        <h3>Recent Activity</h3>
                        <div class="overview-activity-list">
                            <?php if (empty($recentActivities)): ?>
                                <div class="overview-activity-item">
                                    <div class="overview-activity-left">
                                        <i class="bi bi-info-circle overview-activity-icon"></i>
                                        <div>
                                            <div class="overview-activity-row">
                                                <span class="overview-activity-user">System</span>
                                                <span class="overview-badge overview-badge-default">Info</span>
                                            </div>
                                            <span class="overview-activity-desc">No recent system activity yet.</span>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <?php foreach ($recentActivities as $activity): ?>
                                    <?php
                                    $activityAction = strtolower((string) ($activity['action'] ?? 'activity'));
                                    $activityIcon = 'bi-activity';
                                    $activityBadgeClass = 'overview-badge-default';
                                    $activityBadgeText = 'Activity';

                                    if ($activityAction === 'login') {
                                        $activityIcon = 'bi-box-arrow-in-right';
                                        $activityBadgeClass = 'overview-badge-login';
                                        $activityBadgeText = 'Login';
                                    } elseif ($activityAction === 'logout') {
                                        $activityIcon = 'bi-box-arrow-right';
                                        $activityBadgeClass = 'overview-badge-logout';
                                        $activityBadgeText = 'Logout';
                                    } elseif (strpos($activityAction, 'request_') === 0) {
                                        $activityIcon = 'bi-file-earmark-check';
                                        $activityBadgeClass = 'overview-badge-approved';
                                        $activityBadgeText = 'Request';
                                    } elseif (strpos($activityAction, 'verification_') === 0) {
                                        $activityIcon = 'bi-person-check';
                                        $activityBadgeClass = 'overview-badge-approved';
                                        $activityBadgeText = 'Verification';
                                    }
                                    ?>
                                    <div class="overview-activity-item">
                                        <div class="overview-activity-left">
                                            <i class="bi <?php echo htmlspecialchars($activityIcon); ?> overview-activity-icon"></i>
                                            <div>
                                                <div class="overview-activity-row">
                                                    <span class="overview-activity-user"><?php echo htmlspecialchars($activity['username'] ?? 'System'); ?></span>
                                                    <span class="overview-badge <?php echo htmlspecialchars($activityBadgeClass); ?>"><?php echo htmlspecialchars($activityBadgeText); ?></span>
                                                </div>
                                                <span class="overview-activity-desc"><?php echo htmlspecialchars(formatActivityLogDescription($conn, $activity['description'] ?? 'System activity')); ?></span>
                                            </div>
                                        </div>
                                        <div class="overview-activity-right">
                                            <span class="overview-activity-date"><?php echo htmlspecialchars(date('M d', strtotime($activity['created_at']))); ?></span>
                                            <span class="overview-activity-time"><?php echo htmlspecialchars(date('h:i A', strtotime($activity['created_at']))); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="overview-card">
                        <h3>System Status</h3>
                        <div class="overview-status-list">
                            <div class="overview-status-item overview-status-operational">
                                <span class="overview-status-label">System Status</span>
                                <span class="overview-status-value text-success">Operational</span>
                            </div>
                            <div class="overview-status-item overview-status-connected">
                                <span class="overview-status-label">Database</span>
                                <span class="overview-status-value text-info">Connected</span>
                            </div>
                            <div class="overview-status-item overview-status-notset">
                                <span class="overview-status-label">Last Backup</span>
                                <span class="overview-status-value text-warning">
                                    <?php echo !empty($recentBackups) ? htmlspecialchars(date('M d, h:i A', (int) $recentBackups[0]['date'])) : 'Not Set'; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <?php elseif ($activeSection === 'activity'): ?>
            <div class="activity-log-shell">
                <section class="activity-log-card">
                    <div class="card-heading activity-log-heading">
                        <div class="title-row">
                            <i class="bi bi-activity"></i>
                            <div>
                                <h2>Activity Log</h2>
                                <p>Track system activity and barangay operations</p>
                            </div>
                        </div>
                    </div>

                    <form class="filters-bar activity-log-filters" method="GET">
                        <input type="hidden" name="section" value="activity">
                        <div class="search-input-wrapper">
                            <i class="bi bi-search"></i>
                            <input type="search" name="activity_search" class="search-input" placeholder="Search by user, action, or details..." value="<?php echo htmlspecialchars($activitySearch); ?>" />
                        </div>
                        <button type="submit" class="dropdown-btn">Search <i class="bi bi-search"></i></button>
                    </form>

                    <div class="activity-list">
                        <?php if (empty($activityLogs)): ?>
                            <div class="activity-empty">No activity recorded yet.</div>
                        <?php else: ?>
                            <?php foreach ($activityLogs as $activity): ?>
                                <?php
                                $activityAction = strtolower((string) ($activity['action'] ?? 'activity'));
                                $activityIcon = 'bi-activity';
                                $activityBadgeClass = 'badge-info';
                                $activityBadgeText = 'Activity';
                                $activityStatusText = 'Info';

                                if ($activityAction === 'login') {
                                    $activityIcon = 'bi-box-arrow-in-right';
                                    $activityBadgeClass = 'badge-success';
                                    $activityBadgeText = 'Login';
                                    $activityStatusText = 'Success';
                                } elseif ($activityAction === 'logout') {
                                    $activityIcon = 'bi-box-arrow-right';
                                    $activityBadgeClass = 'badge-info';
                                    $activityBadgeText = 'Logout';
                                    $activityStatusText = 'Info';
                                } elseif (strpos($activityAction, 'request_') === 0) {
                                    $activityIcon = 'bi-file-earmark-check';
                                    $activityBadgeClass = 'badge-success';
                                    $activityBadgeText = 'Request';
                                    $activityStatusText = 'Success';
                                } elseif (strpos($activityAction, 'verification_') === 0) {
                                    $activityIcon = 'bi-person-check';
                                    $activityBadgeClass = 'badge-success';
                                    $activityBadgeText = 'Verification';
                                    $activityStatusText = 'Success';
                                }
                                ?>
                                <article class="activity-card">
                                    <div class="card-main">
                                        <div class="card-icon">
                                            <i class="bi <?php echo htmlspecialchars($activityIcon); ?>"></i>
                                        </div>
                                        <div class="card-info">
                                            <div class="card-meta">
                                                <span class="user-name"><?php echo htmlspecialchars($activity['username'] ?? 'System'); ?></span>
                                                <span class="separator">•</span>
                                                <span class="action-type"><?php echo htmlspecialchars($activityBadgeText); ?></span>
                                            </div>
                                            <p class="action-desc"><?php echo htmlspecialchars(formatActivityLogDescription($conn, $activity['description'] ?? 'System activity')); ?></p>
                                            <div class="action-time">
                                                <i class="bi bi-clock"></i>
                                                <time><?php echo htmlspecialchars(date('M d, Y, h:i A', strtotime($activity['created_at']))); ?></time>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-status">
                                        <span class="badge <?php echo htmlspecialchars($activityBadgeClass); ?>"><?php echo htmlspecialchars($activityStatusText); ?></span>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
            <?php else: ?>
            <div class="requests-card">
                <div class="card-heading">
                    <div class="title-row">
                        <i class="bi bi-file-earmark-text"></i>
                        <div>
                            <h2><?php echo $activeSection === 'pending' ? 'Pending Requests' : ($activeSection === 'archive' ? 'Archived Request History' : 'Request History'); ?></h2>
                            <p><?php echo $activeSection === 'pending' ? 'Newest pending document requests first' : ($activeSection === 'archive' ? 'Completed, printed, or rejected requests older than ' . $archiveCutoffDays . ' days' : 'Approved, printed, released, and rejected request history'); ?></p>
                        </div>
                    </div>

                    <form class="filter-form" method="GET">
                        <input type="hidden" name="section" value="<?php echo htmlspecialchars($activeSection); ?>">
                        <?php if ($activeSection === 'requests'): ?>
                            <select name="status" aria-label="Filter by status" onchange="this.form.submit()">
                                <?php foreach ($statusOptions as $value => $label): ?>
                                    <option value="<?php echo htmlspecialchars($value); ?>" <?php echo $statusFilter === $value ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                        <label class="search-box">
                            <i class="bi bi-search"></i>
                            <input type="search" name="search" placeholder="Search request..." value="<?php echo htmlspecialchars($search); ?>">
                        </label>
                    </form>
                </div>

                <div class="table-wrap">
                    <table class="requests-table">
                        <thead>
                            <tr>
                                <th>Request Number</th>
                                <th>Resident Name</th>
                                <th>Document Type</th>
                                <th>Purpose</th>
                                <th>Date Requested</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($requests)): ?>
                            <tr>
                                <td colspan="7" class="empty-cell"><?php echo $activeSection === 'pending' ? 'No pending document requests found.' : ($activeSection === 'archive' ? 'No archived request history found.' : 'No request history found.'); ?></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($requests as $request): ?>
                                <?php
                                $requestId = (int) $request['request_id'];
                                $requestNumber = $request['request_number'] ?: adminRequestNumber($requestId, $request['date_submitted']);
                                $residentName = trim(($request['firstName'] ?? '') . ' ' . ($request['lastName'] ?? ''));
                                $userName = $residentName ?: ($request['emailAddress'] ?: ($request['username'] ?? 'Unknown User'));
                                $dateRequested = $request['date_submitted'];
                                $requestModalId = 'requestReviewModal' . $requestId;
                                $requestRejectModalId = 'rejectRequestModal' . $requestId;
                                $requestFiles = fetchRequestFiles($conn, $requestId);
                                $requestRedirectData = ['section' => $activeSection, 'search' => $search];
                                if ($activeSection === 'requests') {
                                    $requestRedirectData['status'] = $statusFilter;
                                }
                                $requestRedirect = http_build_query($requestRedirectData);
                                $requestStatus = strtolower((string) ($request['status'] ?? 'pending'));
                                $canUpdateRequest = $requestStatus === 'pending';
                                ?>
                                <tr id="admin-request-<?php echo $requestId; ?>" class="<?php echo $requestId === $highlightRequestId ? 'request-highlight' : ''; ?>">
                                    <td><?php echo htmlspecialchars($requestNumber); ?></td>
                                    <td><span class="user-link"><?php echo htmlspecialchars($userName); ?></span></td>
                                    <td><?php echo htmlspecialchars($request['document_type']); ?></td>
                                    <td><?php echo htmlspecialchars($request['purpose'] ?: 'Not specified'); ?></td>
                                    <td><?php echo htmlspecialchars(date('m/d/Y', strtotime($dateRequested))); ?></td>
                                    <td>
                                        <span class="status-pill <?php echo htmlspecialchars(adminStatusClass($request['status'])); ?>">
                                            <?php echo htmlspecialchars(adminStatusLabel($request['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="table-actions">
                                            <button type="button" class="verify-button open-modal-button" data-modal-target="<?php echo htmlspecialchars($requestModalId); ?>">
                                                <i class="bi bi-eye"></i>
                                                <span><?php echo $activeSection === 'pending' ? 'View &amp; Verify' : 'View Details'; ?></span>
                                            </button>
                                        </div>
                                        <div class="modal-backdrop" id="<?php echo htmlspecialchars($requestModalId); ?>" aria-hidden="true" hidden data-allow-backdrop="false">
                                            <div class="modal-panel request-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($requestModalId); ?>Title">
                                                <div class="modal-header">
                                                    <div>
                                                        <h3 id="<?php echo htmlspecialchars($requestModalId); ?>Title"><?php echo htmlspecialchars($requestNumber); ?></h3>
                                                        <p><?php echo htmlspecialchars($userName); ?> - <?php echo htmlspecialchars(adminStatusLabel($request['status'])); ?></p>
                                                    </div>
                                                    <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                                </div>
                                                <div class="modal-form request-modal-content">
                                                    <div class="details-grid">
                                                        <div>
                                                            <span>Resident</span>
                                                            <strong><?php echo htmlspecialchars($userName); ?></strong>
                                                        </div>
                                                        <div>
                                                            <span>Email</span>
                                                            <strong><?php echo htmlspecialchars($request['emailAddress'] ?: 'Not provided'); ?></strong>
                                                        </div>
                                                        <div>
                                                            <span>Phone</span>
                                                            <strong><?php echo htmlspecialchars($request['phoneNumber'] ?: 'Not provided'); ?></strong>
                                                        </div>
                                                        <div>
                                                            <span>Status</span>
                                                            <strong><?php echo htmlspecialchars(adminStatusLabel($request['status'])); ?></strong>
                                                        </div>
                                                        <div>
                                                            <span>Document Type</span>
                                                            <strong><?php echo htmlspecialchars($request['document_type']); ?></strong>
                                                        </div>
                                                        <div>
                                                            <span>Date Requested</span>
                                                            <strong><?php echo htmlspecialchars(date('m/d/Y', strtotime($dateRequested))); ?></strong>
                                                        </div>
                                                        <div class="wide">
                                                            <span>Address</span>
                                                            <strong><?php echo htmlspecialchars($request['fullAddress'] ?: 'Not provided'); ?></strong>
                                                        </div>
                                                        <div class="wide">
                                                            <span>Purpose</span>
                                                            <strong><?php echo htmlspecialchars($request['purpose'] ?: 'Not specified'); ?></strong>
                                                        </div>
                                                    </div>

                                                    <div class="reason-note">
                                                        <strong>Status Message</strong>
                                                        <p><?php echo htmlspecialchars(adminStatusMessage($requestStatus)); ?></p>
                                                    </div>

                                                    <?php if (trim((string) ($request['admin_remarks'] ?? '')) !== ''): ?>
                                                        <div class="reason-note">
                                                            <strong>Message</strong>
                                                            <p><?php echo htmlspecialchars($request['admin_remarks']); ?></p>
                                                        </div>
                                                    <?php endif; ?>

                                                    <div class="requirements-box">
                                                        <span>Uploaded Requirements</span>
                                                        <?php if (empty($requestFiles)): ?>
                                                            <p>No uploaded files attached to this request.</p>
                                                        <?php else: ?>
                                                            <div class="file-list">
                                                                <?php foreach ($requestFiles as $file): ?>
                                                                    <?php
                                                                    $fileName = $file['file_name'] ?: basename((string) $file['file_path']);
                                                                    $filePath = '../' . ltrim((string) $file['file_path'], '/\\');
                                                                    ?>
                                                                    <a href="<?php echo htmlspecialchars($filePath); ?>" target="_blank" rel="noopener">
                                                                        <i class="bi bi-paperclip"></i>
                                                                        <?php echo htmlspecialchars($fileName); ?>
                                                                    </a>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>

                                                    <?php if ($canUpdateRequest): ?>
                                                        <div class="review-actions">
                                                            <form method="POST" action="../actions/updateRequestStatus.php">
                                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                                <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
                                                                <input type="hidden" name="redirect_query" value="<?php echo htmlspecialchars($requestRedirect); ?>">
                                                                <button type="submit" name="status" value="approved" class="add-user-button approve-submit"><i class="bi bi-check-circle"></i>Approve</button>
                                                            </form>
                                                            <button type="button" class="add-user-button reject-submit open-modal-button" data-modal-target="<?php echo htmlspecialchars($requestRejectModalId); ?>">
                                                                <i class="bi bi-x-circle"></i>Reject
                                                            </button>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if ($canUpdateRequest): ?>
                                            <div class="modal-backdrop" id="<?php echo htmlspecialchars($requestRejectModalId); ?>" aria-hidden="true" hidden>
                                                <div class="modal-panel reject-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($requestRejectModalId); ?>Title">
                                                    <div class="modal-header">
                                                        <div>
                                                            <h3 id="<?php echo htmlspecialchars($requestRejectModalId); ?>Title">Reject Request</h3>
                                                            <p><?php echo htmlspecialchars($requestNumber); ?></p>
                                                        </div>
                                                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                                    </div>
                                                    <form method="POST" action="../actions/updateRequestStatus.php" class="modal-form reject-review-form">
                                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                        <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
                                                        <input type="hidden" name="redirect_query" value="<?php echo htmlspecialchars($requestRedirect); ?>">
                                                        <label for="requestRejectReason<?php echo $requestId; ?>">Reason</label>
                                                        <textarea id="requestRejectReason<?php echo $requestId; ?>" name="admin_remarks" rows="4" placeholder="Example: Missing or invalid uploaded requirement." required></textarea>
                                                        <div class="reject-modal-actions">
                                                            <button type="button" class="modal-secondary-button" data-modal-close>Cancel</button>
                                                            <button type="submit" name="status" value="rejected" class="add-user-button reject-submit"><i class="bi bi-x-circle"></i>Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php endif; ?>
        </div>
    </section>
</main>

<!-- Edit current admin account modal -->
<div class="modal-backdrop" id="editSelfModal" aria-hidden="true" hidden>
    <div class="modal-panel edit-user-modal" role="dialog" aria-modal="true" aria-labelledby="editSelfModalTitle">
        <div class="modal-header">
            <div>
                <h3 id="editSelfModalTitle">Account Settings</h3>
                <p>Update your username or password</p>
            </div>
            <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
        </div>
        <form method="POST" action="../actions/updateSelf.php" class="modal-form">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <div>
                <label>Username</label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>" required>
            </div>
            <div>
                <label>Current Password (required to change password)</label>
                <input type="password" name="current_password" placeholder="Current password">
            </div>
            <div>
                <label>New Password (leave blank to keep current)</label>
                <input type="password" name="new_password" placeholder="New password">
            </div>
            <div style="margin-top:10px;">
                <button type="submit" class="add-user-button">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const params = new URLSearchParams(window.location.search);
    const highlightedUserId = params.get('highlight_user');
    const highlightedRequestId = params.get('highlight_request');

    const openModal = function (modal) {
        if (!modal) return;
        modal.hidden = false;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        const firstInput = modal.querySelector('input:not([type="hidden"]), select, textarea, button');
        if (firstInput) firstInput.focus();
    };

    const closeModal = function (modal) {
        if (!modal) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        modal.hidden = true;
    };

    document.querySelectorAll('[data-modal-target]').forEach(function (button) {
        button.addEventListener('click', function () {
            openModal(document.getElementById(button.dataset.modalTarget));
        });
    });

    const highlightedRow = highlightedUserId
        ? document.getElementById('admin-user-' + highlightedUserId)
        : (highlightedRequestId ? document.getElementById('admin-request-' + highlightedRequestId) : null);
    if (highlightedRow) {
        highlightedRow.classList.add('request-highlight');
        window.setTimeout(function () {
            highlightedRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 120);
    }

    const notificationToggle = document.querySelector('.notification-toggle');
    const notificationMenu = document.getElementById('adminNotificationMenu');
    const notificationBadge = document.querySelector('[data-notification-badge]');
    const notificationItems = Array.from(document.querySelectorAll('[data-notification-key]'));
    const notificationStorageKey = 'adminReadNotifications';
    let notificationReadKeys = [];

    try {
        notificationReadKeys = JSON.parse(window.localStorage.getItem(notificationStorageKey) || '[]');
    } catch (error) {
        notificationReadKeys = [];
    }

    const saveNotificationReadKeys = function () {
        window.localStorage.setItem(notificationStorageKey, JSON.stringify(notificationReadKeys));
    };

    const refreshNotificationBadge = function () {
        const unreadItems = notificationItems.filter(function (item) {
            return !notificationReadKeys.includes(item.dataset.notificationKey);
        });

        notificationItems.forEach(function (item) {
            item.classList.toggle('is-read', notificationReadKeys.includes(item.dataset.notificationKey));
        });

        if (notificationBadge) {
            if (unreadItems.length > 0) {
                notificationBadge.hidden = false;
                notificationBadge.textContent = unreadItems.length > 9 ? '9+' : String(unreadItems.length);
            } else {
                notificationBadge.hidden = true;
            }
        }
    };

    if (notificationToggle && notificationMenu) {
        notificationToggle.addEventListener('click', function (event) {
            event.stopPropagation();
            const willOpen = notificationMenu.hidden;
            notificationMenu.hidden = !willOpen;
            notificationToggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
        });

        document.addEventListener('click', function (event) {
            if (!notificationMenu.hidden && !notificationMenu.contains(event.target) && !notificationToggle.contains(event.target)) {
                notificationMenu.hidden = true;
                notificationToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    notificationItems.forEach(function (item) {
        item.addEventListener('click', function () {
            const key = item.dataset.notificationKey;
            if (key && !notificationReadKeys.includes(key)) {
                notificationReadKeys.push(key);
                saveNotificationReadKeys();
            }
        });
    });

    refreshNotificationBadge();

    const reportPrintButton = document.querySelector('[data-print-report]');
    if (reportPrintButton) {
        reportPrintButton.addEventListener('click', function () {
            window.print();
        });
    }

    document.querySelectorAll('.print-certificate-button').forEach(function (button) {
        button.addEventListener('click', function () {
            const certificate = document.getElementById(button.dataset.printTarget);
            if (!certificate) return;

            const markPrintedPromise = (button.dataset.currentStatus === 'approved' && button.dataset.requestId && button.dataset.csrfToken)
                ? (function () {
                    const statusData = new FormData();
                    statusData.append('request_id', button.dataset.requestId);
                    statusData.append('csrf_token', button.dataset.csrfToken);
                    statusData.append('status', 'printed');
                    statusData.append('redirect_query', button.dataset.redirectQuery || 'section=approved');

                    return window.fetch('../actions/updateRequestStatus.php', {
                        method: 'POST',
                        body: statusData,
                        credentials: 'same-origin'
                    }).then(function (response) {
                        if (response.ok) {
                            button.dataset.currentStatus = 'printed';
                            return true;
                        }
                        return false;
                    }).catch(function () {
                        return false;
                    });
                })()
                : Promise.resolve(false);

            const printWindow = window.open('', '_blank', 'width=900,height=1100');
            if (!printWindow) return;

            let refreshedAfterPrint = false;
            const refreshIfMarkedPrinted = function () {
                if (refreshedAfterPrint) return;
                refreshedAfterPrint = true;
                markPrintedPromise.then(function (shouldRefresh) {
                    if (shouldRefresh) {
                        window.setTimeout(function () {
                            window.location.reload();
                        }, 500);
                    }
                });
            };

            printWindow.document.write('<!doctype html><html><head><title>Print Certificate</title>');
            printWindow.document.write('<style>body{margin:0;padding:24px;background:#f3f4f6;font-family:Georgia,serif}.certificate-sheet{width:760px;min-height:980px;margin:0 auto;padding:56px;border:12px double #1f2937;background:#fff;color:#111827}.certificate-topline{text-align:center;font-size:14px}.certificate-barangay{text-align:center;font-size:28px;font-weight:800;text-transform:uppercase;margin-top:6px}.certificate-office{text-align:center;font-size:14px;margin-bottom:28px}.certificate-seal-row{display:flex;align-items:center;justify-content:center;gap:24px;margin:28px 0}.certificate-seal{width:86px;height:86px;border:3px solid #ef0004;border-radius:50%;display:grid;place-items:center;color:#ef0004;font-weight:800}.certificate-seal-row h2{margin:0;text-align:center;font-size:30px;text-transform:uppercase}.certificate-seal-row p{text-align:center;margin:8px 0 0}.certificate-body{font-size:18px;line-height:1.8;text-align:justify;margin-top:28px}.certificate-greeting{font-weight:800;text-align:left}.certificate-signature-row{display:flex;justify-content:space-between;gap:48px;margin-top:80px}.certificate-signature-row div{flex:1;text-align:center;border-top:1px solid #111827;padding-top:10px}.certificate-signature-row span{display:block;font-size:12px;text-transform:uppercase;color:#4b5563}.certificate-signature-row strong{font-size:16px;text-transform:uppercase}@media print{body{background:#fff;padding:0}.certificate-sheet{width:auto;min-height:auto;margin:0;border:10px double #111827;box-shadow:none}}</style>');
            printWindow.document.write('</head><body>' + certificate.outerHTML + '</body></html>');
            printWindow.document.close();
            printWindow.addEventListener('afterprint', refreshIfMarkedPrinted);
            printWindow.focus();
            printWindow.setTimeout(function () {
                printWindow.print();
                printWindow.setTimeout(refreshIfMarkedPrinted, 2500);
            }, 250);
        });
    });

    document.querySelectorAll('.open-template-modal').forEach(function (button) {
        button.addEventListener('click', function () {
            openModal(document.getElementById(button.dataset.templateModal));
        });
    });

    document.querySelectorAll('[data-modal-close]').forEach(function (button) {
        button.addEventListener('click', function () {
            closeModal(button.closest('.modal-backdrop'));
        });
    });

    document.querySelectorAll('.modal-backdrop').forEach(function (modal) {
        modal.addEventListener('click', function (event) {
            if (event.target === modal) {
                if (modal.dataset.allowBackdrop === 'false') return;
                closeModal(modal);
            }
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            document.querySelectorAll('.modal-backdrop.is-open').forEach(function (modal) {
                if (modal.dataset.allowBackdrop === 'false') return;
                closeModal(modal);
            });
        }
    });
});
</script>
</body>
</html>

<?php



require_once '../auth/session.php';
require_once '../config/db.php';
require_once '../helpers/functions.php';



if (!isset($_SESSION['user_id'])) {
    $_SESSION['errors'] = ["Please login to access the staff portal."];

    header("Location: ../pages/loginPage.php");
    exit();
}

if ($_SESSION['role'] !== 'staff') {
    header("Location: ../dashboard/" . $_SESSION['role'] . ".php");
    exit();
}

$displayName = $_SESSION['first_name'] ?? ($_SESSION['username'] ?? 'Staff User');

function staffUserColumnExists($conn, $columnName) {
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS column_count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = ?");
    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "s", $columnName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    return $row && (int) $row['column_count'] > 0;
}

if ($conn && isset($_SESSION['user_id']) && staffUserColumnExists($conn, 'first_name')) {
    $staffNameStmt = mysqli_prepare($conn, "SELECT first_name FROM users WHERE userId = ? LIMIT 1");
    if ($staffNameStmt) {
        $staffUserId = (int) $_SESSION['user_id'];
        mysqli_stmt_bind_param($staffNameStmt, "i", $staffUserId);
        mysqli_stmt_execute($staffNameStmt);
        $staffNameResult = mysqli_stmt_get_result($staffNameStmt);
        if ($staffNameRow = mysqli_fetch_assoc($staffNameResult)) {
            $staffFirstName = trim((string) ($staffNameRow['first_name'] ?? ''));
            if ($staffFirstName !== '') {
                $displayName = $staffFirstName;
                $_SESSION['first_name'] = $staffFirstName;
            }
        }
        mysqli_stmt_close($staffNameStmt);
    }
}

function staffRequestNumber($id, $dateSubmitted) {
    $year = $dateSubmitted ? date('Y', strtotime($dateSubmitted)) : date('Y');
    return 'REQ-' . $year . '-' . str_pad((string) $id, 3, '0', STR_PAD_LEFT);
}

function staffStatusLabel($status) {
    $labels = [
        'pending' => 'Pending',
        'approved' => 'Approved',
        'printed' => 'Printed',
        'rejected' => 'Rejected',
        'released' => 'Released',
    ];

    return $labels[$status] ?? ucfirst((string) $status);
}

function fetchStaffRequestFiles($conn, $requestId) {
    $files = [];
    $fileStmt = mysqli_prepare($conn, "SELECT file_name, file_path FROM document_request_files WHERE request_id = ? ORDER BY file_id ASC");
    if ($fileStmt) {
        mysqli_stmt_bind_param($fileStmt, "i", $requestId);
        mysqli_stmt_execute($fileStmt);
        $fileResult = mysqli_stmt_get_result($fileStmt);
        while ($fileRow = mysqli_fetch_assoc($fileResult)) {
            $files[] = $fileRow;
        }
        mysqli_stmt_close($fileStmt);
    }

    return $files;
}

function staffTableExists($conn, $tableName) {
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS table_count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "s", $tableName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    return $row && (int) $row['table_count'] > 0;
}

function staffComplaintStatusLabel($status) {
    $labels = [
        'pending' => 'Pending',
        'done' => 'Done',
    ];

    return $labels[$status] ?? ucfirst((string) $status);
}

$stats = [
    'total' => 0,
    'pending' => 0,
    'approved' => 0,
    'printed' => 0,
    'released' => 0,
    'rejected' => 0,
];

$statsSql = "SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count,
    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_count,
    SUM(CASE WHEN status = 'printed' THEN 1 ELSE 0 END) AS printed_count,
    SUM(CASE WHEN status = 'released' THEN 1 ELSE 0 END) AS released_count,
    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_count
    FROM document_requests";
$statsResult = mysqli_query($conn, $statsSql);
if ($statsResult && $row = mysqli_fetch_assoc($statsResult)) {
    $stats = [
        'total' => (int) $row['total'],
        'pending' => (int) $row['pending_count'],
        'approved' => (int) $row['approved_count'],
        'printed' => (int) $row['printed_count'],
        'released' => (int) $row['released_count'],
        'rejected' => (int) $row['rejected_count'],
    ];
}

$pendingRequests = [];
$pendingRequestsSql = "SELECT
        r.*,
        u.username,
        res.firstName,
        res.lastName,
        res.emailAddress,
        res.phoneNumber,
        res.fullAddress
    FROM document_requests r
    LEFT JOIN users u ON r.user_id = u.userId
    LEFT JOIN residents res ON u.residentId = res.residentId
    WHERE r.status = 'pending'
    ORDER BY r.date_submitted DESC, r.request_id DESC";
$pendingRequestsResult = mysqli_query($conn, $pendingRequestsSql);
if ($pendingRequestsResult) {
    while ($row = mysqli_fetch_assoc($pendingRequestsResult)) {
        $pendingRequests[] = $row;
    }
}

$staffNotifications = [];
foreach (array_slice($pendingRequests, 0, 8) as $notificationRequest) {
    $notificationRequestId = (int) ($notificationRequest['request_id'] ?? 0);
    $notificationRequestNumber = $notificationRequest['request_number'] ?: staffRequestNumber($notificationRequestId, $notificationRequest['date_submitted'] ?? '');
    $notificationResidentName = trim(($notificationRequest['firstName'] ?? '') . ' ' . ($notificationRequest['lastName'] ?? ''));
    $notificationResidentName = $notificationResidentName ?: ($notificationRequest['username'] ?? 'Resident');
    $notificationDate = (string) ($notificationRequest['date_submitted'] ?? '');
    $staffNotifications[] = [
        'key' => 'staff-request:' . $notificationRequestId . ':' . $notificationDate,
        'href' => 'staff.php?view=pending&highlight_request=' . $notificationRequestId,
        'message' => $notificationRequestNumber . ' from ' . $notificationResidentName . ' is waiting for review.',
        'date' => $notificationDate,
    ];
}

$approvedRequests = [];
$approvedRequestsSql = "SELECT
        r.*,
        u.username,
        res.firstName,
        res.lastName,
        res.emailAddress,
        res.phoneNumber,
        res.fullAddress
    FROM document_requests r
    LEFT JOIN users u ON r.user_id = u.userId
    LEFT JOIN residents res ON u.residentId = res.residentId
    WHERE r.status IN ('approved', 'printed')
    ORDER BY COALESCE(r.reviewed_at, r.date_updated) DESC, r.request_id DESC";
$approvedRequestsResult = mysqli_query($conn, $approvedRequestsSql);
if ($approvedRequestsResult) {
    while ($row = mysqli_fetch_assoc($approvedRequestsResult)) {
        $approvedRequests[] = $row;
    }
}

$templates = [];
$templateSql = "SELECT id, name, category, description, fee, usage_count, file_name, file_path, template_content, created_at, last_modified FROM document_templates ORDER BY last_modified DESC, id DESC";
$templateResult = mysqli_query($conn, $templateSql);
if ($templateResult) {
    while ($row = mysqli_fetch_assoc($templateResult)) {
        $templates[] = $row;
    }
}

$activityLogs = [];
$activityStmt = mysqli_prepare($conn, "SELECT user_id, username, role, action, description, created_at FROM activity_logs WHERE user_id = ? AND role = 'staff' ORDER BY created_at DESC LIMIT 12");
if ($activityStmt) {
    $staffUserId = (int) $_SESSION['user_id'];
    mysqli_stmt_bind_param($activityStmt, "i", $staffUserId);
    mysqli_stmt_execute($activityStmt);
    $activityResult = mysqli_stmt_get_result($activityStmt);
    while ($row = mysqli_fetch_assoc($activityResult)) {
        $activityLogs[] = $row;
    }
    mysqli_stmt_close($activityStmt);
}

$complaints = [];
$complaintsTableReady = $conn ? staffTableExists($conn, 'complaints') : false;
if ($complaintsTableReady) {
    $complaintsSql = "SELECT
            complaint_id,
            categories,
            location,
            description,
            attachment_name,
            attachment_path,
            status,
            created_at,
            updated_at,
            completed_at
        FROM complaints
        ORDER BY
            CASE WHEN status = 'pending' THEN 0 ELSE 1 END,
            created_at DESC,
            complaint_id DESC";
    $complaintsResult = mysqli_query($conn, $complaintsSql);
    if ($complaintsResult) {
        while ($row = mysqli_fetch_assoc($complaintsResult)) {
            $complaints[] = $row;
        }
    }
}

foreach (array_slice($complaints, 0, 8) as $notificationComplaint) {
    $notificationComplaintStatus = strtolower((string) ($notificationComplaint['status'] ?? 'pending'));
    if ($notificationComplaintStatus !== 'pending') {
        continue;
    }

    $notificationComplaintId = (int) ($notificationComplaint['complaint_id'] ?? 0);
    $notificationComplaintNo = 'CMP-' . str_pad((string) $notificationComplaintId, 4, '0', STR_PAD_LEFT);
    $notificationComplaintCategory = trim((string) ($notificationComplaint['categories'] ?? ''));
    $notificationComplaintDate = (string) ($notificationComplaint['created_at'] ?? '');
    $staffNotifications[] = [
        'key' => 'staff-complaint:' . $notificationComplaintId . ':' . $notificationComplaintDate,
        'href' => 'staff.php?view=complaints&highlight_complaint=' . $notificationComplaintId,
        'message' => $notificationComplaintNo . ' - ' . ($notificationComplaintCategory !== '' ? $notificationComplaintCategory : 'General Complaint') . ' is waiting for review.',
        'date' => $notificationComplaintDate,
    ];
}

usort($staffNotifications, function ($left, $right) {
    return strtotime($right['date'] ?? '') <=> strtotime($left['date'] ?? '');
});
$staffNotifications = array_slice($staffNotifications, 0, 10);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <link rel="stylesheet" href="../css/staff.css?v=20260824-printed-status">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.13.1/font/bootstrap-icons.min.css" integrity="sha512-t7Few9xlddEmgd3oKZQahkNI4dS6l80+eGEzFQiqtyVYdvcSG2D3Iub77R20BdotfRPA9caaRkg1tyaJiPmO0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <?php displayFlashMessages(); ?>

    <section id="section-header">
      <header class="site-header">
        <div class="container header-container">
          <div class="header-left">
            <h1 class="site-title">Staff Portal</h1>
            <p class="site-subtitle">Welcome, <?php echo htmlspecialchars($displayName); ?></p>
          </div>
          <div class="header-right">
            <div class="notification-wrap">
              <button class="icon-btn notification-toggle" type="button" aria-label="Notifications" aria-expanded="false" aria-controls="staffNotificationMenu">
                <i class="bi bi-bell"></i>
                <span class="notification-badge" data-notification-badge hidden>0</span>
              </button>
              <div class="notification-menu" id="staffNotificationMenu" hidden>
                <div class="notification-menu-header">
                  <strong>Notifications</strong>
                </div>
                <div class="notification-list" data-notification-list>
                  <?php if (empty($staffNotifications)): ?>
                    <div class="notification-empty">No new pending requests or complaints.</div>
                  <?php else: ?>
                    <?php foreach ($staffNotifications as $notification): ?>
                      <a
                        class="notification-item"
                        href="<?php echo htmlspecialchars($notification['href']); ?>"
                        data-notification-key="<?php echo htmlspecialchars($notification['key']); ?>"
                      >
                        <span class="notification-unread-dot" aria-hidden="true"></span>
                        <span><?php echo htmlspecialchars($notification['message']); ?></span>
                      </a>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <a class="logout-btn" href="../auth/logout.php">
              <i class="bi bi-box-arrow-right"></i>
              <span>Logout</span>
            </a>
          </div>
        </div>
      </header>
    </section>

    <section id="section-stats">
      <div class="container">
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-info">
              <span class="stat-label">Total Requests</span>
              <span class="stat-value" style="color: rgba(28, 57, 142, 0.4);"><?php echo (int) $stats['total']; ?></span>
            </div>
            <div class="stat-icon">
              <i class="bi bi-file-earmark-text"></i>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-info">
              <span class="stat-label">Pending</span>
              <span class="stat-value" style="color: rgba(126, 42, 12, 0.4);"><?php echo (int) $stats['pending']; ?></span>
            </div>
            <div class="stat-icon">
              <i class="bi bi-hourglass-split"></i>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-info">
              <span class="stat-label">Approved</span>
              <span class="stat-value" style="color: #0d542b;"><?php echo (int) $stats['approved']; ?></span>
            </div>
            <div class="stat-icon">
              <i class="bi bi-check-circle"></i>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-info">
              <span class="stat-label">Printed</span>
              <span class="stat-value" style="color: #7c3aed;"><?php echo (int) $stats['printed']; ?></span>
            </div>
            <div class="stat-icon">
              <i class="bi bi-printer"></i>
            </div>
          </div>
          <div class="stat-card">
            <div class="stat-info">
              <span class="stat-label">Released</span>
              <span class="stat-value" style="color: #1c398e;"><?php echo (int) $stats['released']; ?></span>
            </div>
            <div class="stat-icon">
              <i class="bi bi-send-check"></i>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="section-tabs">
      <div class="container">
        <div class="tabs-wrapper">
          <div class="tabs-container">
            <button type="button" class="tab-btn active" data-panel="pending">
              <i class="bi bi-clock-history"></i>
              <span>Pending Request</span>
            </button>
            <button type="button" class="tab-btn" data-panel="approved">
              <i class="bi bi-file-earmark-check"></i>
              <span>Approved Documents</span>
            </button>
            <button type="button" class="tab-btn" data-panel="activity">
              <i class="bi bi-activity"></i>
              <span>Activity Log</span>
            </button>
            <button type="button" class="tab-btn" data-panel="templates">
              <i class="bi bi-file-earmark-text"></i>
              <span>Document Templates</span>
            </button>
            <button type="button" class="tab-btn" data-panel="complaints">
              <div class="merged-icon-wrapper">
                <i class="bi bi-exclamation-circle icon-base"></i>
                <i class="bi bi-chat-dots icon-overlay"></i>
              </div>
              <span>Complaints</span>
            </button>
          </div>
        </div>
      </div>
    </section>

    <section id="section-list">
      <div class="container">
        <div class="staff-panel" id="staff-panel-pending">
          <div class="staff-card">
            <div class="section-card-heading">
              <div>
                <h2>Pending Requests</h2>
                <p>Review pending document requests from residents.</p>
              </div>
            </div>
            <div class="table-wrap">
              <table class="requests-table">
                <thead>
                  <tr>
                    <th>Request Number</th>
                    <th>Resident Name</th>
                    <th>Document Type</th>
                    <th>Purpose</th>
                    <th>Date Requested</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (empty($pendingRequests)): ?>
                    <tr>
                      <td colspan="7" class="empty-cell">No pending requests at the moment.</td>
                    </tr>
                  <?php else: ?>
                    <?php foreach ($pendingRequests as $request): ?>
                      <?php
                        $requestId = (int) ($request['request_id'] ?? 0);
                        $requestNumber = $request['request_number'] ?: staffRequestNumber($requestId, $request['date_submitted']);
                        $residentName = trim(($request['firstName'] ?? '') . ' ' . ($request['lastName'] ?? ''));
                        $userName = $residentName ?: ($request['emailAddress'] ?: ($request['username'] ?? 'Unknown User'));
                        $dateRequested = $request['date_submitted'];
                        $requestModalId = 'staffRequestReviewModal' . $requestId;
                        $requestRejectModalId = 'staffRejectRequestModal' . $requestId;
                        $requestFiles = fetchStaffRequestFiles($conn, $requestId);
                        $approveRedirect = http_build_query(['view' => 'approved']);
                        $pendingRedirect = http_build_query(['view' => 'pending']);
                      ?>
                      <tr id="staff-request-<?php echo $requestId; ?>" data-request-id="<?php echo $requestId; ?>">
                        <td><?php echo htmlspecialchars($requestNumber); ?></td>
                        <td><span class="user-link"><?php echo htmlspecialchars($userName); ?></span></td>
                        <td><?php echo htmlspecialchars($request['document_type'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($request['purpose'] ?: 'Not specified'); ?></td>
                        <td><?php echo htmlspecialchars($dateRequested ? date('m/d/Y', strtotime($dateRequested)) : 'N/A'); ?></td>
                        <td>
                          <span class="status-pill pending"><?php echo htmlspecialchars(staffStatusLabel($request['status'])); ?></span>
                        </td>
                        <td>
                          <button type="button" class="verify-button open-modal-button" data-modal-target="<?php echo htmlspecialchars($requestModalId); ?>">
                            <i class="bi bi-eye"></i>
                            <span>View &amp; Verify</span>
                          </button>
                          <div class="modal-backdrop" id="<?php echo htmlspecialchars($requestModalId); ?>" aria-hidden="true" hidden data-allow-backdrop="false">
                            <div class="modal-panel request-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($requestModalId); ?>Title">
                              <div class="modal-header">
                                <div>
                                  <h3 id="<?php echo htmlspecialchars($requestModalId); ?>Title"><?php echo htmlspecialchars($requestNumber); ?></h3>
                                  <p><?php echo htmlspecialchars($userName); ?> - <?php echo htmlspecialchars(staffStatusLabel($request['status'])); ?></p>
                                </div>
                                <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                              </div>
                              <div class="modal-form request-modal-content">
                                <div class="details-grid">
                                  <div>
                                    <span>Resident</span>
                                    <strong><?php echo htmlspecialchars($userName); ?></strong>
                                  </div>
                                  <div>
                                    <span>Email</span>
                                    <strong><?php echo htmlspecialchars($request['emailAddress'] ?: 'Not provided'); ?></strong>
                                  </div>
                                  <div>
                                    <span>Phone</span>
                                    <strong><?php echo htmlspecialchars($request['phoneNumber'] ?: 'Not provided'); ?></strong>
                                  </div>
                                  <div>
                                    <span>Status</span>
                                    <strong><?php echo htmlspecialchars(staffStatusLabel($request['status'])); ?></strong>
                                  </div>
                                  <div>
                                    <span>Document Type</span>
                                    <strong><?php echo htmlspecialchars($request['document_type'] ?? 'N/A'); ?></strong>
                                  </div>
                                  <div>
                                    <span>Date Requested</span>
                                    <strong><?php echo htmlspecialchars($dateRequested ? date('m/d/Y', strtotime($dateRequested)) : 'N/A'); ?></strong>
                                  </div>
                                  <div class="wide">
                                    <span>Address</span>
                                    <strong><?php echo htmlspecialchars($request['fullAddress'] ?: 'Not provided'); ?></strong>
                                  </div>
                                  <div class="wide">
                                    <span>Purpose</span>
                                    <strong><?php echo htmlspecialchars($request['purpose'] ?: 'Not specified'); ?></strong>
                                  </div>
                                </div>

                                <div class="requirements-box">
                                  <span>Uploaded Requirements</span>
                                  <?php if (empty($requestFiles)): ?>
                                    <p>No uploaded files attached to this request.</p>
                                  <?php else: ?>
                                    <div class="file-list">
                                      <?php foreach ($requestFiles as $file): ?>
                                        <?php
                                          $fileName = $file['file_name'] ?: basename((string) $file['file_path']);
                                          $filePath = '../' . ltrim((string) $file['file_path'], '/\\');
                                        ?>
                                        <a href="<?php echo htmlspecialchars($filePath); ?>" target="_blank" rel="noopener">
                                          <i class="bi bi-paperclip"></i>
                                          <?php echo htmlspecialchars($fileName); ?>
                                        </a>
                                      <?php endforeach; ?>
                                    </div>
                                  <?php endif; ?>
                                </div>

                                <div class="review-actions">
                                  <form method="POST" action="../actions/updateRequestStatus.php">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                    <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
                                    <input type="hidden" name="redirect_query" value="<?php echo htmlspecialchars($approveRedirect); ?>">
                                    <button type="submit" name="status" value="approved" class="add-user-button approve-submit"><i class="bi bi-check-circle"></i>Approve</button>
                                  </form>
                                  <button type="button" class="add-user-button reject-submit open-modal-button" data-modal-target="<?php echo htmlspecialchars($requestRejectModalId); ?>">
                                    <i class="bi bi-x-circle"></i>Reject
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="modal-backdrop" id="<?php echo htmlspecialchars($requestRejectModalId); ?>" aria-hidden="true" hidden>
                            <div class="modal-panel reject-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($requestRejectModalId); ?>Title">
                              <div class="modal-header">
                                <div>
                                  <h3 id="<?php echo htmlspecialchars($requestRejectModalId); ?>Title">Reject Request</h3>
                                  <p><?php echo htmlspecialchars($requestNumber); ?></p>
                                </div>
                                <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                              </div>
                              <form method="POST" action="../actions/updateRequestStatus.php" class="modal-form reject-review-form">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
                                <input type="hidden" name="redirect_query" value="<?php echo htmlspecialchars($pendingRedirect); ?>">
                                <label for="staffRequestRejectReason<?php echo $requestId; ?>">Reason</label>
                                <textarea id="staffRequestRejectReason<?php echo $requestId; ?>" name="admin_remarks" rows="4" placeholder="Example: Missing or invalid uploaded requirement." required></textarea>
                                <div class="reject-modal-actions">
                                  <button type="button" class="modal-secondary-button" data-modal-close>Cancel</button>
                                  <button type="submit" name="status" value="rejected" class="add-user-button reject-submit"><i class="bi bi-x-circle"></i>Submit</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="staff-panel" id="staff-panel-approved" hidden>
          <div class="staff-card">
            <div class="section-card-heading">
              <div>
                <h2>Approved Documents</h2>
                <p>Approved and printed document requests ready for the next step.</p>
              </div>
            </div>
            <div class="table-wrap">
              <table class="requests-table">
                <thead>
                  <tr>
                    <th>Request Number</th>
                    <th>Resident Name</th>
                    <th>Document Type</th>
                    <th>Purpose</th>
                    <th>Processed Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (empty($approvedRequests)): ?>
                    <tr>
                      <td colspan="7" class="empty-cell">No approved or printed documents found.</td>
                    </tr>
                  <?php else: ?>
                    <?php foreach ($approvedRequests as $request): ?>
                      <?php
                        $requestId = (int) ($request['request_id'] ?? 0);
                        $requestNumber = $request['request_number'] ?: staffRequestNumber($requestId, $request['date_submitted']);
                        $residentName = trim(($request['firstName'] ?? '') . ' ' . ($request['lastName'] ?? ''));
                        $userName = $residentName ?: ($request['emailAddress'] ?: ($request['username'] ?? 'Unknown User'));
                        $approvedDate = $request['reviewed_at'] ?: $request['date_updated'];
                        $requestStatus = strtolower((string) ($request['status'] ?? 'approved'));
                        $approvedModalId = 'staffApprovedDocModal' . $requestId;
                        $requestFiles = fetchStaffRequestFiles($conn, $requestId);
                        $approvedRedirect = http_build_query(['view' => 'approved']);
                        $certificateTitle = strtoupper((string) ($request['document_type'] ?? 'Barangay Certificate'));
                        $certificateAddress = trim((string) ($request['fullAddress'] ?? 'Barangay Krus na Ligas, Quezon City'));
                        $certificatePurpose = trim((string) ($request['purpose'] ?? 'official purposes'));
                        $certificateDate = $approvedDate ? date('F d, Y', strtotime($approvedDate)) : date('F d, Y');
                        $certificateBody = 'This is to certify that ' . $userName . ', of legal age and a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ', has requested this document for ' . ($certificatePurpose !== '' ? $certificatePurpose : 'official purposes') . '.';
                        if (stripos($certificateTitle, 'INDIGENCY') !== false) {
                          $certificateBody = 'This is to certify that ' . $userName . ', a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ', is known to this office and may be considered for assistance subject to validation by the receiving agency.';
                        } elseif (stripos($certificateTitle, 'RESIDENCY') !== false) {
                          $certificateBody = 'This is to certify that ' . $userName . ' is a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ' based on available barangay records.';
                        } elseif (stripos($certificateTitle, 'CLEARANCE') !== false) {
                          $certificateBody = 'This is to certify that ' . $userName . ', a resident of ' . ($certificateAddress !== '' ? $certificateAddress : 'Barangay Krus na Ligas, Quezon City') . ', has requested barangay clearance for ' . ($certificatePurpose !== '' ? $certificatePurpose : 'official purposes') . '.';
                        }
                        $certificatePreviewId = 'staffCertificatePreview' . $requestId;
                      ?>
                      <tr>
                        <td><?php echo htmlspecialchars($requestNumber); ?></td>
                        <td><span class="user-link"><?php echo htmlspecialchars($userName); ?></span></td>
                        <td><?php echo htmlspecialchars($request['document_type'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($request['purpose'] ?: 'Not specified'); ?></td>
                        <td><?php echo htmlspecialchars($approvedDate ? date('m/d/Y', strtotime($approvedDate)) : 'N/A'); ?></td>
                        <td>
                          <span class="status-pill <?php echo htmlspecialchars($requestStatus); ?>">
                            <?php echo htmlspecialchars(staffStatusLabel($requestStatus)); ?>
                          </span>
                        </td>
                        <td>
                          <div class="table-actions">
                            <button type="button" class="verify-button open-modal-button" data-modal-target="<?php echo htmlspecialchars($approvedModalId); ?>">
                              <i class="bi bi-eye"></i>
                              <span>View</span>
                            </button>
                            <?php if ($requestStatus === 'printed'): ?>
                              <form method="POST" action="../actions/updateRequestStatus.php">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
                                <input type="hidden" name="redirect_query" value="<?php echo htmlspecialchars($approvedRedirect); ?>">
                                <button type="submit" name="status" value="released" class="verify-button release-inline">
                                  <i class="bi bi-send-check"></i>
                                  <span>Mark Released</span>
                                </button>
                              </form>
                            <?php endif; ?>
                          </div>
                          <div class="modal-backdrop" id="<?php echo htmlspecialchars($approvedModalId); ?>" aria-hidden="true" hidden data-allow-backdrop="false">
                            <div class="modal-panel request-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($approvedModalId); ?>Title">
                              <div class="modal-header">
                                <div>
                                  <h3 id="<?php echo htmlspecialchars($approvedModalId); ?>Title"><?php echo htmlspecialchars($requestNumber); ?></h3>
                                  <p><?php echo htmlspecialchars($userName); ?> - <?php echo htmlspecialchars($request['document_type'] ?? 'Document'); ?></p>
                                </div>
                                <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                              </div>
                              <div class="modal-form request-modal-content">
                                <div class="certificate-preview-shell">
                                  <div class="certificate-toolbar">
                                    <span>Sample printable preview</span>
                                    <button
                                      type="button"
                                      class="verify-button print-certificate-button"
                                      data-print-target="<?php echo htmlspecialchars($certificatePreviewId); ?>"
                                      data-request-id="<?php echo $requestId; ?>"
                                      data-current-status="<?php echo htmlspecialchars($requestStatus); ?>"
                                      data-csrf-token="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>"
                                      data-redirect-query="<?php echo htmlspecialchars($approvedRedirect); ?>">
                                      <i class="bi bi-printer"></i>
                                      <span>Print</span>
                                    </button>
                                  </div>
                                  <div class="certificate-sheet" id="<?php echo htmlspecialchars($certificatePreviewId); ?>">
                                    <div class="certificate-topline">Republic of the Philippines</div>
                                    <div class="certificate-topline">Quezon City</div>
                                    <div class="certificate-barangay">Barangay Krus na Ligas</div>
                                    <div class="certificate-office">Office of the Barangay Chairman</div>
                                    <div class="certificate-seal-row">
                                      <div class="certificate-seal">KNL</div>
                                      <div>
                                        <h2><?php echo htmlspecialchars($certificateTitle); ?></h2>
                                        <p>Control No. <?php echo htmlspecialchars($requestNumber); ?></p>
                                      </div>
                                    </div>
                                    <div class="certificate-body">
                                      <p class="certificate-greeting">TO WHOM IT MAY CONCERN:</p>
                                      <p><?php echo htmlspecialchars($certificateBody); ?></p>
                                      <p>This sample document is issued upon the request of the above-named resident for system demonstration and checking purposes.</p>
                                      <p>Issued this <?php echo htmlspecialchars($certificateDate); ?> at Barangay Krus na Ligas, Quezon City.</p>
                                    </div>
                                    <div class="certificate-signature-row">
                                      <div>
                                        <span>Prepared by</span>
                                        <strong>Barangay Staff</strong>
                                      </div>
                                      <div>
                                        <span>Approved by</span>
                                        <strong>Barangay Chairman</strong>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="staff-panel" id="staff-panel-activity" hidden>
          <div class="staff-card">
            <div class="section-card-heading">
              <div>
                <h2>Activity Log</h2>
                <p>Track recent system activity and staff actions.</p>
              </div>
            </div>
            <div class="activity-list">
              <?php if (!empty($activityLogs)): ?>
                <?php foreach ($activityLogs as $activity): ?>
                  <?php
                    $activityAction = strtolower((string) ($activity['action'] ?? 'activity'));
                    $activityIcon = 'bi-activity';
                    $activityBadgeClass = 'badge-info';
                    $activityBadgeText = 'Activity';
                    $activityStatusText = 'Info';

                    if ($activityAction === 'login') {
                      $activityIcon = 'bi-box-arrow-in-right';
                      $activityBadgeClass = 'badge-success';
                      $activityBadgeText = 'Login';
                      $activityStatusText = 'Success';
                    } elseif ($activityAction === 'logout') {
                      $activityIcon = 'bi-box-arrow-right';
                      $activityBadgeClass = 'badge-info';
                      $activityBadgeText = 'Logout';
                      $activityStatusText = 'Info';
                    } elseif (strpos($activityAction, 'request_') === 0) {
                      $activityIcon = 'bi-file-earmark-check';
                      $activityBadgeClass = 'badge-success';
                      $activityBadgeText = 'Request';
                      $activityStatusText = 'Success';
                    } elseif (strpos($activityAction, 'verification_') === 0) {
                      $activityIcon = 'bi-person-check';
                      $activityBadgeClass = 'badge-success';
                      $activityBadgeText = 'Verification';
                      $activityStatusText = 'Success';
                    } elseif (strpos($activityAction, 'complaint_') === 0) {
                      $activityIcon = 'bi-chat-dots';
                      $activityBadgeClass = 'badge-info';
                      $activityBadgeText = 'Complaint';
                      $activityStatusText = 'Info';
                    }
                  ?>
                  <article class="activity-card">
                    <div class="activity-card-main">
                      <div class="activity-icon">
                        <i class="bi <?php echo htmlspecialchars($activityIcon); ?>"></i>
                      </div>
                      <div class="activity-info">
                        <div class="activity-meta">
                          <span class="activity-user"><?php echo htmlspecialchars($activity['username'] ?? 'System'); ?></span>
                          <span class="separator">•</span>
                          <span class="activity-type"><?php echo htmlspecialchars($activityBadgeText); ?></span>
                        </div>
                        <p class="activity-desc"><?php echo htmlspecialchars(formatActivityLogDescription($conn, $activity['description'] ?? 'System activity')); ?></p>
                        <div class="activity-time">
                          <i class="bi bi-clock"></i>
                          <time><?php echo htmlspecialchars(date('M d, Y, h:i A', strtotime($activity['created_at']))); ?></time>
                        </div>
                      </div>
                    </div>
                    <div class="activity-status">
                      <span class="badge <?php echo htmlspecialchars($activityBadgeClass); ?>"><?php echo htmlspecialchars($activityStatusText); ?></span>
                    </div>
                  </article>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="activity-empty">No activity recorded yet.</div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="staff-panel" id="staff-panel-templates" hidden>
          <div class="staff-card">
            <div class="section-card-heading">
              <div>
                <h2>Document Templates</h2>
                <p>Manage barangay document templates and requirements</p>
              </div>
              <button type="button" class="btn-primary open-template-modal" data-template-modal="createTemplateModal">
                <i class="bi bi-plus-lg"></i>
                <span>Create Template</span>
              </button>
            </div>
            <div class="cards-grid">
              <?php if (!empty($templates)): ?>
                <?php foreach ($templates as $template): ?>
                  <?php
                    $templateId = (int) ($template['id'] ?? 0);
                    $fee = number_format((float) ($template['fee'] ?? 0), 2);
                    $lastModified = $template['last_modified'] ?: $template['created_at'];
                    $isFree = (float) ($template['fee'] ?? 0) === 0.0;
                    $templateModalId = 'editTemplateModal' . $templateId;
                    $deleteModalId = 'deleteTemplateModal' . $templateId;
                  ?>
                  <article class="template-card">
                    <div class="card-header">
                      <div class="card-icon">
                        <i class="bi bi-file-earmark-text"></i>
                      </div>
                      <div class="card-title-group">
                        <h3><?php echo htmlspecialchars($template['name'] ?? 'Untitled'); ?></h3>
                        <span class="badge"><?php echo htmlspecialchars($template['category'] ?? 'General'); ?></span>
                      </div>
                    </div>
                    <p class="card-desc"><?php echo htmlspecialchars($template['description'] ?: 'Template description coming soon.'); ?></p>
                    <div class="card-details">
                      <div class="detail-labels">
                        <span>Fee:</span>
                        <span>Usage:</span>
                        <span>Last Modified:</span>
                      </div>
                      <div class="detail-values">
                        <span class="<?php echo $isFree ? 'text-blue' : 'text-green'; ?>"><?php echo $isFree ? 'Free' : '₱' . htmlspecialchars($fee); ?></span>
                        <span><?php echo (int) ($template['usage_count'] ?? 0); ?> times</span>
                        <span class="text-dark-gray"><?php echo htmlspecialchars(date('M d, Y', strtotime($lastModified))); ?></span>
                      </div>
                    </div>
                    <div class="card-actions">
                      <?php if (!empty($template['file_path'])): ?>
                        <a class="btn-secondary btn-view" href="../<?php echo htmlspecialchars($template['file_path']); ?>" target="_blank" rel="noopener">
                          <i class="bi bi-download"></i>
                          <span>View</span>
                        </a>
                      <?php else: ?>
                        <button type="button" class="btn-secondary btn-view" disabled>No File</button>
                      <?php endif; ?>
                      <button type="button" class="btn-icon open-template-modal" data-template-modal="<?php echo htmlspecialchars($templateModalId); ?>" aria-label="Edit">
                        <i class="bi bi-pencil"></i>
                      </button>
                      <button type="button" class="btn-icon open-template-modal" data-template-modal="<?php echo htmlspecialchars($deleteModalId); ?>" aria-label="Delete">
                        <i class="bi bi-trash"></i>
                      </button>
                    </div>
                  </article>

                  <div class="modal-backdrop" id="<?php echo htmlspecialchars($templateModalId); ?>" aria-hidden="true" hidden>
                    <div class="modal-panel template-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($templateModalId); ?>Title">
                      <div class="modal-header">
                        <div>
                          <h3 id="<?php echo htmlspecialchars($templateModalId); ?>Title">Edit Template</h3>
                          <p><?php echo htmlspecialchars($template['name'] ?? 'Untitled'); ?></p>
                        </div>
                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                      </div>
                      <form class="modal-form template-form" method="POST" action="../actions/manageDocumentTemplate.php" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="template_id" value="<?php echo $templateId; ?>">
                        <label>Template Name</label>
                        <input type="text" name="name" value="<?php echo htmlspecialchars($template['name'] ?? ''); ?>" required>
                        <label>Category</label>
                        <input type="text" name="category" value="<?php echo htmlspecialchars($template['category'] ?? ''); ?>" required>
                        <label>Description</label>
                        <textarea name="description" rows="3"><?php echo htmlspecialchars($template['description'] ?? ''); ?></textarea>
                        <label>Fee (₱)</label>
                        <input type="number" step="0.01" min="0" name="fee" value="<?php echo htmlspecialchars((string) ($template['fee'] ?? 0)); ?>">
                        <label>Template Content / Notes</label>
                        <textarea name="template_content" rows="4" placeholder="Add the editable wording for this template."><?php echo htmlspecialchars($template['template_content'] ?? ''); ?></textarea>
                        <label>Upload Word/PDF/TXT File (optional)</label>
                        <input type="file" name="template_file" accept=".doc,.docx,.pdf,.txt">
                        <button type="submit" class="add-user-button"><i class="bi bi-check-circle"></i>Save Changes</button>
                      </form>
                    </div>
                  </div>

                  <div class="modal-backdrop" id="<?php echo htmlspecialchars($deleteModalId); ?>" aria-hidden="true" hidden>
                    <div class="modal-panel template-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($deleteModalId); ?>Title">
                      <div class="modal-header">
                        <div>
                          <h3 id="<?php echo htmlspecialchars($deleteModalId); ?>Title">Delete Template</h3>
                          <p><?php echo htmlspecialchars($template['name'] ?? 'Untitled'); ?></p>
                        </div>
                        <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                      </div>
                      <form class="modal-form template-form" method="POST" action="../actions/manageDocumentTemplate.php">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="template_id" value="<?php echo $templateId; ?>">
                        <p class="delete-template-message">Are you sure you want to delete this template?</p>
                        <button type="submit" class="add-user-button reject-submit"><i class="bi bi-trash"></i>Delete Template</button>
                      </form>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="template-card empty-template-card">
                  <p>No templates available yet.</p>
                </div>
              <?php endif; ?>
            </div>

            <div class="modal-backdrop" id="createTemplateModal" aria-hidden="true" hidden>
              <div class="modal-panel template-modal" role="dialog" aria-modal="true" aria-labelledby="createTemplateModalTitle">
                <div class="modal-header">
                  <div>
                    <h3 id="createTemplateModalTitle">Create Template</h3>
                    <p>Add a new document template and upload a file if needed.</p>
                  </div>
                  <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                </div>
                <form class="modal-form template-form" method="POST" action="../actions/manageDocumentTemplate.php" enctype="multipart/form-data">
                  <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                  <input type="hidden" name="action" value="create">
                  <label>Template Name</label>
                  <input type="text" name="name" placeholder="e.g. Barangay Clearance" required>
                  <label>Category</label>
                  <input type="text" name="category" placeholder="e.g. Certificates" required>
                  <label>Description</label>
                  <textarea name="description" rows="3" placeholder="Short description of the template"></textarea>
                  <label>Fee (₱)</label>
                  <input type="number" step="0.01" min="0" name="fee" value="0">
                  <label>Template Content / Notes</label>
                  <textarea name="template_content" rows="4" placeholder="Add the wording or instructions for the template."></textarea>
                  <label>Upload Word/PDF/TXT File (optional)</label>
                  <input type="file" name="template_file" accept=".doc,.docx,.pdf,.txt">
                  <button type="submit" class="add-user-button"><i class="bi bi-plus-lg"></i>Create Template</button>
                </form>
              </div>
            </div>
          </div>
        </div>

        <div class="staff-panel" id="staff-panel-complaints" hidden>
          <div class="staff-card">
            <div class="section-card-heading">
              <div>
                <h2>Complaints</h2>
                <p>Pending complaints are shown first, then the newest completed complaints.</p>
              </div>
            </div>
            <?php if (!$complaintsTableReady): ?>
              <div class="activity-empty">Complaints table is not installed yet. Run the SQL script first to start receiving complaints.</div>
            <?php else: ?>
              <div class="table-wrap">
                <table class="requests-table complaints-table">
                  <thead>
                    <tr>
                      <th>Complaint No.</th>
                      <th>Complaint</th>
                      <th>Location</th>
                      <th>Date Submitted</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (empty($complaints)): ?>
                      <tr>
                        <td colspan="6" class="empty-cell">No complaints recorded yet.</td>
                      </tr>
                    <?php else: ?>
                      <?php foreach ($complaints as $complaint): ?>
                        <?php
                          $complaintId = (int) ($complaint['complaint_id'] ?? 0);
                          $complaintNo = 'CMP-' . str_pad((string) $complaintId, 4, '0', STR_PAD_LEFT);
                          $complaintStatus = strtolower((string) ($complaint['status'] ?? 'pending'));
                          $complaintModalId = 'staffComplaintModal' . $complaintId;
                          $complaintRedirect = http_build_query(['view' => 'complaints']);
                          $complaintDate = $complaint['created_at'] ?? '';
                          $attachmentPath = trim((string) ($complaint['attachment_path'] ?? ''));
                          $attachmentName = trim((string) ($complaint['attachment_name'] ?? '')) ?: basename($attachmentPath);
                          $categories = trim((string) ($complaint['categories'] ?? ''));
                        ?>
                        <tr id="staff-complaint-<?php echo $complaintId; ?>" data-complaint-id="<?php echo $complaintId; ?>">
                          <td><?php echo htmlspecialchars($complaintNo); ?></td>
                          <td><?php echo htmlspecialchars($categories !== '' ? $categories : 'General Complaint'); ?></td>
                          <td><?php echo htmlspecialchars($complaint['location'] ?: 'Not provided'); ?></td>
                          <td><?php echo htmlspecialchars($complaintDate ? date('m/d/Y h:i A', strtotime($complaintDate)) : 'N/A'); ?></td>
                          <td>
                            <span class="status-pill <?php echo htmlspecialchars($complaintStatus); ?>"><?php echo htmlspecialchars(staffComplaintStatusLabel($complaintStatus)); ?></span>
                          </td>
                          <td>
                            <div class="table-actions">
                              <button type="button" class="verify-button open-modal-button" data-modal-target="<?php echo htmlspecialchars($complaintModalId); ?>">
                                <i class="bi bi-eye"></i>
                                <span>View</span>
                              </button>
                              <form method="POST" action="../actions/updateComplaintStatus.php">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                <input type="hidden" name="complaint_id" value="<?php echo $complaintId; ?>">
                                <input type="hidden" name="redirect_query" value="<?php echo htmlspecialchars($complaintRedirect); ?>">
                                <?php if ($complaintStatus === 'pending'): ?>
                                  <button type="submit" name="status" value="done" class="verify-button done-inline">
                                    <i class="bi bi-check2-circle"></i>
                                    <span>Mark Done</span>
                                  </button>
                                <?php else: ?>
                                  <button type="submit" name="status" value="pending" class="verify-button pending-inline">
                                    <i class="bi bi-arrow-counterclockwise"></i>
                                    <span>Reopen</span>
                                  </button>
                                <?php endif; ?>
                              </form>
                            </div>

                            <div class="modal-backdrop" id="<?php echo htmlspecialchars($complaintModalId); ?>" aria-hidden="true" hidden data-allow-backdrop="false">
                              <div class="modal-panel request-modal" role="dialog" aria-modal="true" aria-labelledby="<?php echo htmlspecialchars($complaintModalId); ?>Title">
                                <div class="modal-header">
                                  <div>
                                    <h3 id="<?php echo htmlspecialchars($complaintModalId); ?>Title"><?php echo htmlspecialchars($complaintNo); ?></h3>
                                    <p><?php echo htmlspecialchars(staffComplaintStatusLabel($complaintStatus)); ?> complaint</p>
                                  </div>
                                  <button type="button" class="modal-close" data-modal-close aria-label="Close modal"><i class="bi bi-x-lg"></i></button>
                                </div>
                                <div class="modal-form request-modal-content">
                                  <div class="details-grid">
                                    <div>
                                      <span>Status</span>
                                      <strong><?php echo htmlspecialchars(staffComplaintStatusLabel($complaintStatus)); ?></strong>
                                    </div>
                                    <div>
                                      <span>Date Submitted</span>
                                      <strong><?php echo htmlspecialchars($complaintDate ? date('M d, Y h:i A', strtotime($complaintDate)) : 'N/A'); ?></strong>
                                    </div>
                                    <div>
                                      <span>Last Updated</span>
                                      <strong><?php echo htmlspecialchars(!empty($complaint['updated_at']) ? date('M d, Y h:i A', strtotime($complaint['updated_at'])) : 'N/A'); ?></strong>
                                    </div>
                                    <div>
                                      <span>Completed</span>
                                      <strong><?php echo htmlspecialchars(!empty($complaint['completed_at']) ? date('M d, Y h:i A', strtotime($complaint['completed_at'])) : 'Not yet'); ?></strong>
                                    </div>
                                    <div class="wide">
                                      <span>Complaint</span>
                                      <strong><?php echo htmlspecialchars($categories !== '' ? $categories : 'General Complaint'); ?></strong>
                                    </div>
                                    <div class="wide">
                                      <span>Location</span>
                                      <strong><?php echo htmlspecialchars($complaint['location'] ?: 'Not provided'); ?></strong>
                                    </div>
                                    <div class="wide">
                                      <span>Details</span>
                                      <strong><?php echo nl2br(htmlspecialchars($complaint['description'] ?: 'No additional details provided.')); ?></strong>
                                    </div>
                                  </div>

                                  <div class="requirements-box">
                                    <span>Attachment</span>
                                    <?php if ($attachmentPath === ''): ?>
                                      <p>No file uploaded.</p>
                                    <?php else: ?>
                                      <div class="file-list">
                                        <a href="../<?php echo htmlspecialchars(ltrim($attachmentPath, '/\\')); ?>" target="_blank" rel="noopener">
                                          <i class="bi bi-paperclip"></i>
                                          <?php echo htmlspecialchars($attachmentName); ?>
                                        </a>
                                      </div>
                                    <?php endif; ?>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>

    <script>
      document.addEventListener('DOMContentLoaded', function () {
        const params = new URLSearchParams(window.location.search);
        const requestedPanel = params.get('view') || params.get('section') || 'pending';
        const highlightedRequestId = params.get('highlight_request');
        const highlightedComplaintId = params.get('highlight_complaint');
        const normalizedPanel = requestedPanel === 'approved' || requestedPanel === 'templates' || requestedPanel === 'activity' || requestedPanel === 'complaints'
          ? requestedPanel
          : 'pending';
        const initialTab = document.querySelector('.tab-btn[data-panel="' + normalizedPanel + '"]');

        const openModal = function (modal) {
          if (!modal) return;
          modal.classList.add('is-open');
          modal.removeAttribute('hidden');
          modal.setAttribute('aria-hidden', 'false');
          const firstInput = modal.querySelector('input:not([type="hidden"]), select, textarea, button');
          if (firstInput) {
            firstInput.focus();
          }
        };

        const closeModal = function (modal) {
          if (!modal) return;
          modal.classList.remove('is-open');
          modal.setAttribute('aria-hidden', 'true');
          modal.setAttribute('hidden', '');
        };

        document.querySelectorAll('.modal-backdrop').forEach(function (modal) {
          closeModal(modal);
        });

        const activatePanel = function (panelId) {
          document.querySelectorAll('.tab-btn').forEach(function (tab) {
            tab.classList.toggle('active', tab.getAttribute('data-panel') === panelId);
          });

          document.querySelectorAll('.staff-panel').forEach(function (panel) {
            panel.hidden = true;
          });

          if (panelId === 'pending') {
            document.getElementById('staff-panel-pending').hidden = false;
          } else if (panelId === 'approved') {
            document.getElementById('staff-panel-approved').hidden = false;
          } else if (panelId === 'activity') {
            document.getElementById('staff-panel-activity').hidden = false;
          } else if (panelId === 'templates') {
            document.getElementById('staff-panel-templates').hidden = false;
          } else if (panelId === 'complaints') {
            document.getElementById('staff-panel-complaints').hidden = false;
          }

          const url = new URL(window.location.href);
          url.searchParams.set('view', panelId);
          window.history.replaceState({}, '', url.toString());
        };

        if (initialTab) {
          activatePanel(normalizedPanel);
        } else {
          activatePanel('pending');
        }

        document.querySelectorAll('.tab-btn').forEach(function (button) {
          button.addEventListener('click', function () {
            const panelId = this.getAttribute('data-panel');
            activatePanel(panelId);
          });
        });

        const highlightedRow = highlightedRequestId
          ? document.getElementById('staff-request-' + highlightedRequestId)
          : (highlightedComplaintId ? document.getElementById('staff-complaint-' + highlightedComplaintId) : null);
        if (highlightedRow) {
          highlightedRow.classList.add('request-highlight');
          window.setTimeout(function () {
            highlightedRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }, 120);
        }

        const notificationToggle = document.querySelector('.notification-toggle');
        const notificationMenu = document.getElementById('staffNotificationMenu');
        const notificationBadge = document.querySelector('[data-notification-badge]');
        const notificationItems = Array.from(document.querySelectorAll('[data-notification-key]'));
        const notificationStorageKey = 'staffReadRequestNotifications';
        let notificationReadKeys = [];

        try {
          notificationReadKeys = JSON.parse(window.localStorage.getItem(notificationStorageKey) || '[]');
        } catch (error) {
          notificationReadKeys = [];
        }

        const saveNotificationReadKeys = function () {
          window.localStorage.setItem(notificationStorageKey, JSON.stringify(notificationReadKeys));
        };

        const refreshNotificationBadge = function () {
          const unreadItems = notificationItems.filter(function (item) {
            return !notificationReadKeys.includes(item.dataset.notificationKey);
          });

          notificationItems.forEach(function (item) {
            item.classList.toggle('is-read', notificationReadKeys.includes(item.dataset.notificationKey));
          });

          if (notificationBadge) {
            if (unreadItems.length > 0) {
              notificationBadge.hidden = false;
              notificationBadge.textContent = unreadItems.length > 9 ? '9+' : String(unreadItems.length);
            } else {
              notificationBadge.hidden = true;
            }
          }
        };

        if (notificationToggle && notificationMenu) {
          notificationToggle.addEventListener('click', function (event) {
            event.stopPropagation();
            const willOpen = notificationMenu.hidden;
            notificationMenu.hidden = !willOpen;
            notificationToggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
          });

          document.addEventListener('click', function (event) {
            if (!notificationMenu.hidden && !notificationMenu.contains(event.target) && !notificationToggle.contains(event.target)) {
              notificationMenu.hidden = true;
              notificationToggle.setAttribute('aria-expanded', 'false');
            }
          });
        }

        notificationItems.forEach(function (item) {
          item.addEventListener('click', function () {
            const key = item.dataset.notificationKey;
            if (key && !notificationReadKeys.includes(key)) {
              notificationReadKeys.push(key);
              saveNotificationReadKeys();
            }
          });
        });

        refreshNotificationBadge();

        document.querySelectorAll('.print-certificate-button').forEach(function (button) {
          button.addEventListener('click', function (event) {
            event.stopPropagation();
            const certificate = document.getElementById(button.dataset.printTarget);
            if (!certificate) return;

            const markPrintedPromise = (button.dataset.currentStatus === 'approved' && button.dataset.requestId && button.dataset.csrfToken)
              ? (function () {
                const statusData = new FormData();
                statusData.append('request_id', button.dataset.requestId);
                statusData.append('csrf_token', button.dataset.csrfToken);
                statusData.append('status', 'printed');
                statusData.append('redirect_query', button.dataset.redirectQuery || 'view=approved');

                return window.fetch('../actions/updateRequestStatus.php', {
                  method: 'POST',
                  body: statusData,
                  credentials: 'same-origin'
                }).then(function (response) {
                  if (response.ok) {
                    button.dataset.currentStatus = 'printed';
                    return true;
                  }
                  return false;
                }).catch(function () {
                  return false;
                });
              })()
              : Promise.resolve(false);

            const printWindow = window.open('', '_blank', 'width=900,height=1100');
            if (!printWindow) return;

            let refreshedAfterPrint = false;
            const refreshIfMarkedPrinted = function () {
              if (refreshedAfterPrint) return;
              refreshedAfterPrint = true;
              markPrintedPromise.then(function (shouldRefresh) {
                if (shouldRefresh) {
                  window.setTimeout(function () {
                    window.location.reload();
                  }, 500);
                }
              });
            };

            printWindow.document.write('<!doctype html><html><head><title>Print Certificate</title>');
            printWindow.document.write('<style>body{margin:0;padding:24px;background:#f3f4f6;font-family:Georgia,serif}.certificate-sheet{width:760px;min-height:980px;margin:0 auto;padding:56px;border:12px double #1f2937;background:#fff;color:#111827}.certificate-topline{text-align:center;font-size:14px}.certificate-barangay{text-align:center;font-size:28px;font-weight:800;text-transform:uppercase;margin-top:6px}.certificate-office{text-align:center;font-size:14px;margin-bottom:28px}.certificate-seal-row{display:flex;align-items:center;justify-content:center;gap:24px;margin:28px 0}.certificate-seal{width:86px;height:86px;border:3px solid #ef0004;border-radius:50%;display:grid;place-items:center;color:#ef0004;font-weight:800}.certificate-seal-row h2{margin:0;text-align:center;font-size:30px;text-transform:uppercase}.certificate-seal-row p{text-align:center;margin:8px 0 0}.certificate-body{font-size:18px;line-height:1.8;text-align:justify;margin-top:28px}.certificate-greeting{font-weight:800;text-align:left}.certificate-signature-row{display:flex;justify-content:space-between;gap:48px;margin-top:80px}.certificate-signature-row div{flex:1;text-align:center;border-top:1px solid #111827;padding-top:10px}.certificate-signature-row span{display:block;font-size:12px;text-transform:uppercase;color:#4b5563}.certificate-signature-row strong{font-size:16px;text-transform:uppercase}@media print{body{background:#fff;padding:0}.certificate-sheet{width:auto;min-height:auto;margin:0;border:10px double #111827;box-shadow:none}}</style>');
            printWindow.document.write('</head><body>' + certificate.outerHTML + '</body></html>');
            printWindow.document.close();
            printWindow.addEventListener('afterprint', refreshIfMarkedPrinted);
            printWindow.focus();
            printWindow.setTimeout(function () {
              printWindow.print();
              printWindow.setTimeout(refreshIfMarkedPrinted, 2500);
            }, 250);
          });
        });

        document.querySelectorAll('.open-template-modal').forEach(function (button) {
          button.addEventListener('click', function (event) {
            event.stopPropagation();
            openModal(document.getElementById(this.getAttribute('data-template-modal')));
          });
        });

        document.querySelectorAll('[data-modal-target]').forEach(function (button) {
          button.addEventListener('click', function (event) {
            event.stopPropagation();
            openModal(document.getElementById(this.getAttribute('data-modal-target')));
          });
        });

        document.querySelectorAll('[data-modal-close]').forEach(function (button) {
          button.addEventListener('click', function (event) {
            event.stopPropagation();
            const modal = event.currentTarget.closest('.modal-backdrop');
            closeModal(modal);
          });
        });

        document.querySelectorAll('.modal-backdrop').forEach(function (modal) {
          modal.addEventListener('click', function (event) {
            if (event.target === modal) {
              closeModal(modal);
            }
          });
        });

        document.addEventListener('keydown', function (event) {
          if (event.key === 'Escape') {
            document.querySelectorAll('.modal-backdrop.is-open').forEach(function (modal) {
              closeModal(modal);
            });
          }
        });
      });
    </script>
</body>
</html>

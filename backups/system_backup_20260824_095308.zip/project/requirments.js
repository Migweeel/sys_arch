document.addEventListener("DOMContentLoaded", () => {

  const docType = document.getElementById("doc-type");
  const container = document.getElementById("requirementsContainer");
  const submitBtn = document.querySelector(".submit-btn");
  const isVerified = submitBtn?.dataset.verified === "1";
  const MAX_SIZE = 25 * 1024 * 1024;

  const templates = {
    clearance: `
      <div class="requirements-section">
        <h3>REQUIREMENTS</h3>

        <div class="requirement-item">
          <span>Government ID</span>
          <label class="action-btn" for="requirements_government_id">
            <span class="upload-text">Upload</span>
            <input id="requirements_government_id" class="upload-input" type="file" name="requirements[government_id]" required>
          </label>
        </div>

        <div class="requirement-item">
          <span>Proof of Residency</span>
          <label class="action-btn" for="requirements_proof_residency">
            <span class="upload-text">Upload</span>
            <input id="requirements_proof_residency" class="upload-input" type="file" name="requirements[proof_residency]" required>
          </label>
        </div>

        <div class="requirement-item">
          <span>Cedula</span>
          <label class="action-btn" for="requirements_cedula">
            <span class="upload-text">Upload</span>
            <input id="requirements_cedula" class="upload-input" type="file" name="requirements[cedula]" required>
          </label>
        </div>
      </div>
    `,
    indigency: `
      <div class="requirements-section">
        <h3>REQUIREMENTS</h3>

        <div class="requirement-item">
          <span>Government ID</span>
          <label class="action-btn" for="requirements_government_id">
            <span class="upload-text">Upload</span>
            <input id="requirements_government_id" class="upload-input" type="file" name="requirements[government_id]" required>
          </label>
        </div>
      </div>
    `,
    residency: `
      <div class="requirements-section">
        <h3>REQUIREMENTS</h3>

        <div class="requirement-item">
          <span>Proof of Residency</span>
          <label class="action-btn" for="requirements_proof_residency">
            <span class="upload-text">Upload</span>
            <input id="requirements_proof_residency" class="upload-input" type="file" name="requirements[proof_residency]" required>
          </label>
        </div>
      </div>
    `
  };

  docType.addEventListener("change", () => {
    container.innerHTML = templates[docType.value] || "";
    submitBtn.disabled = true;

    const inputs = container.querySelectorAll("input[type=file]");

    if (!isVerified) {
      inputs.forEach(input => {
        input.disabled = true;
      });
      submitBtn.disabled = true;
      return;
    }

    inputs.forEach(input => {
      input.addEventListener("change", () => {
        if (!input.files || !input.files[0]) {
          return;
        }

        if (input.files[0].size > MAX_SIZE) {
          alert("File must not exceed 25MB.");
          input.value = "";
          const textSpan = input.parentElement.querySelector('.upload-text');
          if (textSpan) textSpan.textContent = 'Upload';
          submitBtn.disabled = true;
          return;
        }

        const textSpan = input.parentElement.querySelector('.upload-text');
        if (textSpan) {
          textSpan.textContent = input.files[0].name;
        }

        const allFilled = [...inputs].every(i => i.files.length > 0);
        submitBtn.disabled = !allFilled;
      });
    });

    container.querySelectorAll('.action-btn').forEach(label => {
      const input = label.querySelector('input[type=file]');
      if (!input) return;
      label.addEventListener('click', event => {
        if (event.target !== input) {
          input.click();
        }
      });
    });
  });

});

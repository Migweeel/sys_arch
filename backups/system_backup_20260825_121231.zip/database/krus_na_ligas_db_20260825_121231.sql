-- Krus na Ligas system backup
-- Generated: 2026-08-25 12:12:31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `krus_na_ligas_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `krus_na_ligas_db`;

DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `username` varchar(100) NOT NULL DEFAULT '',
  `role` varchar(50) NOT NULL DEFAULT 'resident',
  `action` varchar(50) NOT NULL DEFAULT 'activity',
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activity_logs_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=435 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('1', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 21:22:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('2', '8', 'tenderfoot1', 'resident', 'login', 'User logged in to the system', '2026-07-29 21:38:29');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('3', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 21:39:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('4', '8', 'tenderfoot1', 'resident', 'login', 'User logged in to the system', '2026-07-29 21:51:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('5', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 21:52:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('6', '7', 'admin', 'admin', 'user_created', 'Admin created a STAFF account for mig1259.', '2026-07-29 22:23:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('7', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:23:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('8', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:31:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('9', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:32:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('10', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 22:46:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('11', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdasdas.', '2026-07-29 22:59:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('12', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: dasdsadas.', '2026-07-29 23:12:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('13', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:18:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('14', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:18:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('15', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdasda.', '2026-07-29 23:27:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('16', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:28:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('17', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-29 23:57:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('18', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-29 23:57:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('19', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdasd.', '2026-07-29 23:58:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('20', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-29 23:58:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('21', '9', 'mig1259', 'staff', 'template_created', 'Staff created document template: asdads.', '2026-07-30 00:00:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('22', '9', 'mig1259', 'staff', 'template_deleted', 'Staff deleted a document template.', '2026-07-30 00:00:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('23', '9', 'mig1259', 'staff', 'login', 'User logged in to the system', '2026-07-30 00:01:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('24', '7', 'admin', 'admin', 'login', 'User logged in to the system', '2026-07-30 00:57:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('25', '7', 'admin', 'admin', 'user_created', 'Admin created a ADMIN account for admin1.', '2026-07-30 01:04:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('26', '7', 'admin', 'admin', 'user_created', 'Admin created a STAFF account for kenneth.', '2026-07-30 01:05:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('27', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 01:05:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('28', '0', 'nethhh', 'resident', 'registration_submitted', 'A new resident account was registered.', '2026-07-30 01:11:29');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('29', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 01:11:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('30', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 01:13:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('31', '10', 'admin1', 'admin', 'verification_verified', 'User verification was verified.', '2026-07-30 01:14:55');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('32', '10', 'admin1', 'admin', 'verification_verified', 'User verification was verified.', '2026-07-30 01:14:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('33', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 01:15:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('34', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 01:15:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('35', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 01:16:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('36', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 01:16:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('37', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 01:17:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('38', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 01:17:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('39', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 13:55:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('40', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 13:58:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('41', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:16:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('42', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:17:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('43', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:17:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('44', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:18:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('45', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:23:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('46', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:27:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('47', '11', 'kenneth', 'staff', 'request_approved', 'REQ-2026-006 was approved by staff.', '2026-07-30 14:44:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('48', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 14:44:32');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('49', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:44:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('50', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:44:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('51', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:45:31');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('52', '11', 'kenneth', 'staff', 'request_rejected', 'REQ-2026-007 was rejected by staff.', '2026-07-30 14:45:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('53', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 14:46:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('54', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 14:46:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('55', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 14:47:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('56', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 14:47:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('57', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:47:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('58', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:47:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('59', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 14:47:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('60', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 14:48:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('61', '11', 'kenneth', 'staff', 'request_rejected', 'REQ-2026-012 was rejected by staff.', '2026-07-30 14:48:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('62', '11', 'kenneth', 'staff', 'request_approved', 'REQ-2026-011 was approved by staff.', '2026-07-30 14:48:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('63', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 14:48:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('64', '10', 'admin1', 'admin', 'request_approved', 'REQ-2026-010 was approved by admin.', '2026-07-30 14:49:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('65', '10', 'admin1', 'admin', 'request_rejected', 'REQ-2026-009 was rejected by admin.', '2026-07-30 14:49:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('66', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 15:03:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('67', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 15:03:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('68', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 15:04:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('69', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Residency.', '2026-07-30 15:04:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('70', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 15:04:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('71', '12', 'nethhh', 'resident', 'document_requested', 'Resident submitted a document request: Certificate of Indigency.', '2026-07-30 15:05:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('72', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 15:05:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('73', '11', 'kenneth', 'staff', 'request_rejected', 'REQ-2026-017 was rejected by staff.', '2026-07-30 15:05:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('74', '11', 'kenneth', 'staff', 'request_approved', 'REQ-2026-016 was approved by staff.', '2026-07-30 15:05:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('75', '11', 'kenneth', 'staff', 'request_released', 'REQ-2026-016 was released by staff.', '2026-07-30 15:06:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('76', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 15:06:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('77', '10', 'admin1', 'admin', 'request_rejected', 'REQ-2026-015 was rejected by admin.', '2026-07-30 15:07:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('78', '10', 'admin1', 'admin', 'request_approved', 'REQ-2026-014 was approved by admin.', '2026-07-30 15:07:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('79', '10', 'admin1', 'admin', 'request_released', 'REQ-2026-014 was released by admin.', '2026-07-30 15:07:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('80', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:18:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('81', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 21:27:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('82', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:27:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('83', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:33:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('84', '12', 'nethhh', 'resident', 'login', 'User logged in to the system', '2026-07-30 21:34:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('85', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 21:34:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('86', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:35:30');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('87', '0', 'tbag', 'resident', 'registration_submitted', 'A new resident account was registered.', '2026-07-30 21:40:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('88', '13', 'tbag', 'resident', 'login', 'User logged in to the system', '2026-07-30 21:41:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('89', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:41:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('90', '10', 'admin1', 'admin', 'user_created', 'Admin created a ADMIN account for admin2.', '2026-07-30 21:48:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('91', '10', 'admin1', 'admin', 'user_deleted', 'Admin deleted user account #7.', '2026-07-30 21:57:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('92', '10', 'admin1', 'admin', 'user_deleted', 'Admin deleted user account #4.', '2026-07-30 21:57:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('93', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 21:58:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('94', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 21:58:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('95', '11', 'kenneth', 'staff', 'login', 'User logged in to the system', '2026-07-30 22:05:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('96', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:07:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('97', '10', 'admin1', 'admin', 'user_updated', 'Admin updated user account #14.', '2026-07-30 22:29:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('98', '10', 'admin1', 'admin', 'user_updated', 'Admin updated user account: Daniel Padilla (username: daniel, role: Staff).', '2026-07-30 22:44:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('99', '10', 'admin1', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:45:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('100', '14', 'joshua', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:45:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('101', '14', 'joshua', 'admin', 'user_updated', 'Admin updated user account: Kenneth Tarroza (username: michael, role: Resident).', '2026-07-30 22:46:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('102', '14', 'joshua', 'admin', 'user_updated', 'Admin updated user account: Kenneth Tarroza (username: michael, role: Resident).', '2026-07-30 22:47:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('103', '12', 'michael', 'resident', 'login', 'User logged in to the system', '2026-07-30 22:49:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('104', '14', 'joshua', 'admin', 'login', 'User logged in to the system', '2026-07-30 22:50:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('105', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Theodor Bagwell (username: tbag, role: Resident).', '2026-07-30 22:56:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('106', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Michael Scofield (username: michael, role: Resident).', '2026-07-30 22:56:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('107', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Daniel Padilla (username: daniel, role: Staff).', '2026-07-30 22:56:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('108', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: admin1 (username: admin1, role: Admin).', '2026-07-30 22:56:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('109', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: mig1259 (username: mig1259, role: Staff).', '2026-07-30 22:56:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('110', '14', 'joshua', 'admin', 'user_deleted', 'Admin deleted user account: Miguel Rivera (username: tenderfoot1, role: Resident).', '2026-07-30 22:56:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('111', '14', 'joshua', 'admin', 'request_rejected', 'Admin rejected document request: REQ-2026-013 (Certificate of Indigency).', '2026-07-30 22:56:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('112', '14', 'joshua', 'admin', 'request_released', 'Admin released document request: REQ-2026-010 (Certificate of Residency).', '2026-07-30 22:56:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('113', '14', 'joshua', 'admin', 'request_released', 'Admin released document request: REQ-2026-011 (Certificate of Residency).', '2026-07-30 22:56:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('114', '14', 'joshua', 'admin', 'user_created', 'Admin created user account: Kenneth Tarroza (username: nethhh, role: Admin).', '2026-07-30 22:58:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('115', '14', 'joshua', 'admin', 'user_created', 'Admin created user account: Michael Scofield (username: michael, role: Staff).', '2026-07-30 22:59:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('116', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:00:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('117', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:00:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('118', '16', 'michael', 'staff', 'request_rejected', 'Staff rejected document request: REQ-2026-008 (Certificate of Indigency).', '2026-07-30 23:01:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('119', '17', 'fernando', 'resident', 'registration_submitted', 'Resident registered account: Fernando Sucre (username: fernando, role: Resident). Pending admin verification.', '2026-07-30 23:02:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('120', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:02:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('121', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:02:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('122', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:03:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('123', '15', 'nethhh', 'admin', 'user_deleted', 'Admin deleted user account: Joshua Garcia (username: joshua, role: Admin).', '2026-07-30 23:03:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('124', '15', 'nethhh', 'admin', 'verification_verified', 'Admin set verification status to verified for user account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:03:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('125', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:03:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('126', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-018 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:04:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('127', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-019 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:04:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('128', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-020 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:04:53');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('129', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-021 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:05:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('130', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-022 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:05:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('131', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-023 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:05:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('132', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:05:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('133', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-023 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:06:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('134', '15', 'nethhh', 'admin', 'request_rejected', 'Admin rejected document request: REQ-2026-022 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:06:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('135', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-004 (Certificate of Indigency).', '2026-07-30 23:06:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('136', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-006 (Certificate of Indigency).', '2026-07-30 23:06:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('137', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-021 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:06:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('138', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:07:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('139', '16', 'michael', 'staff', 'request_approved', 'Staff approved document request: REQ-2026-020 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:07:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('140', '16', 'michael', 'staff', 'request_approved', 'Staff approved document request: REQ-2026-019 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:07:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('141', '16', 'michael', 'staff', 'request_rejected', 'Staff rejected document request: REQ-2026-018 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:07:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('142', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:07:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('143', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:08:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('144', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-024 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:08:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('145', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-025 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-30 23:08:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('146', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:08:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('147', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-019 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:09:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('148', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:09:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('149', '16', 'michael', 'staff', 'request_released', 'Staff released document request: REQ-2026-020 (Certificate of Indigency) for resident Fernando Sucre (username: fernando).', '2026-07-30 23:09:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('150', '18', 'alexander', 'resident', 'registration_submitted', 'Resident registered account: Alexander Mahone (username: alexander, role: Resident). Pending admin verification.', '2026-07-30 23:11:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('151', '19', 'lincoln', 'resident', 'registration_submitted', 'Resident registered account: Lincoln Burrows (username: lincoln, role: Resident). Pending admin verification.', '2026-07-30 23:12:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('152', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:12:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('153', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:12:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('154', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:12:50');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('155', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: wfvdwvwe', '2026-07-30 23:13:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('156', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:14:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('157', '19', 'lincoln', 'resident', 'verification_resubmitted', 'Resident resubmitted verification proof for account: Lincoln Burrows (username: lincoln, role: Resident).', '2026-07-30 23:14:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('158', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:14:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('159', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: fewfewvbwe', '2026-07-30 23:15:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('160', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: fewfewvbwe', '2026-07-30 23:15:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('161', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:15:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('162', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:18:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('163', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:22:31');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('164', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:22:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('165', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-30 23:23:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('166', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:23:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('167', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:23:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('168', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:24:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('169', '15', 'nethhh', 'admin', 'verification_rejected', 'Admin set verification status to rejected for user account: Lincoln Burrows (username: lincoln, role: Resident). Reason: wqfwevwev', '2026-07-30 23:24:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('170', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-07-30 23:29:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('171', '19', 'lincoln', 'resident', 'verification_resubmitted', 'Resident resubmitted verification proof for account: Lincoln Burrows (username: lincoln, role: Resident).', '2026-07-30 23:30:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('172', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-30 23:30:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('173', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-025 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-07-31 00:01:03');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('174', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-31 00:01:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('175', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-026 (Certificate of Indigency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-07-31 00:01:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('176', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-31 00:01:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('177', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:24:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('178', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:38:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('179', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:39:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('180', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 15:58:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('181', '0', 'Guest', 'resident', 'complaint_submitted', 'Complaint submitted: CMP-0001.', '2026-07-31 16:09:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('182', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-07-31 16:09:50');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('183', '16', 'michael', 'staff', 'complaint_done', 'Staff marked complaint CMP-0001 as done.', '2026-07-31 16:15:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('184', '16', 'michael', 'staff', 'complaint_pending', 'Staff marked complaint CMP-0001 as pending.', '2026-07-31 16:15:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('185', '16', 'michael', 'staff', 'complaint_done', 'Staff marked complaint CMP-0001 as done.', '2026-07-31 16:15:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('186', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-07-31 16:16:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('187', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-07-31 16:16:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('188', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 20:42:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('189', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 20:56:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('190', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 21:00:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('191', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:01:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('192', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:02:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('193', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:13:31');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('194', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:16:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('195', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 21:18:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('196', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:18:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('197', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 21:27:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('198', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:27:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('199', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 21:27:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('200', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 21:27:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('201', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 21:35:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('202', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 21:35:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('203', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 21:39:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('204', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 21:42:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('205', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 21:42:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('206', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 21:42:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('207', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:00:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('208', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:00:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('209', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:00:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('210', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:01:05');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('211', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:06:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('212', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:06:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('213', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:13:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('214', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:13:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('215', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:21:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('216', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:22:03');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('217', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:31:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('218', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:31:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('219', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:32:20');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('220', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:32:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('221', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:40:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('222', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 22:40:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('223', '15', 'nethhh', 'admin', 'verification_verified', 'Admin set verification status to verified for user account: Alexander Mahone (username: alexander, role: Resident).', '2026-08-02 22:40:32');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('224', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 22:40:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('225', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:40:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('226', '18', 'alexander', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-027 (Certificate of Indigency) for account: Alexander Mahone (username: alexander, role: Resident).', '2026-08-02 22:40:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('227', '18', 'alexander', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:41:03');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('228', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-02 22:41:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('229', '16', 'michael', 'staff', 'request_approved', 'Staff approved document request: REQ-2026-027 (Certificate of Indigency) for resident Alexander Mahone (username: alexander).', '2026-08-02 22:41:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('230', '16', 'michael', 'staff', 'request_released', 'Staff released document request: REQ-2026-027 (Certificate of Indigency) for resident Alexander Mahone (username: alexander).', '2026-08-02 22:46:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('231', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-02 22:46:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('232', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:46:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('233', '18', 'alexander', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:46:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('234', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:47:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('235', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-02 22:57:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('236', '18', 'alexander', 'resident', 'login', 'User logged in to the system', '2026-08-02 22:57:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('237', '18', 'alexander', 'resident', 'logout', 'User logged out of the system', '2026-08-02 23:01:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('238', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-02 23:01:53');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('239', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-02 23:02:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('240', '19', 'lincoln', 'resident', 'login', 'User logged in to the system', '2026-08-19 21:46:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('241', '19', 'lincoln', 'resident', 'logout', 'User logged out of the system', '2026-08-19 21:47:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('242', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-19 21:48:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('243', '16', 'michael', 'staff', 'certificate_printed', 'Staff printed sample certificate preview for REQ-2026-025 (Certificate of Residency) for Fernando Sucre.', '2026-08-19 21:48:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('244', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-19 21:49:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('245', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-19 21:49:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('246', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-19 21:52:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('247', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-23 22:21:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('248', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-23 22:22:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('249', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-23 22:22:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('250', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-23 22:23:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('251', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 15:05:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('252', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 15:05:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('253', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 15:05:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('254', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 15:05:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('255', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:06:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('256', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:23:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('257', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:24:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('258', '15', 'nethhh', 'admin', 'request_printed', 'Admin printed document request: REQ-2026-025 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-08-24 15:37:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('259', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:37:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('260', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:39:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('261', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:46:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('262', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 15:46:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('263', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 15:47:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('264', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 15:47:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('265', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 15:47:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('266', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:50:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('267', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 15:52:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('268', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 15:53:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('269', '15', 'nethhh', 'admin', 'system_backup_created', 'Admin created system backup: system_backup_20260824_095308.zip.', '2026-08-24 15:53:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('270', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 16:19:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('271', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 16:19:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('272', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 16:22:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('273', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 16:23:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('274', '17', 'fernando', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-028 (Certificate of Residency) for account: Fernando Sucre (username: fernando, role: Resident).', '2026-08-24 16:23:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('275', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 16:23:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('276', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 16:23:35');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('277', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 16:27:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('278', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 16:27:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('279', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 16:28:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('280', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 16:28:14');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('281', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 16:41:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('282', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 16:41:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('283', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 16:54:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('284', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 16:54:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('285', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 16:57:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('286', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 16:57:50');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('287', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 16:58:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('288', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 16:58:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('289', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 17:08:45');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('290', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 17:08:55');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('291', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 17:36:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('292', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 17:36:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('293', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 17:54:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('294', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 17:54:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('295', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 17:56:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('296', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 17:56:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('297', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 17:59:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('298', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 17:59:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('299', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 18:00:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('300', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-24 18:20:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('301', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-24 18:30:29');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('302', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 18:30:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('303', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 18:53:51');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('304', '16', 'michael', 'staff', 'login', 'User logged in to the system', '2026-08-24 18:53:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('305', '16', 'michael', 'staff', 'logout', 'User logged out of the system', '2026-08-24 19:07:22');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('306', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 19:07:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('307', '15', 'nethhh', 'admin', 'user_deleted', 'Admin deleted user account: Michael Scofield (username: michael, role: Staff).', '2026-08-24 19:07:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('308', '15', 'nethhh', 'admin', 'user_created', 'Admin created user account: Theodore Bagwell (username: tbag, role: Staff).', '2026-08-24 19:09:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('309', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 19:10:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('310', '20', 'tbag', 'staff', 'login', 'User logged in to the system', '2026-08-24 19:10:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('311', '20', 'tbag', 'staff', 'logout', 'User logged out of the system', '2026-08-24 19:10:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('312', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 19:14:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('313', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 19:16:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('314', '21', 'scofield', 'resident', 'registration_submitted', 'Resident registered account: Michael Scofied (username: scofield, role: Resident). Pending admin verification.', '2026-08-24 19:17:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('315', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-24 19:18:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('316', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-24 19:19:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('317', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 19:19:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('318', '15', 'nethhh', 'admin', 'verification_verified', 'Admin set verification status to verified for user account: Michael Scofied (username: scofield, role: Resident).', '2026-08-24 19:19:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('319', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 19:19:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('320', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-24 19:19:36');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('321', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-24 19:21:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('322', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 20:22:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('323', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 20:25:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('324', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-24 20:26:13');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('325', '21', 'scofield', 'resident', 'profile_updated', 'Resident updated their profile information.', '2026-08-24 20:26:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('326', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-24 20:26:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('327', '20', 'tbag', 'staff', 'login', 'User logged in to the system', '2026-08-24 20:58:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('328', '20', 'tbag', 'staff', 'logout', 'User logged out of the system', '2026-08-24 20:58:26');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('329', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-24 20:58:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('330', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-24 20:59:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('331', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 01:10:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('332', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 01:13:57');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('333', '20', 'tbag', 'staff', 'login', 'User logged in to the system', '2026-08-25 01:14:03');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('334', '20', 'tbag', 'staff', 'logout', 'User logged out of the system', '2026-08-25 01:29:32');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('335', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 01:29:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('336', '21', 'scofield', 'resident', 'logout', 'User was logged out due to inactivity.', '2026-08-25 01:53:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('337', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 02:18:59');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('338', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 02:44:53');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('339', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 02:44:58');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('340', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 02:45:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('341', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 03:08:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('342', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 03:12:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('343', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 03:22:55');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('344', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 03:23:07');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('345', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 03:23:10');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('346', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 03:23:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('347', '15', 'nethhh', 'admin', 'template_created', 'Admin created document template: Certificate of Residency.', '2026-08-25 03:25:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('348', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 03:25:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('349', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 03:25:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('350', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 03:31:21');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('351', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 03:31:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('352', '15', 'nethhh', 'admin', 'template_updated', 'Admin updated document template: Certificate of Residency.', '2026-08-25 03:31:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('353', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 03:31:43');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('354', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 03:31:50');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('355', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 03:31:56');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('356', '20', 'tbag', 'staff', 'login', 'User logged in to the system', '2026-08-25 03:32:08');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('357', '20', 'tbag', 'staff', 'template_updated', 'Staff updated document template: Certificate of Residency.', '2026-08-25 03:32:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('358', '20', 'tbag', 'staff', 'logout', 'User logged out of the system', '2026-08-25 03:32:30');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('359', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 03:32:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('360', '21', 'scofield', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-029 (Certificate of Residency) for account: Michael Scofied (username: scofield, role: Resident).', '2026-08-25 03:32:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('361', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 03:32:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('362', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 03:33:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('363', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-029 (Certificate of Residency) for resident Michael Scofied (username: scofield).', '2026-08-25 03:33:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('364', '15', 'nethhh', 'admin', 'template_deleted', 'Admin deleted document template: Certificate of Residency (Certificates).', '2026-08-25 03:57:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('365', '15', 'nethhh', 'admin', 'request_printed', 'Admin printed document request: REQ-2026-029 (Certificate of Residency) for resident Michael Scofied (username: scofield).', '2026-08-25 04:39:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('366', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-029 (Certificate of Residency) for resident Michael Scofied (username: scofield).', '2026-08-25 04:39:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('367', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-025 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-08-25 04:39:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('368', '15', 'nethhh', 'admin', 'template_created', 'Admin created document template: Barangay Clearance.', '2026-08-25 04:48:02');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('369', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 04:48:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('370', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 04:48:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('371', '21', 'scofield', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-030 (Barangay Clearance) for account: Michael Scofied (username: scofield, role: Resident).', '2026-08-25 04:48:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('372', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 04:48:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('373', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 04:48:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('374', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-030 (Barangay Clearance) for resident Michael Scofied (username: scofield).', '2026-08-25 04:49:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('375', '15', 'nethhh', 'admin', 'template_updated', 'Admin updated document template: Barangay Clearance.', '2026-08-25 04:58:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('376', '15', 'nethhh', 'admin', 'template_created', 'Admin created document template: Certificate of Indigency.', '2026-08-25 05:07:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('377', '15', 'nethhh', 'admin', 'template_updated', 'Admin updated document template: Barangay Clearance.', '2026-08-25 05:10:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('378', '15', 'nethhh', 'admin', 'template_updated', 'Admin updated document template: Certificate of Indigency.', '2026-08-25 05:10:55');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('379', '15', 'nethhh', 'admin', 'template_updated', 'Admin updated document template: Certificate of Indigency.', '2026-08-25 05:11:37');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('380', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 05:11:42');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('381', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 05:11:49');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('382', '21', 'scofield', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-031 (Certificate of Indigency) for account: Michael Scofied (username: scofield, role: Resident).', '2026-08-25 05:12:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('383', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 05:12:25');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('384', '20', 'tbag', 'staff', 'login', 'User logged in to the system', '2026-08-25 05:12:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('385', '20', 'tbag', 'staff', 'request_approved', 'Staff approved document request: REQ-2026-031 (Certificate of Indigency) for resident Michael Scofied (username: scofield).', '2026-08-25 05:12:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('386', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 17:07:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('387', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 17:07:17');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('388', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 17:07:23');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('389', '15', 'nethhh', 'admin', 'user_deleted', 'Admin deleted user account: Lincoln Burrows (username: lincoln, role: Resident).', '2026-08-25 17:07:47');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('390', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 17:08:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('391', '21', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 17:09:33');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('392', '21', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 17:09:39');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('393', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 17:09:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('394', '15', 'nethhh', 'admin', 'user_deleted', 'Admin deleted user account: Michael Scofied (username: scofield, role: Resident).', '2026-08-25 17:10:34');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('395', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 17:10:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('396', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-25 17:26:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('397', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-25 17:27:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('398', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 17:27:15');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('399', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-028 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-08-25 17:27:20');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('400', '15', 'nethhh', 'admin', 'request_printed', 'Admin printed document request: REQ-2026-028 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-08-25 17:27:27');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('401', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-028 (Certificate of Residency) for resident Fernando Sucre (username: fernando).', '2026-08-25 17:27:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('402', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 17:27:44');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('403', '17', 'fernando', 'resident', 'login', 'User logged in to the system', '2026-08-25 17:27:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('404', '17', 'fernando', 'resident', 'logout', 'User logged out of the system', '2026-08-25 17:34:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('405', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 17:37:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('406', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 17:37:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('407', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 17:41:09');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('408', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 17:51:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('409', '22', 'scofield', 'resident', 'registration_submitted', 'Resident registered account: Michael Scofield (username: scofield, role: Resident). Pending admin verification.', '2026-08-25 17:54:41');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('410', '22', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 17:56:28');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('411', '22', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 17:56:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('412', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 17:57:01');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('413', '15', 'nethhh', 'admin', 'verification_verified', 'Admin set verification status to verified for user account: Michael Scofield (username: scofield, role: Resident).', '2026-08-25 17:57:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('414', '15', 'nethhh', 'admin', 'verification_verified', 'Admin set verification status to verified for user account: Michael Scofield (username: scofield, role: Resident).', '2026-08-25 17:57:31');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('415', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 17:57:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('416', '22', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 17:57:46');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('417', '22', 'scofield', 'resident', 'document_requested', 'Resident submitted document request: REQ-2026-032 (Certificate of Indigency) for account: Michael Scofield (username: scofield, role: Resident).', '2026-08-25 17:58:16');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('418', '22', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 17:58:55');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('419', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 17:59:04');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('420', '15', 'nethhh', 'admin', 'user_created', 'Admin created user account: Lincoln Burrows (username: lincoln, role: Staff).', '2026-08-25 18:00:06');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('421', '15', 'nethhh', 'admin', 'request_approved', 'Admin approved document request: REQ-2026-032 (Certificate of Indigency) for resident Michael Scofield (username: scofield).', '2026-08-25 18:00:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('422', '15', 'nethhh', 'admin', 'request_printed', 'Admin printed document request: REQ-2026-032 (Certificate of Indigency) for resident Michael Scofield (username: scofield).', '2026-08-25 18:01:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('423', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 18:02:00');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('424', '22', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 18:02:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('425', '22', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 18:02:24');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('426', '22', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 18:02:40');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('427', '22', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 18:03:12');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('428', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 18:03:19');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('429', '15', 'nethhh', 'admin', 'request_released', 'Admin released document request: REQ-2026-032 (Certificate of Indigency) for resident Michael Scofield (username: scofield).', '2026-08-25 18:03:29');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('430', '15', 'nethhh', 'admin', 'logout', 'User logged out of the system', '2026-08-25 18:03:38');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('431', '22', 'scofield', 'resident', 'login', 'User logged in to the system', '2026-08-25 18:03:48');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('432', '22', 'scofield', 'resident', 'logout', 'User logged out of the system', '2026-08-25 18:04:11');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('433', '15', 'nethhh', 'admin', 'login', 'User logged in to the system', '2026-08-25 18:04:18');
INSERT INTO `activity_logs` (`id`, `user_id`, `username`, `role`, `action`, `description`, `created_at`) VALUES ('434', '15', 'nethhh', 'admin', 'system_backup_created', 'Admin created system backup: system_backup_20260825_121226.zip.', '2026-08-25 18:12:31');

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `complaints`;
CREATE TABLE `complaints` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `attachment_name` varchar(255) DEFAULT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `status` enum('pending','done') NOT NULL DEFAULT 'pending',
  `completed_by` int(11) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`complaint_id`),
  KEY `idx_complaints_status_created` (`status`,`created_at`),
  KEY `idx_complaints_completed_by` (`completed_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `complaints` (`complaint_id`, `categories`, `location`, `description`, `attachment_name`, `attachment_path`, `status`, `completed_by`, `completed_at`, `created_at`, `updated_at`) VALUES ('1', 'Draining / Flooding', 'rwenvierv', 'erberbcdbvebrf', 'cat hitler.jpg', 'uploads/complaints/complaint_6a6c583fd8c391.76754598_cat_hitler.jpg', 'done', '16', '2026-07-31 16:15:16', '2026-07-31 16:09:35', '2026-07-31 16:15:16');

DROP TABLE IF EXISTS `document_request_files`;
CREATE TABLE `document_request_files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`file_id`),
  KEY `idx_document_request_files_request_id` (`request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('1', '1', 'cat hitler.jpg', 'uploads/requirements/6a3bd3f706adf_cathitler.jpg', '2026-06-24 20:56:23');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('2', '2', 'cat hitler.jpg', 'uploads/requirements/6a3ea56de6552_cathitler.jpg', '2026-06-27 00:14:37');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('3', '3', 'cat hitler.jpg', 'uploads/requirements/6a3ea5d8928b7_cathitler.jpg', '2026-06-27 00:16:24');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('4', '4', 'cat hitler.jpg', 'uploads/requirements/6a3ea68aa5283_cathitler.jpg', '2026-06-27 00:19:22');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('5', '5', 'cat hitler.jpg', 'uploads/requirements/6a3ea69a3d7a0_cathitler.jpg', '2026-06-27 00:19:38');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('6', '6', 'cat hitler.jpg', 'uploads/requirements/6a6a3545d7596_cathitler.jpg', '2026-07-30 01:15:49');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('7', '7', 'cat hitler.jpg', 'uploads/requirements/6a6af2db09528_cathitler.jpg', '2026-07-30 14:44:43');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('8', '8', 'cat hitler.jpg', 'uploads/requirements/6a6af35793b27_cathitler.jpg', '2026-07-30 14:46:47');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('9', '9', 'cat hitler.jpg', 'uploads/requirements/6a6af37be7880_cathitler.jpg', '2026-07-30 14:47:23');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('10', '10', 'cat hitler.jpg', 'uploads/requirements/6a6af38852469_cathitler.jpg', '2026-07-30 14:47:36');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('11', '11', 'cat hitler.jpg', 'uploads/requirements/6a6af39155920_cathitler.jpg', '2026-07-30 14:47:45');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('12', '12', 'cat hitler.jpg', 'uploads/requirements/6a6af39a71812_cathitler.jpg', '2026-07-30 14:47:54');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('13', '13', 'cat hitler.jpg', 'uploads/requirements/6a6af757533a7_cathitler.jpg', '2026-07-30 15:03:51');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('14', '14', 'cat hitler.jpg', 'uploads/requirements/6a6af773cb222_cathitler.jpg', '2026-07-30 15:04:19');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('15', '15', 'cat hitler.jpg', 'uploads/requirements/6a6af7914b588_cathitler.jpg', '2026-07-30 15:04:49');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('16', '16', 'cat hitler.jpg', 'uploads/requirements/6a6af79ba6374_cathitler.jpg', '2026-07-30 15:04:59');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('17', '17', 'cat hitler.jpg', 'uploads/requirements/6a6af7a744d13_cathitler.jpg', '2026-07-30 15:05:11');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('18', '18', 'cat hitler.jpg', 'uploads/requirements/6a6b67f82d1e6_cathitler.jpg', '2026-07-30 23:04:24');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('19', '19', 'cat hitler.jpg', 'uploads/requirements/6a6b680682972_cathitler.jpg', '2026-07-30 23:04:38');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('20', '20', 'cat hitler.jpg', 'uploads/requirements/6a6b68153e2eb_cathitler.jpg', '2026-07-30 23:04:53');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('21', '21', 'cat hitler.jpg', 'uploads/requirements/6a6b682034266_cathitler.jpg', '2026-07-30 23:05:04');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('22', '22', 'cat hitler.jpg', 'uploads/requirements/6a6b682cd0f96_cathitler.jpg', '2026-07-30 23:05:16');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('23', '23', 'cat hitler.jpg', 'uploads/requirements/6a6b683646f8b_cathitler.jpg', '2026-07-30 23:05:26');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('24', '24', 'cat hitler.jpg', 'uploads/requirements/6a6b68f381df9_cathitler.jpg', '2026-07-30 23:08:35');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('25', '25', 'cat hitler.jpg', 'uploads/requirements/6a6b68fc7b758_cathitler.jpg', '2026-07-30 23:08:44');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('26', '26', 'cat hitler.jpg', 'uploads/requirements/6a6b755e7b569_cathitler.jpg', '2026-07-31 00:01:34');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('27', '27', 'cat hitler.jpg', 'uploads/requirements/6a6f56f45aa3a_cathitler.jpg', '2026-08-02 22:40:52');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('28', '28', 'cat hitler.jpg', 'uploads/requirements/6a8bff7dcbe66_cathitler.jpg', '2026-08-24 16:23:25');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('29', '29', 'cat hitler.jpg', 'uploads/requirements/6a8c9c5f6636e_cathitler.jpg', '2026-08-25 03:32:47');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('30', '30', 'cat hitler.jpg', 'uploads/requirements/6a8cae25c7943_cathitler.jpg', '2026-08-25 04:48:37');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('31', '30', 'cat hitler.jpg', 'uploads/requirements/6a8cae25c7b9f_cathitler.jpg', '2026-08-25 04:48:37');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('32', '31', 'cat hitler.jpg', 'uploads/requirements/6a8cb3b72abe3_cathitler.jpg', '2026-08-25 05:12:23');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('33', '31', 'cat hitler.jpg', 'uploads/requirements/6a8cb3b72ae24_cathitler.jpg', '2026-08-25 05:12:23');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('34', '32', 'cat hitler.jpg', 'uploads/requirements/6a8d67384ad82_cathitler.jpg', '2026-08-25 17:58:16');
INSERT INTO `document_request_files` (`file_id`, `request_id`, `file_name`, `file_path`, `uploaded_at`) VALUES ('35', '32', 'cat hitler.jpg', 'uploads/requirements/6a8d67384af64_cathitler.jpg', '2026-08-25 17:58:16');

DROP TABLE IF EXISTS `document_requests`;
CREATE TABLE `document_requests` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_number` varchar(30) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `template_id` int(11) DEFAULT NULL,
  `document_type` varchar(100) NOT NULL,
  `purpose` text NOT NULL,
  `status` enum('pending','approved','printed','released','rejected') NOT NULL DEFAULT 'pending',
  `generated_file_path` varchar(255) DEFAULT NULL,
  `admin_remarks` text DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `date_submitted` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`request_id`),
  KEY `idx_document_requests_template_id` (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('1', 'REQ-2026-001', '6', NULL, 'Certificate of Residency', 'sample', 'rejected', NULL, NULL, '9', '2026-06-24 22:08:17', '2026-06-24 20:56:23', '2026-06-24 22:08:17');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('2', 'REQ-2026-002', '10', NULL, 'Certificate of Residency', 'purpose', 'released', NULL, NULL, '9', '2026-06-27 00:15:54', '2026-06-27 00:14:37', '2026-06-27 00:15:54');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('3', 'REQ-2026-003', '10', NULL, 'Certificate of Residency', 'purpose', 'released', NULL, NULL, '7', '2026-07-29 20:47:02', '2026-06-27 00:16:24', '2026-07-29 20:47:02');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('4', 'REQ-2026-004', '10', NULL, 'Certificate of Indigency', 'purpose', 'released', NULL, NULL, '15', '2026-07-30 23:06:28', '2026-06-27 00:19:22', '2026-07-30 23:06:28');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('5', 'REQ-2026-005', '10', NULL, 'Certificate of Indigency', 'purpose', 'rejected', NULL, 'Invalid requirement', '9', '2026-06-27 00:23:26', '2026-06-27 00:19:38', '2026-06-27 00:23:26');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('6', 'REQ-2026-006', '12', NULL, 'Certificate of Indigency', 'sadwqf', 'released', 'uploads/generated_documents/REQ-2026-000_1785345349.pdf', NULL, '15', '2026-07-30 23:06:35', '2026-07-30 01:15:49', '2026-07-30 23:06:35');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('7', 'REQ-2026-007', '12', NULL, 'Certificate of Residency', 'awdwvdsv', 'rejected', 'uploads/generated_documents/REQ-2026-007_1785393883.pdf', 'sawevewv', '11', '2026-07-30 14:45:42', '2026-07-30 14:44:43', '2026-07-30 14:45:42');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('8', 'REQ-2026-008', '12', NULL, 'Certificate of Indigency', 'awfwqfwe', 'rejected', 'uploads/generated_documents/REQ-2026-008_1785394007.pdf', 'wefewvwv', '16', '2026-07-30 23:01:07', '2026-07-30 14:46:47', '2026-07-30 23:01:07');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('9', 'REQ-2026-009', '12', NULL, 'Certificate of Indigency', 'ewfewvwe', 'rejected', 'uploads/generated_documents/REQ-2026-009_1785394043.pdf', 'wefwef', '10', '2026-07-30 14:49:42', '2026-07-30 14:47:23', '2026-07-30 14:49:42');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('10', 'REQ-2026-010', '12', NULL, 'Certificate of Residency', 'cagerwvbreb', 'released', 'uploads/generated_documents/REQ-2026-010_1785394056.pdf', NULL, '14', '2026-07-30 22:56:51', '2026-07-30 14:47:36', '2026-07-30 22:56:51');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('11', 'REQ-2026-011', '12', NULL, 'Certificate of Residency', 'cwevewvwe', 'released', 'uploads/generated_documents/REQ-2026-011_1785394065.pdf', NULL, '14', '2026-07-30 22:56:52', '2026-07-30 14:47:45', '2026-07-30 22:56:52');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('12', 'REQ-2026-012', '12', NULL, 'Certificate of Residency', 'ascewgvew', 'rejected', 'uploads/generated_documents/REQ-2026-012_1785394074.pdf', 'wefwevwe', '11', '2026-07-30 14:48:08', '2026-07-30 14:47:54', '2026-07-30 14:48:08');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('13', 'REQ-2026-013', '12', NULL, 'Certificate of Indigency', 'fwqfgewg', 'rejected', 'uploads/generated_documents/REQ-2026-013_1785395031.pdf', 'dqwfwqf', '14', '2026-07-30 22:56:43', '2026-07-30 15:03:51', '2026-07-30 22:56:43');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('14', 'REQ-2026-014', '12', NULL, 'Certificate of Residency', 'qwefwegwe', 'released', 'uploads/generated_documents/REQ-2026-014_1785395059.pdf', NULL, '10', '2026-07-30 15:07:12', '2026-07-30 15:04:19', '2026-07-30 15:07:12');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('15', 'REQ-2026-015', '12', NULL, 'Certificate of Residency', 'fwqfwqf', 'rejected', 'uploads/generated_documents/REQ-2026-015_1785395089.pdf', 'fwqefewf', '10', '2026-07-30 15:07:04', '2026-07-30 15:04:49', '2026-07-30 15:07:04');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('16', 'REQ-2026-016', '12', NULL, 'Certificate of Indigency', 'wefewggewg', 'released', 'uploads/generated_documents/REQ-2026-016_1785395099.pdf', NULL, '11', '2026-07-30 15:06:01', '2026-07-30 15:04:59', '2026-07-30 15:06:01');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('17', 'REQ-2026-017', '12', NULL, 'Certificate of Indigency', 'fewqfwebwe', 'rejected', 'uploads/generated_documents/REQ-2026-017_1785395111.pdf', 'wefsvewg', '11', '2026-07-30 15:05:33', '2026-07-30 15:05:11', '2026-07-30 15:05:33');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('18', 'REQ-2026-018', '17', NULL, 'Certificate of Indigency', 'wefew', 'rejected', 'uploads/generated_documents/REQ-2026-018_1785423864.pdf', 'ewfewvwv', '16', '2026-07-30 23:07:34', '2026-07-30 23:04:24', '2026-07-30 23:07:34');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('19', 'REQ-2026-019', '17', NULL, 'Certificate of Residency', 'cwefew', 'released', 'uploads/generated_documents/REQ-2026-019_1785423878.pdf', NULL, '15', '2026-07-30 23:09:04', '2026-07-30 23:04:38', '2026-07-30 23:09:04');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('20', 'REQ-2026-020', '17', NULL, 'Certificate of Indigency', 'cwerfwe', 'released', 'uploads/generated_documents/REQ-2026-020_1785423893.pdf', NULL, '16', '2026-07-30 23:09:22', '2026-07-30 23:04:53', '2026-07-30 23:09:22');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('21', 'REQ-2026-021', '17', NULL, 'Certificate of Residency', 'cascewv', 'approved', 'uploads/generated_documents/REQ-2026-021_1785423904.pdf', NULL, '15', '2026-07-30 23:06:57', '2026-07-30 23:05:04', '2026-07-30 23:06:57');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('22', 'REQ-2026-022', '17', NULL, 'Certificate of Indigency', 'casfewvfdbv', 'rejected', 'uploads/generated_documents/REQ-2026-022_1785423916.pdf', 'wefvewvew', '15', '2026-07-30 23:06:10', '2026-07-30 23:05:16', '2026-07-30 23:06:10');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('23', 'REQ-2026-023', '17', NULL, 'Certificate of Residency', 'sacregrebc', 'approved', 'uploads/generated_documents/REQ-2026-023_1785423926.pdf', NULL, '15', '2026-07-30 23:06:00', '2026-07-30 23:05:26', '2026-07-30 23:06:00');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('24', 'REQ-2026-024', '17', NULL, 'Certificate of Indigency', 'ewfvewvwe', 'pending', 'uploads/generated_documents/REQ-2026-024_1785424115.pdf', NULL, NULL, NULL, '2026-07-30 23:08:35', '2026-07-30 23:08:35');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('25', 'REQ-2026-025', '17', NULL, 'Certificate of Residency', 'ascngfrt', 'released', 'uploads/generated_documents/REQ-2026-025_1785424124.pdf', NULL, '15', '2026-08-25 04:39:34', '2026-07-30 23:08:44', '2026-08-25 04:39:34');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('26', 'REQ-2026-026', '17', NULL, 'Certificate of Indigency', 'sacewgvew', 'pending', 'uploads/generated_documents/REQ-2026-026_1785427294.pdf', NULL, NULL, NULL, '2026-07-31 00:01:34', '2026-07-31 00:01:34');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('27', 'REQ-2026-027', '18', NULL, 'Certificate of Indigency', 'asdewqcvew', 'released', 'uploads/generated_documents/REQ-2026-027_1785681652.pdf', NULL, '16', '2026-08-02 22:46:16', '2026-08-02 22:40:52', '2026-08-02 22:46:16');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('28', 'REQ-2026-028', '17', NULL, 'Certificate of Residency', 'sacs', 'released', 'uploads/generated_documents/REQ-2026-028_1787650040.pdf', NULL, '15', '2026-08-25 17:27:41', '2026-08-24 16:23:25', '2026-08-25 17:27:41');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('29', 'REQ-2026-029', '21', '7', 'Certificate of Residency', 'ewfdvsdv', 'released', 'uploads/generated_documents/REQ-2026-029_1787600024.pdf', NULL, '15', '2026-08-25 04:39:33', '2026-08-25 03:32:47', '2026-08-25 04:39:33');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('30', 'REQ-2026-030', '21', '8', 'Barangay Clearance', 'wevwsrvfrvre', 'approved', 'uploads/generated_documents/REQ-2026-030_1787605841.pdf', NULL, '15', '2026-08-25 04:49:01', '2026-08-25 04:48:37', '2026-08-25 05:10:41');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('31', 'REQ-2026-031', '21', '9', 'Certificate of Indigency', 'ewfwefewv', 'approved', 'uploads/generated_documents/REQ-2026-031_1787605958.pdf', NULL, '20', '2026-08-25 05:12:38', '2026-08-25 05:12:23', '2026-08-25 05:12:38');
INSERT INTO `document_requests` (`request_id`, `request_number`, `user_id`, `template_id`, `document_type`, `purpose`, `status`, `generated_file_path`, `admin_remarks`, `reviewed_by`, `reviewed_at`, `date_submitted`, `date_updated`) VALUES ('32', 'REQ-2026-032', '22', '9', 'Certificate of Indigency', 'sdjbvewbvjdsvnuewb', 'released', 'uploads/generated_documents/REQ-2026-032_1787652052.pdf', NULL, '15', '2026-08-25 18:03:29', '2026-08-25 17:58:16', '2026-08-25 18:03:29');

DROP TABLE IF EXISTS `document_templates`;
CREATE TABLE `document_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `usage_count` int(11) NOT NULL DEFAULT 0,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `template_content` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `document_templates` (`id`, `name`, `category`, `description`, `fee`, `usage_count`, `file_name`, `file_path`, `template_content`, `requirements`, `created_at`, `last_modified`) VALUES ('8', 'Barangay Clearance', 'Certificates', '', '0.00', '1', '', '', 'This further certifies that, based on the available records of this Office, the above-named resident has no pending case, complaint, or derogatory record on file as of the date of issuance.', 'Valid ID\r\nProof of Residency', '2026-08-25 04:48:02', '2026-08-25 05:10:41');
INSERT INTO `document_templates` (`id`, `name`, `category`, `description`, `fee`, `usage_count`, `file_name`, `file_path`, `template_content`, `requirements`, `created_at`, `last_modified`) VALUES ('9', 'Certificate of Indigency', 'Certificates', '', '1.00', '2', '', '', 'This is to certify the above-mentioned name is classified \"INDIGENT\" in this barangay.', 'Valid Id\r\nProof of Residency', '2026-08-25 05:07:39', '2026-08-25 17:58:16');

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `reset_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`reset_id`),
  UNIQUE KEY `idx_password_resets_token_hash` (`token_hash`),
  KEY `idx_password_resets_user_id` (`user_id`),
  KEY `idx_password_resets_expires_at` (`expires_at`),
  CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`userId`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `password_resets` (`reset_id`, `user_id`, `token_hash`, `expires_at`, `used_at`, `created_at`) VALUES ('2', '15', '74a378cdf4e05d209f0c52ec2feca8a67aaae64c0b6b0abcdf7abdbb4eef41dd', '2026-08-24 15:27:02', '2026-08-24 20:46:08', '2026-08-24 20:27:02');
INSERT INTO `password_resets` (`reset_id`, `user_id`, `token_hash`, `expires_at`, `used_at`, `created_at`) VALUES ('3', '15', '323c64119353d43b871fc3b4c8fdfc0fddd9b9071c7d031ce3cc913b868f9687', '2026-08-24 15:46:08', '2026-08-24 20:51:01', '2026-08-24 20:46:08');
INSERT INTO `password_resets` (`reset_id`, `user_id`, `token_hash`, `expires_at`, `used_at`, `created_at`) VALUES ('4', '15', '3f9b3b3c81b9b4c91d2d8dc77117a9ba71b66f656defd4117550865be27f0398', '2026-08-24 15:51:01', NULL, '2026-08-24 20:51:01');

DROP TABLE IF EXISTS `requests`;
CREATE TABLE `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `doc_type` varchar(255) NOT NULL,
  `date_submitted` datetime NOT NULL,
  `date_requested` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'processing',
  `purpose` text DEFAULT NULL,
  `files` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `requests` (`id`, `user_id`, `doc_type`, `date_submitted`, `date_requested`, `status`, `purpose`, `files`, `created_at`, `updated_at`) VALUES ('1', '4', 'Certificate of Indigency', '2026-05-09 11:38:53', NULL, 'processing', 'zzz', '{\"government_id\":\"69ff00adc1c82_picka.jpg\"}', '2026-05-09 17:38:53', '2026-05-09 17:38:53');

DROP TABLE IF EXISTS `residents`;
CREATE TABLE `residents` (
  `residentId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `middleName` varchar(100) DEFAULT NULL,
  `suffix` varchar(50) DEFAULT NULL,
  `dateOfBirth` date NOT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `civilStatus` enum('Single','Married','Widowed','Separated') NOT NULL,
  `fullAddress` text NOT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL,
  `emailAddress` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`residentId`),
  UNIQUE KEY `phoneNumber` (`phoneNumber`),
  UNIQUE KEY `emailAddress` (`emailAddress`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('4', 'Miguel', 'Rivera', 'N/A', 'N/A', '2001-09-29', 'Male', 'Single', '12333 street', '09300659494', 'mglrvr55555@gmail.com', '2026-05-09 13:57:16', '2026-05-09 13:57:16');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('5', 'admin', 'admin', 'N/A', 'N/A', '2001-09-12', 'Male', 'Single', '1212123 street', '09121232211', 'admin@gmail.com', '2026-05-09 18:30:00', '2026-05-09 18:30:00');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('8', 'Miguel', 'Rivera', 'Lopez', NULL, '2001-09-19', 'Male', 'Single', 'quezon city', '09206899729', 'midguel7@gmail.com', '2026-07-29 19:47:21', '2026-07-29 19:47:21');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('10', 'Theodor', 'Bagwell', NULL, NULL, '1980-10-01', 'Male', 'Separated', 'San Mateo, Rizal', '09111111111', 'tbag@gmail.com', '2026-07-30 21:40:56', '2026-07-30 21:40:56');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('11', 'Fernando', 'Sucre', NULL, NULL, '1990-01-20', 'Male', 'Married', 'San Mateo, Rizal', '09385003281', 'fernandosucre@gmail.com', '2026-07-30 23:02:22', '2026-07-30 23:02:22');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('12', 'Alexander', 'Mahone', NULL, NULL, '1980-05-05', 'Male', 'Separated', 'San Mateo, Rizal', '09839902141', 'alexmahone@gmail.com', '2026-07-30 23:11:07', '2026-07-30 23:11:07');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('13', 'Lincoln', 'Burrows', NULL, NULL, '1980-04-11', 'Male', 'Single', 'San Mateo, Rizal', '09469480012', 'lincolnburrows@gmail.com', '2026-07-30 23:12:15', '2026-07-30 23:12:15');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('14', 'Michael', 'Scofied', NULL, NULL, '2000-11-02', 'Male', 'Single', 'San Mateo, Rizal', '09425683385', 'kennethtarroza22@gmail.com', '2026-08-24 19:17:19', '2026-08-24 20:26:43');
INSERT INTO `residents` (`residentId`, `firstName`, `lastName`, `middleName`, `suffix`, `dateOfBirth`, `sex`, `civilStatus`, `fullAddress`, `phoneNumber`, `emailAddress`, `created_at`, `updated_at`) VALUES ('15', 'Michael', 'Scofield', NULL, NULL, '2000-11-01', 'Male', 'Single', 'Krus na Ligas', '09318748921', 'michaelscofield@gmail.com', '2026-08-25 17:54:41', '2026-08-25 17:54:41');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `contact_email` varchar(150) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('resident','admin','staff') NOT NULL,
  `residentId` int(11) DEFAULT NULL,
  `account_status` varchar(20) NOT NULL DEFAULT 'pending',
  `verification_proof` varchar(255) DEFAULT NULL,
  `verification_rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `avatar_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username` (`username`),
  KEY `residentId` (`residentId`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`residentId`) REFERENCES `residents` (`residentId`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('15', 'nethhh', 'Kenneth', 'Tarroza', 'kennethtarroza22@gmail.com', '09129048371', '$2y$10$iUQ6/4XVeAhimt96JiAIIeQkZKGQ.PpUzIrfb6vzzSMBOQzQ4N/qi', 'admin', NULL, 'verified', NULL, NULL, '2026-07-30 22:58:35', '2026-07-30 22:58:35', NULL);
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('17', 'fernando', NULL, NULL, NULL, NULL, '$2y$10$iNCt.PQKUyfaK0xlrHSeeu9.cODzEr6Co7i0gM4z.34vW7h8zdAIi', 'resident', '11', 'verified', 'uploads/verification_proofs/proof_6a6b677eb6e284.63244289_cathitler.jpg', NULL, '2026-07-30 23:02:22', '2026-08-02 21:35:53', '/updated/uploads/avatars/avatar_17_1785677753.jpg');
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('18', 'alexander', NULL, NULL, NULL, NULL, '$2y$10$Y9TXXYY4/mSHeU7JR4u6m.UuiIeZsU8NIhSNcLfpnt4NUHZLSxlvC', 'resident', '12', 'verified', 'uploads/verification_proofs/proof_6a6b698b1f8ba5.74669941_cathitler.jpg', NULL, '2026-07-30 23:11:07', '2026-08-02 22:40:32', NULL);
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('20', 'tbag', 'Theodore', 'Bagwell', 'tbag@gmail.com', '09483719044', '$2y$10$E3.F55ngROscDENPpRCGVejxSBop0NYEq9s8Jghk8126ENl55BQK.', 'staff', NULL, 'verified', NULL, NULL, '2026-08-24 19:09:41', '2026-08-24 19:09:41', NULL);
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('22', 'scofield', NULL, NULL, NULL, NULL, '$2y$10$SxGu8oLLrkclllxDBHITEOW8ZZbzrdnPSIzJPcm3n8AEQZ1PV3ocy', 'resident', '15', 'verified', 'uploads/verification_proofs/proof_6a8d666138c7e3.95472757_cathitler.jpg', NULL, '2026-08-25 17:54:41', '2026-08-25 17:57:31', NULL);
INSERT INTO `users` (`userId`, `username`, `first_name`, `last_name`, `contact_email`, `contact_phone`, `password`, `role`, `residentId`, `account_status`, `verification_proof`, `verification_rejection_reason`, `created_at`, `updated_at`, `avatar_path`) VALUES ('23', 'lincoln', 'Lincoln', 'Burrows', 'lincolnburrows@gmail.com', '09123488471', '$2y$10$L8vfk3NWzak7xWSAq/.9xOGsPeau30GNk91YliXtgRgo5021sJ6R6', 'staff', NULL, 'verified', NULL, NULL, '2026-08-25 18:00:06', '2026-08-25 18:00:06', NULL);

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;




<div class="sticky-header">
    <div class="navbar-top">
        <div class="top-content">
            <div class="flag-container">
                <img class="flag-img" src="<?= $base ?>assets/ph-flag.jpg" alt="Philippine flag">
            </div>
            <div>
                <h1 class="portal-title">THE OFFICIAL WEB PORTAL OF BARANGAY KRUS NA LIGAS</h1>
            </div>
        </div>
    </div>

    <div class="navbar-main">
        <div class="nav-container">
            <nav class="nav-wrapper" id="nav-menu">
                <div class="logo-section">
                    <a href="#">
                        <img class="logo-img" src="<?= $base ?>assets/logo.png" alt="Barangay logo">
                    </a>
                </div>
                <div class="mobile-toggle">
                    <i class="ri-menu-line" id="hamburger"></i>
                </div>
                <div class="nav-menu-desktop">
                    <ul class="nav-links">
                        <li>
                            <a href="<?= $base ?>index.php">HOME</a>
                        </li>
                        <li>
                            <a href="<?= $base ?>pages/about.php">ABOUT US</a>
                        </li>
                        <li>
                            <a href="<?= $base ?>pages/complaint.php">COMPLAINT</a>
                        </li>
                        <li>
                            <a href="<?= $base ?>index.php#contact">CONTACT</a>
                        </li>
                        <li>
                            <a href="<?= $base ?>pages/hotline.php">HOTLINES</a>
                        </li>
                        <li>
                            <a href="<?= $base ?>pages/service.php">SERVICES</a>
                        </li>
                        <li>
                            <a href="<?= $base ?>pages/loginPage.php">LOGIN</a>
                        </li>
                        <li>
                            <a href="<?= $base ?>pages/registerPage.php">REGISTER</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="search-section-desktop">
                <div class="search-group">
                    <input class="search-input" type="text" name="" placeholder="Search">
                    <button type="submit" name="" class="search-btn">Search</button>
                </div>
            </div>
        </div>
    </div>

    <!-- MOBILE MENU DROPDOWN -->
    <div id="mobile-menu" class="mobile-menu-dropdown hidden">
        <div class="mobile-menu-content">
            <ul class="mobile-links">
                <li>
                    <a href="<?= $base ?>index.php">HOME</a>
                </li>
                <li>
                    <a href="<?= $base ?>pages/about.php">ABOUT US</a>
                </li>
                <li>
                    <a href="<?= $base ?>pages/complaint.php">COMPLAINT</a>
                </li>
                <li>
                    <a href="<?= $base ?>index.php#contact">CONTACT</a>
                </li>
                <li>
                    <a href="<?= $base ?>pages/hotline.php">HOTLINES</a>
                </li>
                <li>
                    <a href="<?= $base ?>pages/service.php">SERVICES</a>
                </li>
                <li>
                    <a href="<?= $base ?>pages/loginPage.php">LOGIN</a>
                </li>
                <li>
                    <a href="<?= $base ?>pages/registerPage.php">REGISTER</a>
                </li>
            </ul>
            <div class="search-group mobile-search">
                <input class="search-input" type="text" name="" placeholder="Search">
                <button type="submit" name="" class="search-btn">Search</button>
            </div>
        </div>
    </div>
</div>



<div class="hotline-footer">
    <div class="footer-content">
        <p class="city-gov">City Government of Quezon City</p>
        <p class="update-info">This directory is regularly updated. For the most current information, please visit 
            the official Quezon City government website.
        </p>
        <p class="last-updated">Last Updated: January 2026</p>
    </div>
</div>
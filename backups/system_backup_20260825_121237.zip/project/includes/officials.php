


<div class="officials-section">
    <h2 class="section-title">YOUR BARANGAY KRUS NA LIGAS SERVANT</h2>
    
    <div class="officials-container">
        <div class="chairman-row">
            <div class="official-card">
                <img src="<?= $base ?>assets/officials/chairman.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Reniel John Perdido</h3>
                <p class="official-role">PUNONG BARANGAY</p>
            </div>
        </div>

        <div class="official-grid">
            <div class="official-card">
                <img src="<?= $base ?>assets/officials/sk-chairman.png" class="official-img" alt="Sk-Chairman">
                <h3 class="official-name">Michael Angelo Dimaayo</h3>
                <p class="official-role">SK CHAIRPERSON</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/secretary.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Jonathan Sombrero</h3>
                <p class="official-role">SECRETARY</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/treasurer.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Joe-Marie Jalla</h3>
                <p class="official-role">TREASURER</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/kag-angelo.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Angelo Agpaoa</h3>
                <p class="official-role">BARANGAY KAGAWAD</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/kag-arlene.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Arlene Montiano-Dayag</h3>
                <p class="official-role">BARANGAY KAGAWAD</p>
            </div>
        </div>

        <div class="official-grid">
            <div class="official-card">
                <img src="<?= $base ?>assets/officials/kag-felix.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Felix Cuevas</h3>
                <p class="official-role">BARANGAY KAGAWAD</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/kag-irene.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Irene Dela Cruz</h3>
                <p class="official-role">BARANGAY KAGAWAD</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/kag-jessie.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Jessie Virtucio</h3>
                <p class="official-role">BARANGAY KAGAWAD</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/kag-patria.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Patria Uchi</h3>
                <p class="official-role">BARANGAY KAGAWAD</p>
            </div>

            <div class="official-card">
                <img src="<?= $base ?>assets/officials/kag-wilfredo.png" class="official-img" alt="Chairman">
                <h3 class="official-name">Wilfredo Fulgencio</h3>
                <p class="official-role">BARANGAY KAGAWAD</p>
            </div>
        </div>
    </div>
</div>
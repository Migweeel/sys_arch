    const avatarTrigger = document.getElementById("avatarTrigger");
    const avatarInput = document.getElementById("avatarInput");
    const avatarPreview = document.getElementById("avatarPreview");

    avatarTrigger.addEventListener("click", () => avatarInput.click());

    avatarInput.addEventListener("change", () => {
    const file = avatarInput.files[0];
    if(!file) return;

    // file size check
    if(file.size > 25 * 1024 * 1024){
        alert("Maximum file size: 25MB");
        avatarInput.value = "";
        return;
    }

    const formData = new FormData();
    formData.append("avatar", file);

    fetch("../actions/uploadAvatar.php", { method: "POST", body: formData })
        .then(res => res.json())
        .then(data => {
        if(data.success){
            if (avatarPreview) {
                avatarPreview.src = data.avatarPath + "?" + new Date().getTime();
                avatarPreview.style.display = "block";
            } else {
                const img = document.createElement("img");
                img.id = "avatarPreview";
                img.src = data.avatarPath + "?" + new Date().getTime();
                img.alt = "Profile avatar";
                avatarTrigger.prepend(img);
            }
            const icon = avatarTrigger.querySelector(".avatar-upload-icon");
            if (icon) icon.style.display = "none";
            avatarTrigger.classList.add("has-avatar");
        } else {
            alert("Upload error: " + data.error);
        }
        })
        .catch(err => {
        console.error(err);
        alert("Upload failed. Check console.");
        });
    });
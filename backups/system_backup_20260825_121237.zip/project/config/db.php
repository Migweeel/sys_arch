<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "krus_na_ligas_db";

function ensureUserTableColumns($conn, $database) {
    $safeDatabase = mysqli_real_escape_string($conn, $database);
    $columnChecks = [
        'account_status' => "ALTER TABLE `users` ADD COLUMN `account_status` VARCHAR(20) NOT NULL DEFAULT 'pending' AFTER `residentId`",
        'verification_proof' => "ALTER TABLE `users` ADD COLUMN `verification_proof` VARCHAR(255) DEFAULT NULL AFTER `account_status`",
        'verification_rejection_reason' => "ALTER TABLE `users` ADD COLUMN `verification_rejection_reason` TEXT DEFAULT NULL AFTER `verification_proof`",
        'updated_at' => "ALTER TABLE `users` ADD COLUMN `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`"
    ];

    foreach ($columnChecks as $columnName => $alterSql) {
        $checkSql = "SELECT COUNT(*) AS column_count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$safeDatabase' AND TABLE_NAME = 'users' AND COLUMN_NAME = '$columnName'";
        $checkResult = mysqli_query($conn, $checkSql);

        if ($checkResult && $row = mysqli_fetch_assoc($checkResult)) {
            if ((int) $row['column_count'] === 0) {
                mysqli_query($conn, $alterSql);
            }
        }
    }
}

function ensureActivityLogsTable($conn, $database) {
    $safeDatabase = mysqli_real_escape_string($conn, $database);
    $checkSql = "SELECT COUNT(*) AS table_count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '$safeDatabase' AND TABLE_NAME = 'activity_logs'";
    $checkResult = mysqli_query($conn, $checkSql);

    if ($checkResult && $row = mysqli_fetch_assoc($checkResult)) {
        if ((int) $row['table_count'] === 0) {
            $createSql = "CREATE TABLE activity_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL DEFAULT 0,
                username VARCHAR(100) NOT NULL DEFAULT '',
                role VARCHAR(50) NOT NULL DEFAULT 'resident',
                action VARCHAR(50) NOT NULL DEFAULT 'activity',
                description TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_activity_logs_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            mysqli_query($conn, $createSql);
        }
    }
}

function ensureDocumentTemplatesTable($conn, $database) {
    $safeDatabase = mysqli_real_escape_string($conn, $database);
    $checkSql = "SELECT COUNT(*) AS table_count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '$safeDatabase' AND TABLE_NAME = 'document_templates'";
    $checkResult = mysqli_query($conn, $checkSql);

    if ($checkResult && $row = mysqli_fetch_assoc($checkResult)) {
        if ((int) $row['table_count'] === 0) {
            $createSql = "CREATE TABLE document_templates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                category VARCHAR(100) NOT NULL,
                description TEXT DEFAULT NULL,
                fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                usage_count INT NOT NULL DEFAULT 0,
                file_name VARCHAR(255) DEFAULT NULL,
                file_path VARCHAR(255) DEFAULT NULL,
                template_content TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            mysqli_query($conn, $createSql);
        }
    }
}

function ensureDocumentRequestGeneratedFileColumn($conn, $database) {
    $safeDatabase = mysqli_real_escape_string($conn, $database);
    $checkSql = "SELECT COUNT(*) AS column_count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$safeDatabase' AND TABLE_NAME = 'document_requests' AND COLUMN_NAME = 'generated_file_path'";
    $checkResult = mysqli_query($conn, $checkSql);

    if ($checkResult && $row = mysqli_fetch_assoc($checkResult)) {
        if ((int) $row['column_count'] === 0) {
            mysqli_query($conn, "ALTER TABLE document_requests ADD COLUMN generated_file_path VARCHAR(255) DEFAULT NULL AFTER status");
        }
    }
}

// Try to connect to the database
$conn = mysqli_connect($host, $username, $password, $database);

// If database doesn't exist, create it
if (!$conn) {
    // Connect without specifying database
    $conn = mysqli_connect($host, $username, $password);

    if (!$conn) {
        // Instead of dying, set conn to null and let the application handle it
        $conn = null;
    } else {
        // Create the database
        $sql = "CREATE DATABASE IF NOT EXISTS `$database` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        if (mysqli_query($conn, $sql)) {
            // Now connect to the newly created database
            mysqli_select_db($conn, $database);
            ensureUserTableColumns($conn, $database);
            ensureActivityLogsTable($conn, $database);
            ensureDocumentTemplatesTable($conn, $database);
            ensureDocumentRequestGeneratedFileColumn($conn, $database);
        } else {
            // If database creation fails, set conn to null
            mysqli_close($conn);
            $conn = null;
        }
    }
} else {
    mysqli_set_charset($conn, 'utf8mb4');
    ensureUserTableColumns($conn, $database);
    ensureActivityLogsTable($conn, $database);
    ensureDocumentTemplatesTable($conn, $database);
    ensureDocumentRequestGeneratedFileColumn($conn, $database);
}

﻿<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/db.php';
require_once '../helpers/functions.php';

$userId = (int) ($_SESSION['user_id'] ?? 0);
$username = $_SESSION['username'] ?? 'Unknown User';
$role = strtolower($_SESSION['role'] ?? 'resident');
$timedOut = isset($_GET['timeout']) && $_GET['timeout'] === '1';

if ($userId > 0 && isset($conn) && $conn instanceof mysqli) {
    $description = $timedOut ? 'User was logged out due to inactivity.' : 'User logged out of the system';
    logActivity($conn, $userId, $username, $role, 'logout', $description);
}

session_unset();
session_destroy();

session_start();
require_once 'session.php';

$_SESSION['success'] = $timedOut
    ? 'Account logged out due to inactivity. Please login again to continue.'
    : 'You have been logged out successfully.';

header('Location: ../pages/loginPage.php');
exit();

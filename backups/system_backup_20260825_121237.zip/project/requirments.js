document.addEventListener("DOMContentLoaded", () => {
  const docType = document.getElementById("doc-type");
  const container = document.getElementById("requirementsContainer");
  const submitBtn = document.querySelector(".submit-btn");
  const isVerified = submitBtn?.dataset.verified === "1";
  const MAX_SIZE = 25 * 1024 * 1024;

  if (!docType || !container || !submitBtn) {
    return;
  }

  const escapeHtml = value => String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");

  const requirementKey = value => {
    const key = String(value).toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
    return key || "requirement";
  };

  const parseRequirements = option => {
    if (!option) {
      return [];
    }

    try {
      const parsed = JSON.parse(option.dataset.requirements || "[]");
      if (Array.isArray(parsed)) {
        return parsed.map(item => String(item).trim()).filter(Boolean);
      }
    } catch (error) {
      return [];
    }

    return [];
  };

  const buildRequirementsHtml = requirements => {
    const items = requirements.length > 0 ? requirements : ["Government ID"];
    const usedKeys = new Map();

    return `
      <div class="requirements-section">
        <h3>REQUIREMENTS</h3>
        ${items.map(label => {
          const baseKey = requirementKey(label);
          const count = (usedKeys.get(baseKey) || 0) + 1;
          usedKeys.set(baseKey, count);
          const key = count > 1 ? `${baseKey}_${count}` : baseKey;
          const inputId = `requirements_${key}`;

          return `
            <div class="requirement-item">
              <span>${escapeHtml(label)}</span>
              <label class="action-btn" for="${escapeHtml(inputId)}">
                <span class="upload-text">Upload</span>
                <input id="${escapeHtml(inputId)}" class="upload-input" type="file" name="requirements[${escapeHtml(key)}]" required>
              </label>
            </div>
          `;
        }).join("")}
      </div>
    `;
  };

  docType.addEventListener("change", () => {
    const selectedOption = docType.options[docType.selectedIndex];
    const requirements = parseRequirements(selectedOption);
    container.innerHTML = buildRequirementsHtml(requirements);
    submitBtn.disabled = true;

    const inputs = container.querySelectorAll("input[type=file]");

    if (!isVerified) {
      inputs.forEach(input => {
        input.disabled = true;
      });
      submitBtn.disabled = true;
      return;
    }

    inputs.forEach(input => {
      input.addEventListener("change", () => {
        if (!input.files || !input.files[0]) {
          return;
        }

        if (input.files[0].size > MAX_SIZE) {
          alert("File must not exceed 25MB.");
          input.value = "";
          const textSpan = input.parentElement.querySelector(".upload-text");
          if (textSpan) textSpan.textContent = "Upload";
          submitBtn.disabled = true;
          return;
        }

        const textSpan = input.parentElement.querySelector(".upload-text");
        if (textSpan) {
          textSpan.textContent = input.files[0].name;
        }

        const allFilled = [...inputs].every(i => i.files.length > 0);
        submitBtn.disabled = !allFilled;
      });
    });

    container.querySelectorAll(".action-btn").forEach(label => {
      const input = label.querySelector("input[type=file]");
      if (!input) return;
      label.addEventListener("click", event => {
        if (event.target !== input) {
          input.click();
        }
      });
    });
  });
});

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['avatar'])) {
        echo "File received: " . $_FILES['avatar']['name'];
    } else {
        echo "No file received";
    }
}
?>

<form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="avatar" />
    <button type="submit">Upload</button>
</form>
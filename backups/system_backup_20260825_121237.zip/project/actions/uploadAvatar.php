<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once "../config/db.php"; // make sure this path is correct
header('Content-Type: application/json');

// Check DB connection
if(!$conn){
    echo json_encode(['success'=>false,'error'=>'DB connection failed']);
    exit;
}

// Check login
if(!isset($_SESSION['user_id'])){
    echo json_encode(['success'=>false,'error'=>'Not logged in']);
    exit;
}

$userId = $_SESSION['user_id'];

// Check file
if(!isset($_FILES['avatar'])){
    echo json_encode(['success'=>false,'error'=>'No file uploaded']);
    exit;
}

$file = $_FILES['avatar'];

// Check upload error
if($file['error'] !== UPLOAD_ERR_OK){
    echo json_encode(['success'=>false,'error'=>'Upload error']);
    exit;
}

// Optional: validate file type
$allowedTypes = ['image/jpeg','image/png','image/gif'];
if(!in_array($file['type'], $allowedTypes)){
    echo json_encode(['success'=>false,'error'=>'Invalid file type']);
    exit;
}

// Optional: validate file size (max 25MB)
if($file['size'] > 25*1024*1024){
    echo json_encode(['success'=>false,'error'=>'File too large']);
    exit;
}

// Upload directory
$uploadDir = __DIR__ . '/../uploads/avatars/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

// Save file
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = "avatar_{$userId}_" . time() . "." . $ext;
$filepath = $uploadDir . $filename;

if(!move_uploaded_file($file['tmp_name'], $filepath)){
    echo json_encode(['success'=>false,'error'=>'Failed to save file']);
    exit;
}

// Generate public path for avatar from this application's base path
$siteBase = str_replace('/actions', '', dirname($_SERVER['SCRIPT_NAME']));
$relativePath = rtrim($siteBase, '/') . '/uploads/avatars/' . $filename;
$stmt = $conn->prepare("UPDATE users SET avatar_path=? WHERE userId=?");
if(!$stmt){
    echo json_encode(['success'=>false,'error'=>'DB prepare failed: '.$conn->error]);
    exit;
}

$stmt->bind_param("si", $relativePath, $userId);
if(!$stmt->execute()){
    echo json_encode(['success'=>false,'error'=>'DB execute failed: '.$stmt->error]);
    exit;
}

$stmt->close();

// Success
echo json_encode(['success'=>true,'avatarPath'=>$relativePath]);
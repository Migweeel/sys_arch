<?php



// SANITIZE DATA
function clean($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}


// VALIDATION
function emptyField($username, $password, $confirmPassword, $firstName, $lastName, $birthdate, $sex, $address, $civilStatus, $phoneNumber, $email) {
    if(empty($username) || empty($password) || empty($confirmPassword) || empty($firstName) || empty($lastName) || empty($birthdate) 
        || empty($sex) || empty($address) || empty($civilStatus) || empty($phoneNumber) || empty($email)) {
        
        return true;    
    }

    return false;
}


function invalidNamePattern($firstName, $lastName) {
    $namePattern = "/^[a-zA-Z\sñÑ.]+$/";

    if ((!empty($firstName) || !empty($lastName)) && (!preg_match($namePattern, $firstName) || !preg_match($namePattern, $lastName))) {
        return true;
    }

    return false;

}


function invalidSex($sex) {
    $validSex = ['Male', 'Female'];

    if (!empty($sex) && !in_array($sex, $validSex)) {
        return true;
    }

    return false;
}


function invalidCivilStatus($civilStatus) {
    $validCivilStatus = ['Single', 'Married', 'Widowed', 'Separated'];

    if (!empty($civilStatus) && !in_array($civilStatus, $validCivilStatus)) {
        return true;
    }

    return false;
}


function passwordNotMatch($password, $confirmPassword) {
    if ($password !== $confirmPassword) {
        return true;
    }

    return false;
}


function passwordLength($password) {
    if (!empty($password) && strlen($password) < 8) {
        return true;
    }

    return false;
}


function invalidPhoneNo($phoneNumber) {
    if (!empty($phoneNumber) && !preg_match('/^09[0-9]{9}$/', $phoneNumber)) {
        return true;
    }

    return false;
}


function usernameTaken($conn, $username) {
    $stmt = mysqli_prepare($conn, "SELECT username FROM users WHERE LOWER(username) = LOWER(?) LIMIT 1");
    
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        return true;
    }

    return false;
}


function emailRegistered($conn, $email) {
    $stmt = mysqli_prepare($conn, "SELECT emailAddress FROM residents WHERE emailAddress = ? LIMIT 1");
    
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    return mysqli_num_rows($result) > 0;
}


function phoneRegistered($conn, $phoneNumber) {
    $stmt = mysqli_prepare($conn, "SELECT phoneNumber FROM residents WHERE phoneNumber = ? LIMIT 1");
    
    mysqli_stmt_bind_param($stmt, "s", $phoneNumber);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    return mysqli_num_rows($result) > 0;
}

function userColumnExists($conn, $columnName) {
    static $cache = [];

    if (!$conn) {
        return false;
    }

    if (isset($cache[$columnName])) {
        return $cache[$columnName];
    }

    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS column_count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = ?");
    if (!$stmt) {
        $cache[$columnName] = false;
        return false;
    }

    mysqli_stmt_bind_param($stmt, "s", $columnName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    $cache[$columnName] = $row && (int) $row['column_count'] > 0;
    return $cache[$columnName];
}

function userAccountLogLabel($conn, $userId) {
    $userId = (int) $userId;
    if (!$conn || $userId <= 0) {
        return 'Unknown account';
    }

    $firstNameSelect = userColumnExists($conn, 'first_name') ? 'u.first_name AS accountFirstName' : 'NULL AS accountFirstName';
    $lastNameSelect = userColumnExists($conn, 'last_name') ? 'u.last_name AS accountLastName' : 'NULL AS accountLastName';

    $sql = "SELECT
            u.username,
            u.role,
            $firstNameSelect,
            $lastNameSelect,
            res.firstName AS residentFirstName,
            res.lastName AS residentLastName
        FROM users u
        LEFT JOIN residents res ON u.residentId = res.residentId
        WHERE u.userId = ?
        LIMIT 1";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return 'User account #' . $userId;
    }

    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    if (!$user) {
        return 'User account #' . $userId;
    }

    $residentName = trim((string) ($user['residentFirstName'] ?? '') . ' ' . (string) ($user['residentLastName'] ?? ''));
    $accountName = trim((string) ($user['accountFirstName'] ?? '') . ' ' . (string) ($user['accountLastName'] ?? ''));
    $displayName = $residentName ?: ($accountName ?: ($user['username'] ?? ('User #' . $userId)));
    $username = trim((string) ($user['username'] ?? ''));
    $role = ucfirst((string) ($user['role'] ?? 'user'));

    $details = [];
    if ($username !== '') {
        $details[] = 'username: ' . $username;
    }
    if ($role !== '') {
        $details[] = 'role: ' . $role;
    }

    return $displayName . ($details ? ' (' . implode(', ', $details) . ')' : '');
}

function formatActivityLogDescription($conn, $description) {
    $description = trim((string) $description);
    if ($description === '') {
        return 'System activity';
    }

    if (preg_match('/\buser account #(\d+)\b/i', $description, $matches)) {
        $userId = (int) $matches[1];
        $userLabel = userAccountLogLabel($conn, $userId);

        if (stripos($userLabel, 'User account #') !== 0) {
            return preg_replace('/\buser account #' . preg_quote((string) $userId, '/') . '\b/i', 'user account: ' . $userLabel, $description, 1);
        }
    }

    return $description;
}


function invalidBirthdate($birthdate) {
    if (empty($birthdate)) return true;

    $dateInput = strtotime($birthdate);
    $currentDate = time();
    $minYear = strtotime("1900-01-01");

    if ($dateInput > $currentDate || $dateInput < $minYear) {
        return true;
    }
    
    return false;
}

function buildResidentDocumentData($residentData, $requestData) {
    $fullName = trim((string) ($residentData['first_name'] ?? '') . ' ' . (string) ($residentData['middle_name'] ?? '') . ' ' . (string) ($residentData['last_name'] ?? '') . ' ' . (string) ($residentData['suffix'] ?? ''));
    $fullName = preg_replace('/\s+/', ' ', $fullName);
    $fullName = trim($fullName);

    $address = trim((string) ($residentData['address'] ?? '') . ' ' . (string) ($residentData['full_address'] ?? ''));
    $address = preg_replace('/\s+/', ' ', $address);

    $birthdate = trim((string) ($residentData['birthdate'] ?? ''));
    $age = '';
    if ($birthdate !== '') {
        try {
            $dob = new DateTime($birthdate);
            $now = new DateTime('today');
            $age = (string) $now->diff($dob)->y;
        } catch (Exception $e) {
            $age = '';
        }
    }

    $issueDate = trim((string) ($requestData['date'] ?? ''));
    if ($issueDate === '') {
        $issueDate = date('F j, Y');
    }
    $residentName = $fullName ?: ($residentData['full_name'] ?? '');
    $residentAddress = $address ?: 'Barangay Krus na Ligas, Quezon City';
    $agePhrase = $age !== '' ? $age . ' years old' : 'of legal age';

    return [
        'name' => $residentName,
        'full_name' => $residentName,
        'first_name' => $residentData['first_name'] ?? '',
        'last_name' => $residentData['last_name'] ?? '',
        'middle_name' => $residentData['middle_name'] ?? '',
        'suffix' => $residentData['suffix'] ?? '',
        'age' => $age,
        'age_phrase' => $agePhrase,
        'address' => $residentAddress,
        'full_address' => $residentAddress,
        'document_type' => $requestData['document_type'] ?? '',
        'purpose' => $requestData['purpose'] ?? '',
        'request_number' => $requestData['request_number'] ?? '',
        'date' => $issueDate,
        'today' => $issueDate,
        'barangay' => 'Barangay Krus na Ligas',
        'city' => 'Quezon City',
        'office' => 'Office of the Punong Barangay',
        'prepared_by' => 'Barangay Staff',
        'approved_by' => 'Punong Barangay'
    ];
}

function applyDocumentPlaceholders($content, $data) {
    $replacements = [];
    foreach ($data as $key => $value) {
        $replacements['{{' . $key . '}}'] = (string) $value;
        $replacements['[[' . $key . ']]'] = (string) $value;
        $replacements['{' . $key . '}'] = (string) $value;
    }

    return strtr((string) $content, $replacements);
}

// FUNCTIONS_PHP_VERSION: 2026-08-25-fix2
function databaseColumnExists($conn, $tableName, $columnName) {
    if (!$conn) {
        return false;
    }

    $tableName = trim((string) $tableName);
    $columnName = trim((string) $columnName);
    if ($tableName === '' || $columnName === '') {
        return false;
    }
    if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName) || !preg_match('/^[A-Za-z0-9_]+$/', $columnName)) {
        return false;
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1"
    );
    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, 'ss', $tableName, $columnName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $exists = mysqli_fetch_assoc($result) !== null;
    mysqli_stmt_close($stmt);

    return $exists;
}

function documentTemplateSelectColumns($conn) {
    // The `requirements` column is part of the base schema (see document_templates
    // CREATE TABLE), so it is always selected directly instead of being probed at
    // runtime via databaseColumnExists(). This avoids relying on a prepared
    // SHOW COLUMNS / information_schema lookup on every request.
    return "id, name, category, description, fee, usage_count, file_name, file_path, template_content, requirements, created_at, last_modified";
}

function getDocumentTemplates($conn) {
    if (!$conn) {
        return [];
    }

    $templates = [];
    $selectColumns = documentTemplateSelectColumns($conn);
    $sql = "SELECT $selectColumns
            FROM document_templates
            ORDER BY name ASC, id ASC";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $templates[] = $row;
        }
    }

    return $templates;
}

function getDocumentTemplateById($conn, $templateId) {
    $templateId = (int) $templateId;
    if (!$conn || $templateId <= 0) {
        return null;
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT " . documentTemplateSelectColumns($conn) . "
         FROM document_templates
         WHERE id = ?
         LIMIT 1"
    );
    if (!$stmt) {
        return null;
    }

    mysqli_stmt_bind_param($stmt, 'i', $templateId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $template = mysqli_fetch_assoc($result) ?: null;
    mysqli_stmt_close($stmt);

    return $template;
}

function getDocumentTemplateForRequest($conn, $requestData) {
    $templateId = (int) ($requestData['template_id'] ?? 0);
    if ($templateId > 0) {
        $template = getDocumentTemplateById($conn, $templateId);
        if ($template) {
            return $template;
        }
    }

    $documentType = trim((string) ($requestData['document_type'] ?? ''));
    if (!$conn || $documentType === '') {
        return null;
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT " . documentTemplateSelectColumns($conn) . "
         FROM document_templates
         WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
         ORDER BY id DESC
         LIMIT 1"
    );
    if (!$stmt) {
        return null;
    }

    mysqli_stmt_bind_param($stmt, 's', $documentType);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $template = mysqli_fetch_assoc($result) ?: null;
    mysqli_stmt_close($stmt);

    return $template;
}

function parseDocumentTemplateRequirements($requirementsText) {
    $lines = preg_split('/\r\n|\r|\n/', (string) $requirementsText);
    $requirements = [];
    foreach ($lines as $line) {
        $requirement = trim($line);
        if ($requirement !== '') {
            $requirements[] = $requirement;
        }
    }

    return array_values(array_unique($requirements));
}

function normalizeBarangayDocumentType($documentType) {
    $type = strtolower(trim((string) $documentType));
    if (strpos($type, 'indigency') !== false || strpos($type, 'indigent') !== false) {
        return 'indigency';
    }
    if (strpos($type, 'residency') !== false || strpos($type, 'resident') !== false) {
        return 'residency';
    }
    if (strpos($type, 'clearance') !== false) {
        return 'clearance';
    }
    return 'certificate';
}

function getDefaultBarangayDocumentTemplates() {
    $now = date('Y-m-d H:i:s');
    return [
        [
            'id' => -1,
            'name' => 'Barangay Clearance',
            'category' => 'Certificates',
            'description' => 'Formal clearance certifying residency, good moral character, and no derogatory barangay record.',
            'fee' => 0,
            'usage_count' => 0,
            'file_name' => null,
            'file_path' => null,
            'template_content' => getBarangayDocumentTemplateContent('Barangay Clearance'),
            'created_at' => $now,
            'last_modified' => $now,
            'is_default' => true,
        ],
        [
            'id' => -2,
            'name' => 'Certificate of Residency',
            'category' => 'Certificates',
            'description' => 'Standard barangay certification that the requester is a bona fide resident of the barangay.',
            'fee' => 0,
            'usage_count' => 0,
            'file_name' => null,
            'file_path' => null,
            'template_content' => getBarangayDocumentTemplateContent('Certificate of Residency'),
            'created_at' => $now,
            'last_modified' => $now,
            'is_default' => true,
        ],
        [
            'id' => -3,
            'name' => 'Certificate of Indigency',
            'category' => 'Certificates',
            'description' => 'Formal certification for residents requesting assistance, scholarship, medical, or other support.',
            'fee' => 0,
            'usage_count' => 0,
            'file_name' => null,
            'file_path' => null,
            'template_content' => getBarangayDocumentTemplateContent('Certificate of Indigency'),
            'created_at' => $now,
            'last_modified' => $now,
            'is_default' => true,
        ],
    ];
}

function mergeDefaultBarangayDocumentTemplates($templates) {
    $existingNames = [];
    foreach ($templates as $template) {
        $existingNames[strtolower(trim((string) ($template['name'] ?? '')))] = true;
    }

    foreach (getDefaultBarangayDocumentTemplates() as $defaultTemplate) {
        $defaultName = strtolower(trim((string) ($defaultTemplate['name'] ?? '')));
        if (!isset($existingNames[$defaultName])) {
            $templates[] = $defaultTemplate;
        }
    }

    return $templates;
}

function getBarangayDocumentTemplateContent($documentType = '') {
    // Single, generic fallback body — used only as a starting point/placeholder
    // (e.g. when seeding the built-in default templates, or if a template ends up
    // with no content at all). It is the SAME for every document type; nothing
    // certificate-specific (indigency wording, clearance wording, residency
    // wording, or wording for any new type an admin invents) is hardcoded here.
    // All of that now lives purely in whatever the admin/staff types into the
    // "Template Body" field when they create or edit a template.
    return "has requested a barangay document from this Office.";
}

function buildBarangayDocumentCertificate($data) {
    $documentType = trim((string) ($data['document_type'] ?? 'Barangay Certificate'));

    return buildBarangayDocumentCertificateFromTemplate(getBarangayDocumentTemplateContent($documentType), $data);
}

function buildBarangayDocumentCertificateFromTemplate($templateContent, $data) {
    $name = trim((string) ($data['name'] ?? 'Resident'));
    $agePhrase = trim((string) ($data['age_phrase'] ?? 'of legal age'));
    $address = trim((string) ($data['address'] ?? 'Barangay Krus na Ligas, Quezon City'));
    $purpose = trim((string) ($data['purpose'] ?? 'official purposes'));
    if ($purpose === '') {
        $purpose = 'official purposes';
    }
    $issueDate = trim((string) ($data['date'] ?? date('F j, Y')));
    $documentType = trim((string) ($data['document_type'] ?? 'Barangay Certificate'));

    // FIXED / hardcoded opening paragraph. Same structure for every certificate
    // type, filled in with the real resident data by code, and a complete
    // standalone sentence (ends with a period). Admin/staff never has to type
    // a placeholder for this part, and it never merges into the Template Body.
    $openingParagraph = 'This is to certify that ' . $name . ', ' . $agePhrase . ', a resident of ' . $address . '.';

    // Whatever the admin/staff typed in "Template Body" is used exactly as written,
    // no placeholders needed. Every non-empty line becomes its own paragraph,
    // starting fresh after the opening paragraph above (no auto-merging).
    $rawBody = trim((string) $templateContent);
    $bodyLines = preg_split('/\r\n|\r|\n/', $rawBody);
    $bodyParagraphs = array_values(array_filter(array_map('trim', $bodyLines), static function ($line) {
        return $line !== '';
    }));

    // FIXED / hardcoded closing paragraphs. Same for every certificate type, filled
    // in with the real purpose/date by code.
    $closingParagraph = 'This certification is issued upon the request of the above-named resident for ' . $purpose . ' and for whatever lawful purpose it may serve.';
    $issuedLine = 'Issued this ' . $issueDate . ' at Barangay Krus na Ligas, Quezon City, Philippines.';

    $paragraphs = array_merge([$openingParagraph], $bodyParagraphs, [$closingParagraph, $issuedLine]);

    return [
        'title' => strtoupper($documentType),
        'control_number' => trim((string) ($data['request_number'] ?? '')),
        'date' => $issueDate,
        'paragraphs' => $paragraphs,
        'prepared_by' => trim((string) ($data['prepared_by'] ?? 'Barangay Staff')),
        'approved_by' => trim((string) ($data['approved_by'] ?? 'Punong Barangay')),
    ];
}

function buildBarangayDocumentPlainText($certificate) {
    $lines = [
        'Republic of the Philippines',
        'Quezon City',
        'Barangay Krus na Ligas',
        'Office of the Punong Barangay',
        '',
        trim((string) ($certificate['title'] ?? 'BARANGAY CERTIFICATE')),
        'Control No. ' . trim((string) ($certificate['control_number'] ?? '')),
        '',
        'TO WHOM IT MAY CONCERN:',
        '',
    ];

    foreach (($certificate['paragraphs'] ?? []) as $paragraph) {
        $paragraph = trim((string) $paragraph);
        if ($paragraph !== '') {
            $lines[] = $paragraph;
            $lines[] = '';
        }
    }

    $lines[] = 'Prepared by: ' . trim((string) ($certificate['prepared_by'] ?? 'Barangay Staff'));
    $lines[] = 'Approved by: ' . trim((string) ($certificate['approved_by'] ?? 'Punong Barangay'));

    return implode("\n", $lines);
}

function generateDocumentForRequest($conn, $requestId, $outputDir) {
    $requestId = (int) $requestId;
    if (!$conn || $requestId <= 0) {
        return '';
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT
            r.request_id,
            r.request_number,
            r.document_type,
            r.purpose,
            r.template_id,
            r.reviewed_at,
            r.date_updated,
            res.firstName,
            res.middleName,
            res.lastName,
            res.suffix,
            res.dateOfBirth,
            res.fullAddress
         FROM document_requests r
         LEFT JOIN users u ON r.user_id = u.userId
         LEFT JOIN residents res ON u.residentId = res.residentId
         WHERE r.request_id = ?
         LIMIT 1"
    );
    if (!$stmt) {
        return '';
    }

    mysqli_stmt_bind_param($stmt, 'i', $requestId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $request = mysqli_fetch_assoc($result) ?: null;
    mysqli_stmt_close($stmt);

    if (!$request) {
        return '';
    }

    $issueSourceDate = $request['reviewed_at'] ?: ($request['date_updated'] ?? '');
    $issueDate = $issueSourceDate ? date('F j, Y', strtotime($issueSourceDate)) : date('F j, Y');
    $documentData = buildResidentDocumentData([
        'first_name' => $request['firstName'] ?? '',
        'middle_name' => $request['middleName'] ?? '',
        'last_name' => $request['lastName'] ?? '',
        'suffix' => $request['suffix'] ?? '',
        'birthdate' => $request['dateOfBirth'] ?? '',
        'address' => $request['fullAddress'] ?? '',
    ], [
        'document_type' => $request['document_type'] ?? 'Barangay Certificate',
        'purpose' => $request['purpose'] ?? 'official purposes',
        'request_number' => $request['request_number'] ?? '',
        'date' => $issueDate,
    ]);

    $template = getDocumentTemplateForRequest($conn, $request);
    $templateContent = $template['template_content'] ?? getBarangayDocumentTemplateContent($request['document_type'] ?? 'Barangay Certificate');
    $certificate = buildBarangayDocumentCertificateFromTemplate($templateContent, $documentData);
    $generatedPath = generateFilledDocumentPdf(buildBarangayDocumentPlainText($certificate), $outputDir, $documentData, $request['request_number'] ?? ('request-' . $requestId));

    if ($generatedPath !== '') {
        $updateStmt = mysqli_prepare($conn, "UPDATE document_requests SET generated_file_path = ? WHERE request_id = ?");
        if ($updateStmt) {
            mysqli_stmt_bind_param($updateStmt, 'si', $generatedPath, $requestId);
            mysqli_stmt_execute($updateStmt);
            mysqli_stmt_close($updateStmt);
        }
    }

    return $generatedPath;
}

function regenerateGeneratedDocumentsForTemplate($conn, $templateId, $outputDir) {
    $templateId = (int) $templateId;
    if (!$conn || $templateId <= 0) {
        return 0;
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT request_id
         FROM document_requests
         WHERE template_id = ?
           AND status IN ('approved', 'printed', 'released')
         ORDER BY request_id ASC"
    );
    if (!$stmt) {
        return 0;
    }

    mysqli_stmt_bind_param($stmt, 'i', $templateId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $updatedCount = 0;
    while ($row = mysqli_fetch_assoc($result)) {
        $generatedPath = generateDocumentForRequest($conn, (int) ($row['request_id'] ?? 0), $outputDir);
        if ($generatedPath !== '') {
            $updatedCount++;
        }
    }
    mysqli_stmt_close($stmt);

    return $updatedCount;
}

function escapePdfText($text) {
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], (string) $text);
}

function generateFilledDocumentPdf($templateContent, $outputDir, $data, $requestNumber) {
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0777, true);
    }

    $filledText = applyDocumentPlaceholders((string) $templateContent, $data);
    if (trim($filledText) === '') {
        $filledText = applyDocumentPlaceholders(getBarangayDocumentTemplateContent($data['document_type'] ?? 'Barangay Certificate'), $data);
    }

    $lines = preg_split('/\r\n|\r|\n/', $filledText);
    $lines = array_values(array_filter($lines, static function ($line) {
        return trim($line) !== '';
    }));
    if ($lines === []) {
        $lines = ['Barangay Document'];
    }

    $wrappedLines = [];
    foreach ($lines as $line) {
        $wrapped = wordwrap($line, 90, "\n", true);
        $wrappedLines = array_merge($wrappedLines, explode("\n", $wrapped));
    }

    $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', (string) ($requestNumber ?: 'document'));
    $fileName = $safeName . '_' . time() . '.pdf';
    $filePath = rtrim($outputDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $fileName;

    $contentStream = "BT\n/F1 12 Tf\n72 720 Td\n";
    foreach ($wrappedLines as $index => $line) {
        $contentStream .= '(' . escapePdfText($line) . ") Tj\n";
        if ($index < count($wrappedLines) - 1) {
            $contentStream .= "0 -14 Td\n";
        }
    }
    $contentStream .= "ET\n";

    $streamObject = "<< /Length " . strlen($contentStream) . " >>\nstream\n" . $contentStream . "\nendstream";

    $objects = [
        '<< /Type /Catalog /Pages 2 0 R >>',
        '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
        '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
        $streamObject,
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'
    ];

    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $index => $object) {
        $offsets[$index] = strlen($pdf);
        $pdf .= ($index + 1) . " 0 obj\n" . $object . "\nendobj\n";
    }

    $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    foreach ($offsets as $offset) {
        $pdf .= sprintf("%010d 00000 n \n", $offset);
    }
    $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n" . strlen($pdf) . "\n%%EOF\n";

    file_put_contents($filePath, $pdf);

    return 'uploads/generated_documents/' . basename($filePath);
}

function logActivity($conn, $userId, $username, $role, $action, $description) {
    if (!$conn) {
        return false;
    }

    $userId = (int) $userId;
    $username = trim((string) $username);
    $role = strtolower(trim((string) $role));
    $action = strtolower(preg_replace('/[^a-z0-9_]/', '', (string) $action));
    $description = trim((string) $description);

    if ($description === '') {
        $description = ucfirst(str_replace('_', ' ', $action));
    }

    $stmt = mysqli_prepare($conn, "INSERT INTO activity_logs (user_id, username, role, action, description, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, "issss", $userId, $username, $role, $action, $description);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    return $result;
}

<?php
$base = '../';

require_once '../auth/session.php';

ifLoggedIn();

function displayForgotPasswordFlashMessages() {
    if (!isset($_SESSION['errors']) && !isset($_SESSION['success'])) {
        return;
    }

    echo '<div class="flash-messages-container">';
    if (isset($_SESSION['errors'])) {
        foreach ($_SESSION['errors'] as $error) {
            echo '<p class="error-msg">&bull; ' . htmlspecialchars($error) . '</p>';
        }
        unset($_SESSION['errors']);
    }
    if (isset($_SESSION['success'])) {
        $successMessages = is_array($_SESSION['success']) ? $_SESSION['success'] : [$_SESSION['success']];
        foreach ($successMessages as $success) {
            echo '<p class="success-msg">' . htmlspecialchars($success) . '</p>';
        }
        unset($_SESSION['success']);
    }
    echo '</div>';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/forgotpass.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
<div class="sticky-header">
    <div class="navbar-top">
        <div class="top-content">
            <div class="flag-container">
                <img class="flag-img" src="../assets/ph-flag.jpg" alt="Philippine flag">
            </div>
            <div>
                <h1 class="portal-title">THE OFFICIAL WEB PORTAL OF BARANGAY KRUS NA LIGAS</h1>
            </div>
        </div>
    </div>

    <div class="navbar-main">
        <div class="nav-container">
            <nav class="nav-wrapper" id="nav-menu">
                <div class="logo-section">
                    <a href="#">
                        <img class="logo-img" src="../assets/logo.png" alt="Barangay logo">
                    </a>
                </div>
                <div class="mobile-toggle">
                    <i class="ri-menu-line" id="hamburger"></i>
                </div>
                <div class="nav-menu-desktop">
                    <ul class="nav-links">
                        <li>
                            <a href="../index.php">HOME</a>
                        </li>
                        <li>
                            <a href="registerPage.php">REGISTER</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="search-section-desktop">
                <div class="search-group">
                    <input class="search-input" type="text" name="" placeholder="Search">
                    <button type="submit" name="" class="search-btn">Search</button>
                </div>
            </div>
        </div>
    </div>

    <!-- MOBILE MENU DROPDOWN -->
    <div id="mobile-menu" class="mobile-menu-dropdown hidden">
        <div class="mobile-menu-content">
            <ul class="mobile-links">
                <li>
                            <a href="../index.php">HOME</a>
                        </li>
                        <li>
                            <a href="registerPage.php">REGISTER</a>
                        </li>
            </ul>
            <div class="search-group mobile-search">
                <input class="search-input" type="text" name="" placeholder="Search">
                <button type="submit" name="" class="search-btn">Search</button>
            </div>
        </div>
    </div>
</div>





  <div class="login-wrapper">
        <img src="../assets/bg.png" alt="Background" class="login-bg-img">
        <div class="login-overlay"></div>


  <div class="login-card">
        <img src="../assets/logo.png" alt="Barangay Logo">
        <h1>Barangay Krus na Ligas</h1>
        <h2>Forgot Password?</h2>
        <p>Enter your email address and we'll send you instructions to reset your password.</p>

        <?php displayForgotPasswordFlashMessages(); ?>

        <form action="../actions/requestPasswordReset.php" method="POST">
            <div class="request-form">
                <label for="email" class="form-label">Email Address</label>
                <div class="input-wrapper">
                    <input type="email" id="email" name="email" class="form-input" value="<?php echo htmlspecialchars(old('email')); ?>" placeholder="Enter your email" required>
                    <i class="fa-solid fa-message input-icon"></i>
                </div>
            </div>
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <button type="submit" class="btn-primary">Reset Password</button>
        </form>
        <a href="loginPage.php" class="back-link"><i class="fas fa-long-arrow-alt-left"></i> Back to Login</a>

        <?php clearOldInput(); ?>
    </div>
  </div>


    <script src="../script.js"></script>
</body>
</html>

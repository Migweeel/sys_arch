<?php 



$base = '../'; 

require_once '../auth/session.php';

$rememberUsername = $_COOKIE['remember_username'] ?? '';
$rememberPassword = $_COOKIE['remember_password'] ?? '';
$rememberRole = $_COOKIE['remember_role'] ?? '';
$rememberChecked = !empty($rememberUsername) && !empty($rememberPassword);

ifLoggedIn();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/login.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
</head>

<body>
    <!--- NAVIGATION --->
    <?php include $base . 'includes/navbar.php'; ?>

    <div class="login-wrapper">
        <img src="../assets/bg.png" alt="Background" class="login-bg-img">
        <div class="login-overlay"></div>

        <!-- Login card -->
        <div class="login-container">
            <div class="login-card">
                <img src="../assets/logo.png" class="card-logo" alt="Logo">
                <h2>Barangay Krus na Ligas</h2>

                <?php displayFlashMessages(); ?>

                <form action="../auth/login.php" method="POST">
                    <div class="form-group">
                        <label>Role</label>
                        <select name="role" class="form-control">
                            <option value="" disabled>
                                Select role
                            </option>
                            <option value="admin" <?= ($rememberRole === 'admin' || old('role') === 'admin') ? 'selected' : '' ?>>
                                Admin
                            </option>
                            <option value="staff" <?= ($rememberRole === 'staff' || old('role') === 'staff') ? 'selected' : '' ?>>
                                Staff
                            </option>
                            <option value="resident" <?= ($rememberRole === 'resident' || (!isset($_COOKIE['remember_role']) && old('role') !== 'admin' && old('role') !== 'staff')) ? 'selected' : '' ?>>
                                Resident
                            </option>
                        </select>
                    </div>

                    <label>Username</label>
                    <input type="text" name="username" placeholder="Enter your username" value="<?= htmlspecialchars($rememberUsername ?: old('username')) ?>">

                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter your password" value="<?= htmlspecialchars($rememberPassword) ?>">

                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                    <div class="options">
                        <label>
                            <input type="checkbox" name="remember" class="remember" <?= $rememberChecked ? 'checked' : '' ?>> Remember me
                        </label>
                        <a href="forgotpass.php">Forgot password?</a>
                    </div>

                    <button class="login-btn">Login</button>
                    <div class="footer-links">
                        <p>Dont have an account? <a href="registerPage.php">Register here</a></p>
                   </div>
                </form>

                <?php clearOldInput(); ?>

            </div>
        </div>
    </div>


    <script src="../script.js"></script>
</body>
</html>
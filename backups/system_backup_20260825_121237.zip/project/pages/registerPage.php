<?php 



$base = '../'; 

require_once '../auth/session.php';

ifLoggedIn();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="../css/index.css"> 
    <link rel="stylesheet" href="../css/register.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
</head>
<body>
    <!--- NAVIGATION --->
    <?php include $base . 'includes/navbar.php'; ?>

    <div class="register-section">
        <div class="register-bg-container">
            <img src="../assets/bg.png" alt="Background" class="register-bg-img">
            <div class="register-overlay"></div>
        </div>

        <div class="container">
            <div class="form-header">
                <img src="../assets/logo.png" alt="Barangay Logo" class="logo">
                <h3>Barangay Krus na Ligas</h3>
            </div>

            <?php displayFlashMessages(); ?>

            <form action="../auth/register.php" method="POST" enctype="multipart/form-data">
                <div class="section-header">Account Information</div>
                <div class="form-grid">
                    <div class="full-width">
                        <label>Username</label>
                        <input type="text" name="username" value="<?= old('username') ?>" placeholder="Choose a username">
                    </div>
                    <div>
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Enter a password">
                    </div>
                    <div>
                        <label>Confirm Password</label>
                        <input type="password" name="confirm_password" placeholder="Confirm your password">
                    </div>
                </div>

                <div class="section-header">Personal Information</div>
                <div class="form-grid">
                    <div>
                        <label>First Name</label>
                        <input type="text" name="first_name" value="<?= old('first_name') ?>" placeholder="First Name">
                    </div>
                    <div>
                        <label>Last Name</label>
                        <input type="text" name="last_name" value="<?= old('last_name') ?>" placeholder="Last Name">
                    </div>
                    <div>
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" value="<?= old('middle_name') ?>" placeholder="Proceed if N/A">
                    </div>
                    <div>
                        <label>Suffix</label>
                        <input type="text" name="suffix" value="<?= old('suffix') ?>" placeholder="e.g. Jr., Sr. (Proceed if N/A)">
                    </div>
                    <div>
                        <label>Date of Birth</label>
                        <input type="date" name="birthdate" value="<?= old('birthdate') ?>" max="<?= date('Y-m-d') ?>">
                    </div>
                    <div>
                        <label>Sex</label>
                        <select name="sex">
                            <option value="" disabled <?= old('sex') == '' ? 'selected' : '' ?>>
                                Select Sex
                            </option>
                            <option value="Male" <?= old('sex') == 'Male' ? 'selected' : '' ?>>
                                Male
                            </option>
                            <option value="Female" <?= old('sex') == 'Female' ? 'selected' : '' ?>>
                                Female
                            </option>
                        </select>
                    </div>
                    <div class="full-width">
                        <label>Address</label>
                        <input type="text" name="address" value="<?= old('address') ?>" placeholder="House No., Street Name, Phase/Blk">
                    </div>
                    <div>
                        <label>Civil Status</label>
                        <select name="civil_status">
                            <option value="" disabled <?= old('civil_status') == '' ? 'selected' : '' ?>>
                                Select Status
                            </option>
                            <option value="Single" <?= old('civil_status') == 'Single' ? 'selected' : '' ?>>
                                Single
                            </option>
                            <option value="Married" <?= old('civil_status') == 'Married' ? 'selected' : '' ?>>
                                Married
                            </option>
                            <option value="Widowed" <?= old('civil_status') == 'Widowed' ? 'selected' : '' ?>>
                                Widowed
                            </option>
                            <option value="Separated" <?= old('civil_status') == 'Separated' ? 'selected' : '' ?>>
                                Separated
                            </option>
                        </select>
                    </div>
                    <div>
                        <label>Phone Number</label>
                        <input type="text" name="phone_no" value="<?= old('phone_no') ?>" placeholder="09xxxxxxxxx">
                    </div>
                    <div class="full-width">
                        <label>Email Address</label>
                        <input type="email" name="email" value="<?= old('email') ?>" placeholder="example@email.com">
                    </div>
                </div>

                <div class="section-header">Verification</div>
                <div class="form-grid">
                    <div class="full-width">
                        <label>Proof of Residency / Valid ID</label>
                        <input type="file" name="verification_proof" accept=".jpg,.jpeg,.png,.pdf">
                        <p class="field-note">Upload a clear photo or PDF for admin verification before your account can be used.</p>
                    </div>
                </div>

                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                <button type="submit" class="register-btn">Register Account</button>
                <div class="footer-links">
                    <p>Already have an account? <a href="loginPage.php">Login here</a></p>
                </div>
            </form>

            <?php clearOldInput(); ?>

        </div>
    </div>

    <script src="../script.js"></script>
</body>
</html>

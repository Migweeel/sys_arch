const hamburger = document.getElementById("hamburger");
const mobileMenu = document.getElementById("mobile-menu");

function toggleMobileMenu() {
    mobileMenu.classList.toggle("show-mobile");
}

function initDropdown() {
    hamburger.addEventListener("click", toggleMobileMenu);
}

initDropdown();